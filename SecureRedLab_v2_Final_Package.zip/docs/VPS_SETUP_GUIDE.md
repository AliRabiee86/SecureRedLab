# راهنمای جامع راه‌اندازی SecureRedLab بر روی VPS
# Complete VPS Setup Guide for SecureRedLab

**نسخه:** 2.0.0 - Plan C (Hybrid Architecture)  
**تاریخ:** 2025-01-15  
**نوع پروژه:** تحقیقات آکادمیک  
**معماری:** Cloudflare Pages (Frontend) + VPS (Backend + Execution)

---

## 📊 **مشخصات فنی مورد نیاز (Hardware Requirements)**

### **حداقل (Minimum) - برای تست:**
- **CPU:** 4 Cores (Intel Xeon یا AMD EPYC)
- **RAM:** 8 GB DDR4
- **Storage:** 160 GB SSD
- **Bandwidth:** 1 TB/month
- **Network:** 1 Gbps
- **GPU:** ❌ Not Required (AI models از API استفاده می‌کنند)
- **هزینه تقریبی:** $20-30/month

### **پیشنهادی (Recommended) - برای Production:**
- **CPU:** 8 Cores (Intel Xeon یا AMD EPYC)
- **RAM:** 16 GB DDR4
- **Storage:** 320 GB NVMe SSD
- **Bandwidth:** 3 TB/month
- **Network:** 10 Gbps
- **GPU:** ❌ Not Required
- **هزینه تقریبی:** $50-80/month

### **⚠️ توجه مهم درباره GPU:**
```
❌ GPU NOT REQUIRED
چرا؟
1. ما از API های AI استفاده می‌کنیم (DeepSeek, LLaMA, Mixtral, Qwen, GLM)
2. TensorFlow/PyTorch فقط برای RL Engine استفاده می‌شود (CPU کافی است)
3. Neural Networks کوچک هستند (<100MB)
4. Training روی CPU در زمان معقول انجام می‌شود (<5 دقیقه)

✅ پس نیازی به GPU ندارید و هزینه کمتر می‌شود!
```

### **Operating System:**
- **توصیه:** Ubuntu 22.04 LTS Server (64-bit)
- **جایگزین:** Debian 12, Rocky Linux 9

### **ارائه‌دهندگان VPS پیشنهادی:**
1. **Hetzner** (آلمان) - $20-50/month - عالی برای اروپا
2. **DigitalOcean** (آمریکا) - $24-56/month - ساده و مستند
3. **Linode/Akamai** (آمریکا) - $24-60/month - قابل اعتماد
4. **Vultr** (جهانی) - $18-48/month - مراکز داده زیاد
5. **Contabo** (آلمان) - $15-40/month - ارزان اما کمی کندتر

---

## 📋 **Phase 0: Pre-Setup Checklist**

**قبل از شروع، این موارد را آماده کنید:**

- [ ] VPS خریداری شده یا دانشگاه سرور در اختیار گذاشته
- [ ] دسترسی SSH به VPS (Username + Password یا SSH Key)
- [ ] IP ثابت VPS
- [ ] دامنه (Domain) - اختیاری اما توصیه می‌شود
- [ ] حساب Cloudflare (برای Frontend)
- [ ] API Keys برای 5 مدل AI:
  - DeepSeek API Key
  - LLaMA API Key (Replicate/Together)
  - Mixtral API Key
  - Qwen API Key
  - GLM API Key

---

## 🚀 **Phase 1: VPS Initial Setup (30-45 دقیقه)**

### **1.1: اتصال اولیه به VPS**

```bash
# اتصال SSH
ssh root@YOUR_VPS_IP

# یا با SSH Key
ssh -i ~/.ssh/your_key root@YOUR_VPS_IP
```

### **1.2: بروزرسانی سیستم**

```bash
# بروزرسانی package list
apt update && apt upgrade -y

# نصب ابزارهای پایه
apt install -y curl wget git vim htop net-tools ufw
```

### **1.3: ساخت User جداگانه (امنیت)**

```bash
# ساخت user برای پروژه
useradd -m -s /bin/bash secureredlab
echo "secureredlab:YOUR_STRONG_PASSWORD" | chpasswd

# اضافه کردن به sudoers
usermod -aG sudo secureredlab

# تنظیم SSH Key برای user جدید (اختیاری)
mkdir -p /home/secureredlab/.ssh
cp /root/.ssh/authorized_keys /home/secureredlab/.ssh/
chown -R secureredlab:secureredlab /home/secureredlab/.ssh
chmod 700 /home/secureredlab/.ssh
chmod 600 /home/secureredlab/.ssh/authorized_keys
```

### **1.4: تنظیم Firewall (امنیت حیاتی!)**

```bash
# فعال‌سازی UFW
ufw --force enable

# اجازه SSH (خیلی مهم!)
ufw allow 22/tcp

# اجازه HTTP/HTTPS
ufw allow 80/tcp
ufw allow 443/tcp

# اجازه PostgreSQL (فقط از localhost)
ufw allow from 127.0.0.1 to any port 5432

# اجازه Redis (فقط از localhost)
ufw allow from 127.0.0.1 to any port 6379

# اجازه FastAPI (موقت - بعداً با Nginx reverse proxy می‌شود)
ufw allow 8000/tcp

# اجازه Prometheus (monitoring - اختیاری)
ufw allow 9090/tcp

# بررسی وضعیت
ufw status verbose
```

### **1.5: نصب Docker + Docker Compose**

```bash
# نصب Docker (روش رسمی)
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# اضافه کردن user به docker group
usermod -aG docker secureredlab

# نصب Docker Compose
curl -L "https://github.com/docker/compose/releases/download/v2.24.6/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# تست Docker
docker --version
docker-compose --version

# شروع Docker service
systemctl enable docker
systemctl start docker
```

### **1.6: نصب Python 3.12**

```bash
# اضافه کردن PPA
add-apt-repository ppa:deadsnakes/ppa -y
apt update

# نصب Python 3.12 و ابزارهای مرتبط
apt install -y python3.12 python3.12-venv python3.12-dev python3-pip

# تنظیم Python 3.12 به‌عنوان پیش‌فرض
update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.12 1

# تست
python3 --version  # باید 3.12.x نشان دهد
```

### **1.7: نصب PostgreSQL 16**

```bash
# اضافه کردن PostgreSQL APT Repository
sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget -qO- https://www.postgresql.org/media/keys/ACCC4CF8.asc | tee /etc/apt/trusted.gpg.d/pgdg.asc &>/dev/null
apt update

# نصب PostgreSQL 16
apt install -y postgresql-16 postgresql-contrib-16

# شروع و فعال‌سازی
systemctl enable postgresql
systemctl start postgresql

# تست
sudo -u postgres psql --version
```

### **1.8: نصب Redis 7**

```bash
# نصب Redis
apt install -y redis-server

# تنظیم Redis برای production
sed -i 's/^supervised no/supervised systemd/' /etc/redis/redis.conf
sed -i 's/^bind 127.0.0.1 ::1/bind 127.0.0.1/' /etc/redis/redis.conf

# شروع و فعال‌سازی
systemctl enable redis-server
systemctl start redis-server

# تست
redis-cli ping  # باید PONG برگرداند
```

### **1.9: نصب Nginx (Reverse Proxy)**

```bash
# نصب Nginx
apt install -y nginx

# شروع و فعال‌سازی
systemctl enable nginx
systemctl start nginx

# تست
systemctl status nginx
curl http://localhost  # باید صفحه پیش‌فرض Nginx نمایش دهد
```

---

## 🗃️ **Phase 2: Database Setup (20-30 دقیقه)**

### **2.1: ساخت Database و User**

```bash
# ورود به PostgreSQL
sudo -u postgres psql

# در PostgreSQL:
CREATE DATABASE secureredlab_production;
CREATE USER secureredlab_user WITH PASSWORD 'YOUR_SECURE_DB_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON DATABASE secureredlab_production TO secureredlab_user;
ALTER DATABASE secureredlab_production OWNER TO secureredlab_user;

-- فعال‌سازی Extensions
\c secureredlab_production
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

\q
```

### **2.2: اجرای Schema (ساخت جداول)**

```bash
# ذخیره Schema در فایل
cat > /tmp/schema.sql << 'EOF'
-- 1. جدول کاربران و احراز هویت
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    support_id VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(50) NOT NULL,
    institution VARCHAR(255),
    two_factor_secret TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. جدول تأییدیه‌های چندمرجعی
CREATE TABLE IF NOT EXISTS approvals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    approval_code VARCHAR(100) UNIQUE NOT NULL,
    authority_type VARCHAR(50) NOT NULL,
    target_description TEXT,
    simulation_type VARCHAR(50),
    intensity FLOAT,
    duration INTEGER,
    bot_count INTEGER,
    issued_by UUID REFERENCES users(id),
    approved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    is_valid BOOLEAN DEFAULT TRUE
);

-- 3. جدول تجربیات RL
CREATE TABLE IF NOT EXISTS rl_experiences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    experience_id VARCHAR(100) UNIQUE NOT NULL,
    agent_type VARCHAR(50) NOT NULL,
    simulation_type VARCHAR(50),
    state JSONB NOT NULL,
    action JSONB NOT NULL,
    reward FLOAT NOT NULL,
    next_state JSONB NOT NULL,
    done BOOLEAN NOT NULL,
    metadata JSONB,
    success BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. جدول Episodes
CREATE TABLE IF NOT EXISTS rl_episodes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    episode_id VARCHAR(100) UNIQUE NOT NULL,
    agent_type VARCHAR(50) NOT NULL,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP,
    total_reward FLOAT,
    success BOOLEAN,
    metrics JSONB,
    experience_count INTEGER DEFAULT 0
);

-- 5. جدول مدل‌های RL
CREATE TABLE IF NOT EXISTS rl_models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_type VARCHAR(50) NOT NULL,
    version VARCHAR(50) NOT NULL,
    model_data BYTEA NOT NULL,
    training_episodes INTEGER,
    average_reward FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- 6. جدول نتایج اسکن
CREATE TABLE IF NOT EXISTS scan_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id VARCHAR(100) UNIQUE NOT NULL,
    target VARCHAR(255) NOT NULL,
    target_type VARCHAR(50),
    os_detected VARCHAR(100),
    risk_score FLOAT,
    total_vulnerabilities INTEGER,
    critical_vulnerabilities INTEGER,
    scan_duration FLOAT,
    scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

-- 7. جدول آسیب‌پذیری‌ها
CREATE TABLE IF NOT EXISTS vulnerabilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vuln_id VARCHAR(100) UNIQUE NOT NULL,
    scan_id UUID REFERENCES scan_results(id) ON DELETE CASCADE,
    vuln_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    severity VARCHAR(20) NOT NULL,
    cvss_score FLOAT,
    cve_id VARCHAR(50),
    port INTEGER,
    service VARCHAR(100),
    exploit_probability FLOAT,
    recommendation TEXT,
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. جدول بازآموزی
CREATE TABLE IF NOT EXISTS retraining_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_type VARCHAR(50) NOT NULL,
    old_version VARCHAR(50),
    new_version VARCHAR(50) NOT NULL,
    training_episodes INTEGER,
    training_duration FLOAT,
    old_avg_reward FLOAT,
    new_avg_reward FLOAT,
    improvement_percentage FLOAT,
    retrained_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. جدول Audit Trail
CREATE TABLE IF NOT EXISTS audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(100) NOT NULL,
    user_id UUID REFERENCES users(id),
    target_entity VARCHAR(100),
    target_id UUID,
    action VARCHAR(50) NOT NULL,
    changes JSONB,
    ip_address INET,
    user_agent TEXT,
    tamper_proof_hash VARCHAR(64) NOT NULL,
    previous_hash VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. جدول AI Model Metrics
CREATE TABLE IF NOT EXISTS model_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_name VARCHAR(100) NOT NULL,
    model_type VARCHAR(50),
    total_requests INTEGER DEFAULT 0,
    successful_requests INTEGER DEFAULT 0,
    failed_requests INTEGER DEFAULT 0,
    average_latency FLOAT,
    average_confidence FLOAT,
    last_used TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_rl_experiences_agent ON rl_experiences(agent_type);
CREATE INDEX idx_rl_experiences_created ON rl_experiences(created_at DESC);
CREATE INDEX idx_scan_results_target ON scan_results(target);
CREATE INDEX idx_vulnerabilities_scan ON vulnerabilities(scan_id);
CREATE INDEX idx_vulnerabilities_severity ON vulnerabilities(severity);
CREATE INDEX idx_audit_trail_created ON audit_trail(created_at DESC);
CREATE INDEX idx_model_metrics_name ON model_metrics(model_name);

-- Trigger برای auto-update
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_model_metrics_updated_at BEFORE UPDATE ON model_metrics
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
EOF

# اجرای Schema
PGPASSWORD='YOUR_SECURE_DB_PASSWORD_HERE' psql -U secureredlab_user -d secureredlab_production -f /tmp/schema.sql

# حذف فایل موقت
rm /tmp/schema.sql
```

### **2.3: تست Database**

```bash
# تست اتصال و بررسی جداول
PGPASSWORD='YOUR_SECURE_DB_PASSWORD_HERE' psql -U secureredlab_user -d secureredlab_production -c "\dt"

# باید 10 جدول نمایش دهد:
# users, approvals, rl_experiences, rl_episodes, rl_models,
# scan_results, vulnerabilities, retraining_history, audit_trail, model_metrics
```

---

## 📦 **Phase 3: Project Structure Setup (15-20 دقیقه)**

### **3.1: ساخت ساختار پروژه**

```bash
# تغییر به user secureredlab
su - secureredlab

# ساخت ساختار اصلی
mkdir -p ~/SecureRedLab/{backend,frontend,docker,docs,logs,data}
cd ~/SecureRedLab

# ساخت ساختار Backend
mkdir -p backend/{core,api,execution,config,tests}
mkdir -p backend/api/{routes,websocket,middleware}
mkdir -p backend/execution/{metasploit,sqlmap,nmap,waf_bypass,custom}
mkdir -p backend/config/{production,development}

# ساخت ساختار Docker
mkdir -p docker/{metasploit,sqlmap,nmap,targets,base}
mkdir -p docker/targets/{sql_injection,xss,command_injection,file_upload,xxe}

# ساخت دایرکتوری‌های Logs
mkdir -p logs/{main,audit,error,performance,compliance}

# ساخت دایرکتوری Data
mkdir -p data/{models,experience_replay,scan_results,reports}
```

### **3.2: Clone کردن Repository (از Sandbox)**

**⚠️ این بخش را در Sandbox انجام دهید:**

```bash
# در Sandbox
cd /home/user/webapp/SecureRedLab

# اگر هنوز Git init نکرده‌اید:
git init
git add .
git commit -m "chore: Prepare for VPS migration - Plan C Hybrid Architecture"

# Push به GitHub (فرض: repository از قبل ساخته شده)
git remote add origin https://github.com/YOUR_USERNAME/SecureRedLab.git
git push -u origin main
```

**در VPS:**

```bash
# تغییر به user secureredlab
su - secureredlab
cd ~/SecureRedLab

# Clone repository
git clone https://github.com/YOUR_USERNAME/SecureRedLab.git .

# یا اگر از Private Repository استفاده می‌کنید:
git clone https://YOUR_TOKEN@github.com/YOUR_USERNAME/SecureRedLab.git .
```

### **3.3: ساخت Virtual Environment**

```bash
cd ~/SecureRedLab/backend

# ساخت venv
python3 -m venv venv

# فعال‌سازی
source venv/bin/activate

# بروزرسانی pip
pip install --upgrade pip setuptools wheel
```

---

## 🔧 **Phase 4: Backend Setup (45-60 دقیقه)**

### **4.1: ساخت requirements.txt**

```bash
cat > ~/SecureRedLab/backend/requirements.txt << 'EOF'
# Core Framework
fastapi==0.109.0
uvicorn[standard]==0.27.0
pydantic==2.5.3
pydantic-settings==2.1.0
python-multipart==0.0.6

# Database
psycopg2-binary==2.9.9
sqlalchemy==2.0.25
alembic==1.13.1
redis==5.0.1

# Security
PyJWT==2.8.0
passlib[bcrypt]==1.7.4
python-jose[cryptography]==3.3.0
cryptography==42.0.0

# AI/ML
tensorflow==2.15.0
torch==2.1.2
transformers==4.37.0
numpy==1.26.3
scikit-learn==1.4.0

# Async & Task Queue
celery==5.3.6
flower==2.0.1
kombu==5.3.5

# API Clients
httpx==0.26.0
aiohttp==3.9.1
requests==2.31.0

# Pentesting Tools Integration
python-libnmap==0.7.3
pymetasploit3==1.0.3

# Monitoring & Logging
prometheus-client==0.19.0
python-json-logger==2.0.7
psutil==5.9.8

# Utils
pyyaml==6.0.1
python-dotenv==1.0.0
jinja2==3.1.3
Pillow==10.2.0

# WebSocket
websockets==12.0
python-socketio==5.11.0

# Persian Support
jdatetime==4.1.1
persiantools==4.1.0

# Development
pytest==7.4.4
pytest-asyncio==0.23.3
black==24.1.1
flake8==7.0.0
mypy==1.8.0
EOF
```

### **4.2: نصب Dependencies**

```bash
cd ~/SecureRedLab/backend
source venv/bin/activate

# نصب (ممکن است 10-15 دقیقه طول بکشد)
pip install -r requirements.txt

# تست Import
python3 << EOF
import fastapi
import tensorflow as tf
import torch
print("✅ All dependencies installed successfully!")
print(f"FastAPI: {fastapi.__version__}")
print(f"TensorFlow: {tf.__version__}")
print(f"PyTorch: {torch.__version__}")
EOF
```

### **4.3: ساخت Configuration File**

```bash
cat > ~/SecureRedLab/backend/config/.env.production << 'EOF'
# Environment
ENVIRONMENT=production

# Database
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_NAME=secureredlab_production
DATABASE_USER=secureredlab_user
DATABASE_PASSWORD=YOUR_SECURE_DB_PASSWORD_HERE
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=10

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=

# Security
SECRET_KEY=YOUR_SECRET_KEY_HERE_GENERATE_WITH_openssl_rand_hex_32
JWT_SECRET=YOUR_JWT_SECRET_HERE_GENERATE_WITH_openssl_rand_hex_32
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
REFRESH_TOKEN_EXPIRE_DAYS=30
ENCRYPTION_KEY=YOUR_ENCRYPTION_KEY_HERE_GENERATE_WITH_openssl_rand_base64_32

# AI Models API Keys (شما باید این‌ها را از API providers دریافت کنید)
DEEPSEEK_API_ENDPOINT=https://api.deepseek.com/v1
DEEPSEEK_API_KEY=your_deepseek_api_key_here

LLAMA_API_ENDPOINT=https://api.together.xyz/v1
LLAMA_API_KEY=your_llama_api_key_here

MIXTRAL_API_ENDPOINT=https://api.mistral.ai/v1
MIXTRAL_API_KEY=your_mixtral_api_key_here

QWEN_API_ENDPOINT=https://dashscope.aliyuncs.com/api/v1
QWEN_API_KEY=your_qwen_api_key_here

GLM_API_ENDPOINT=https://open.bigmodel.cn/api/paas/v4
GLM_API_KEY=your_glm_api_key_here

# Celery
CELERY_BROKER_URL=redis://localhost:6379/1
CELERY_RESULT_BACKEND=redis://localhost:6379/2

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE_ROTATION=daily

# CORS (بعداً URL واقعی Cloudflare Pages را اضافه کنید)
CORS_ORIGINS=https://your-frontend.pages.dev,http://localhost:3000

# Rate Limiting
RATE_LIMIT_PER_MINUTE=60
RATE_LIMIT_BURST=100

# Monitoring
PROMETHEUS_PORT=9090
METRICS_ENABLED=true

# Docker Execution
DOCKER_SOCKET=/var/run/docker.sock
MAX_CONCURRENT_CONTAINERS=10
CONTAINER_TIMEOUT=300
EOF

# تنظیم permissions
chmod 600 ~/SecureRedLab/backend/config/.env.production
```

**⚠️ مهم: Generate کردن Secret Keys:**

```bash
# Generate SECRET_KEY
openssl rand -hex 32

# Generate JWT_SECRET
openssl rand -hex 32

# Generate ENCRYPTION_KEY
openssl rand -base64 32
```

---

## 📝 **Phase 5: تنظیم Systemd Services (30-40 دقیقه)**

### **5.1: FastAPI Service**

```bash
# ساخت Systemd service file
sudo cat > /etc/systemd/system/secureredlab-api.service << 'EOF'
[Unit]
Description=SecureRedLab FastAPI Backend
After=network.target postgresql.service redis-server.service

[Service]
Type=simple
User=secureredlab
Group=secureredlab
WorkingDirectory=/home/secureredlab/SecureRedLab/backend
Environment="PATH=/home/secureredlab/SecureRedLab/backend/venv/bin"
EnvironmentFile=/home/secureredlab/SecureRedLab/backend/config/.env.production
ExecStart=/home/secureredlab/SecureRedLab/backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
sudo systemctl daemon-reload

# فعال‌سازی (بعداً بعد از ساخت main.py)
# sudo systemctl enable secureredlab-api
# sudo systemctl start secureredlab-api
```

### **5.2: Celery Worker Service**

```bash
sudo cat > /etc/systemd/system/secureredlab-celery.service << 'EOF'
[Unit]
Description=SecureRedLab Celery Worker
After=network.target redis-server.service

[Service]
Type=simple
User=secureredlab
Group=secureredlab
WorkingDirectory=/home/secureredlab/SecureRedLab/backend
Environment="PATH=/home/secureredlab/SecureRedLab/backend/venv/bin"
EnvironmentFile=/home/secureredlab/SecureRedLab/backend/config/.env.production
ExecStart=/home/secureredlab/SecureRedLab/backend/venv/bin/celery -A core.celery_app worker --loglevel=info --concurrency=4
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
```

### **5.3: Celery Beat Service (برای Scheduled Tasks)**

```bash
sudo cat > /etc/systemd/system/secureredlab-celery-beat.service << 'EOF'
[Unit]
Description=SecureRedLab Celery Beat Scheduler
After=network.target redis-server.service

[Service]
Type=simple
User=secureredlab
Group=secureredlab
WorkingDirectory=/home/secureredlab/SecureRedLab/backend
Environment="PATH=/home/secureredlab/SecureRedLab/backend/venv/bin"
EnvironmentFile=/home/secureredlab/SecureRedLab/backend/config/.env.production
ExecStart=/home/secureredlab/SecureRedLab/backend/venv/bin/celery -A core.celery_app beat --loglevel=info
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
```

---

## 🐳 **Phase 6: Docker Containers Setup (60-90 دقیقه)**

### **6.1: Base Docker Compose**

```bash
cat > ~/SecureRedLab/docker/docker-compose.yml << 'EOF'
version: '3.8'

services:
  # Metasploit Container
  metasploit:
    build: ./metasploit
    container_name: secureredlab_metasploit
    hostname: metasploit
    networks:
      - attack_network
      - isolated_targets
    volumes:
      - metasploit_data:/root/.msf4
      - ./execution_scripts:/scripts
    environment:
      - MSF_DATABASE_URL=postgres://msf:msf_password@metasploit_db:5432/msf
    depends_on:
      - metasploit_db
    restart: unless-stopped
    security_opt:
      - seccomp:unconfined
    cap_add:
      - NET_ADMIN
      - NET_RAW

  metasploit_db:
    image: postgres:16-alpine
    container_name: secureredlab_metasploit_db
    environment:
      - POSTGRES_USER=msf
      - POSTGRES_PASSWORD=msf_password
      - POSTGRES_DB=msf
    volumes:
      - metasploit_db_data:/var/lib/postgresql/data
    networks:
      - attack_network
    restart: unless-stopped

  # SQLMap Container
  sqlmap:
    build: ./sqlmap
    container_name: secureredlab_sqlmap
    hostname: sqlmap
    networks:
      - attack_network
      - isolated_targets
    volumes:
      - sqlmap_data:/root/.sqlmap
      - ./execution_scripts:/scripts
    restart: unless-stopped

  # Nmap Container
  nmap:
    build: ./nmap
    container_name: secureredlab_nmap
    hostname: nmap
    networks:
      - attack_network
      - isolated_targets
    volumes:
      - ./execution_scripts:/scripts
    restart: unless-stopped
    cap_add:
      - NET_ADMIN
      - NET_RAW

  # Target 1: SQL Injection (DVWA)
  target_sqli:
    image: vulnerables/web-dvwa
    container_name: target_sqli
    hostname: target-sqli
    networks:
      - isolated_targets
    environment:
      - MYSQL_ROOT_PASSWORD=dvwa
      - MYSQL_DATABASE=dvwa
      - MYSQL_USER=dvwa
      - MYSQL_PASSWORD=p@ssw0rd
    restart: unless-stopped

  # Target 2: XSS (DVWA)
  target_xss:
    image: vulnerables/web-dvwa
    container_name: target_xss
    hostname: target-xss
    networks:
      - isolated_targets
    restart: unless-stopped

  # Target 3: Command Injection
  target_command_injection:
    build: ./targets/command_injection
    container_name: target_command_injection
    hostname: target-command-injection
    networks:
      - isolated_targets
    restart: unless-stopped

  # Target 4: File Upload
  target_file_upload:
    build: ./targets/file_upload
    container_name: target_file_upload
    hostname: target-file-upload
    networks:
      - isolated_targets
    restart: unless-stopped

  # Target 5: XXE
  target_xxe:
    build: ./targets/xxe
    container_name: target_xxe
    hostname: target-xxe
    networks:
      - isolated_targets
    restart: unless-stopped

networks:
  attack_network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
  
  isolated_targets:
    driver: bridge
    internal: true  # ← عدم دسترسی به اینترنت
    ipam:
      config:
        - subnet: 172.30.0.0/16

volumes:
  metasploit_data:
  metasploit_db_data:
  sqlmap_data:
EOF
```

### **6.2: Metasploit Dockerfile**

```bash
mkdir -p ~/SecureRedLab/docker/metasploit
cat > ~/SecureRedLab/docker/metasploit/Dockerfile << 'EOF'
FROM kalilinux/kali-rolling:latest

# نصب Metasploit و dependencies
RUN apt-get update && \
    DEBIAN_FRONTEND=noninteractive apt-get install -y \
    metasploit-framework \
    postgresql-client \
    python3 \
    python3-pip \
    curl \
    wget \
    git \
    netcat-traditional \
    nmap \
    && apt-get clean && \
    rm -rf /var/lib/apt/lists/*

# نصب pymetasploit3
RUN pip3 install --no-cache-dir pymetasploit3 requests

# ساخت دایرکتوری کار
WORKDIR /opt/metasploit

# کپی اسکریپت‌های helper
COPY entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh

EXPOSE 55553

ENTRYPOINT ["/entrypoint.sh"]
CMD ["msfconsole", "-r", "-"]
EOF

# ساخت entrypoint script
cat > ~/SecureRedLab/docker/metasploit/entrypoint.sh << 'EOF'
#!/bin/bash
set -e

# انتظار برای آماده شدن Database
echo "Waiting for PostgreSQL..."
while ! pg_isready -h metasploit_db -U msf; do
  sleep 1
done

# Initialize Database
if [ ! -f /root/.msf4/database.yml ]; then
  cat > /root/.msf4/database.yml << YAML
production:
  adapter: postgresql
  database: msf
  username: msf
  password: msf_password
  host: metasploit_db
  port: 5432
  pool: 5
  timeout: 5
YAML

  msfdb init
fi

# Start msfrpcd (RPC Server)
msfrpcd -P msf_rpc_password -a 0.0.0.0 -p 55553 &

# Execute command
exec "$@"
EOF
```

### **6.3: SQLMap Dockerfile**

```bash
mkdir -p ~/SecureRedLab/docker/sqlmap
cat > ~/SecureRedLab/docker/sqlmap/Dockerfile << 'EOF'
FROM python:3.11-slim

# نصب dependencies
RUN apt-get update && \
    apt-get install -y \
    git \
    curl \
    && apt-get clean && \
    rm -rf /var/lib/apt/lists/*

# Clone SQLMap
RUN git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git /opt/sqlmap

WORKDIR /opt/sqlmap

# نصب Python dependencies
RUN pip install --no-cache-dir requests

EXPOSE 8775

CMD ["python3", "sqlmapapi.py", "-s", "-H", "0.0.0.0", "-p", "8775"]
EOF
```

### **6.4: Nmap Dockerfile**

```bash
mkdir -p ~/SecureRedLab/docker/nmap
cat > ~/SecureRedLab/docker/nmap/Dockerfile << 'EOF'
FROM alpine:latest

# نصب Nmap و NSE Scripts
RUN apk add --no-cache \
    nmap \
    nmap-scripts \
    python3 \
    py3-pip \
    curl

# نصب python-libnmap
RUN pip3 install --no-cache-dir python-libnmap requests

WORKDIR /opt/nmap

CMD ["sh"]
EOF
```

### **6.5: Build کردن Containers**

```bash
cd ~/SecureRedLab/docker

# Build کردن تمام containers (ممکن است 20-30 دقیقه طول بکشد)
docker-compose build

# Start کردن containers
docker-compose up -d

# بررسی وضعیت
docker-compose ps

# تست Metasploit
docker exec -it secureredlab_metasploit msfconsole -v

# تست SQLMap
curl http://localhost:8775/task/new

# تست Nmap
docker exec -it secureredlab_nmap nmap --version
```

---

## 🎯 **Phase 7: کپی Core Modules از Sandbox (15-20 دقیقه)**

### **7.1: لیست فایل‌های قابل استفاده مستقیم**

```bash
# در VPS
cd ~/SecureRedLab/backend/core

# این فایل‌ها از Sandbox کپی می‌شوند (قبلاً در Git هستند):
# ✅ logging_system.py (25KB)
# ✅ exception_handler.py (29KB)
# ✅ config_manager.py (30KB)
# ✅ database_manager.py (28KB)
# ✅ auth_system.py (8.7KB)
# ✅ ai_output_validator.py (29KB)
# ✅ support_verification.py (30KB)

# Pull از Git
git pull origin main

# تست imports
python3 << 'EOF'
import sys
sys.path.insert(0, '/home/secureredlab/SecureRedLab/backend')

from core.logging_system import LoggingSystem
from core.exception_handler import SecureRedLabException
from core.config_manager import ConfigManager
from core.database_manager import get_database_manager
from core.auth_system import AuthSystem
from core.ai_output_validator import AIOutputValidator
from core.support_verification import SupportVerificationSystem

print("✅ All core modules imported successfully!")
EOF
```

---

## 📊 **Phase 8: Testing & Verification (20-30 دقیقه)**

### **8.1: Database Connection Test**

```bash
cd ~/SecureRedLab/backend
source venv/bin/activate

python3 << 'EOF'
import os
os.environ['DATABASE_HOST'] = 'localhost'
os.environ['DATABASE_PORT'] = '5432'
os.environ['DATABASE_NAME'] = 'secureredlab_production'
os.environ['DATABASE_USER'] = 'secureredlab_user'
os.environ['DATABASE_PASSWORD'] = 'YOUR_SECURE_DB_PASSWORD_HERE'

from core.database_manager import get_database_manager

db = get_database_manager()
print("✅ Database connection successful!")
print(f"Connected to: {db}")
EOF
```

### **8.2: Redis Connection Test**

```bash
python3 << 'EOF'
import redis

r = redis.Redis(host='localhost', port=6379, db=0)
r.set('test_key', 'test_value')
value = r.get('test_key')
print(f"✅ Redis test successful! Value: {value.decode()}")
EOF
```

### **8.3: Docker Network Test**

```bash
# تست اتصال بین containers
docker exec secureredlab_metasploit ping -c 3 target-sqli
docker exec secureredlab_sqlmap ping -c 3 target-xss
docker exec secureredlab_nmap ping -c 3 target-command-injection
```

---

## 🚀 **Phase 9: آماده‌سازی برای Development**

### **9.1: Checklist نهایی**

```bash
# 1. بررسی Services
sudo systemctl status postgresql
sudo systemctl status redis-server
sudo systemctl status nginx
docker-compose ps

# 2. بررسی Firewall
sudo ufw status verbose

# 3. بررسی Disk Space
df -h

# 4. بررسی RAM Usage
free -h

# 5. بررسی CPU
htop
```

### **9.2: Backup Script (توصیه می‌شود)**

```bash
cat > ~/SecureRedLab/scripts/backup.sh << 'EOF'
#!/bin/bash

# تنظیمات
BACKUP_DIR="/home/secureredlab/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="secureredlab_production"
DB_USER="secureredlab_user"
DB_PASSWORD="YOUR_SECURE_DB_PASSWORD_HERE"

# ساخت دایرکتوری backup
mkdir -p $BACKUP_DIR

# Backup Database
PGPASSWORD=$DB_PASSWORD pg_dump -U $DB_USER -h localhost $DB_NAME | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Backup Code
tar -czf $BACKUP_DIR/code_$DATE.tar.gz ~/SecureRedLab/backend/core

# Backup Logs
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz ~/SecureRedLab/logs

# حذف backups قدیمی‌تر از 30 روز
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete

echo "✅ Backup completed: $DATE"
EOF

chmod +x ~/SecureRedLab/scripts/backup.sh

# اضافه کردن به crontab (هر روز ساعت 3 صبح)
(crontab -l 2>/dev/null; echo "0 3 * * * /home/secureredlab/SecureRedLab/scripts/backup.sh") | crontab -
```

---

## 📝 **Phase 10: مراحل بعدی (Next Steps)**

**الان شما یک VPS آماده دارید با:**

✅ Ubuntu 22.04 LTS  
✅ Docker + Docker Compose  
✅ PostgreSQL 16 با 10 جدول  
✅ Redis 7  
✅ Python 3.12 + Virtual Environment  
✅ Nginx  
✅ Core Modules (7 فایل از Sandbox)  
✅ Docker Containers (Metasploit, SQLMap, Nmap, 5 Targets)  
✅ Systemd Services آماده  
✅ Firewall تنظیم شده  
✅ Backup Script  

**مراحل بعدی برنامه‌نویسی (در Sandbox):**

1. ✅ **ساخت FastAPI Backend** (main.py, routes, middleware)
2. ✅ **Migration AI Cores** (ai_core_engine.py, rl_engine.py, neural_vuln_scanner.py)
3. ✅ **ساخت Execution Layer** (Metasploit/SQLMap/Nmap wrappers)
4. ✅ **ساخت WAF Bypass Module** (با AI)
5. ✅ **ساخت WebSocket Gateway**
6. ✅ **Frontend Integration** (اتصال Cloudflare Pages به VPS)
7. ✅ **Testing & Documentation**

---

## 🔐 **امنیت و Best Practices**

### **توصیه‌های امنیتی:**

1. **SSH Key Authentication:**
```bash
# غیرفعال کردن password authentication
sudo sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo systemctl restart sshd
```

2. **Fail2Ban (محافظت در برابر Brute Force):**
```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

3. **Automatic Security Updates:**
```bash
sudo apt install unattended-upgrades -y
sudo dpkg-reconfigure --priority=low unattended-upgrades
```

4. **Nginx Rate Limiting (بعداً):**
```nginx
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;
```

---

## 📞 **پشتیبانی و Troubleshooting**

### **مشکلات رایج:**

**1. خطای اتصال به Database:**
```bash
# بررسی وضعیت PostgreSQL
sudo systemctl status postgresql

# بررسی لاگ‌ها
sudo tail -f /var/log/postgresql/postgresql-16-main.log
```

**2. خطای Docker:**
```bash
# Restart Docker
sudo systemctl restart docker

# بررسی لاگ‌های container
docker logs secureredlab_metasploit
```

**3. مشکل RAM:**
```bash
# بررسی استفاده از RAM
free -h

# Kill کردن process های سنگین
sudo pkill -f celery
```

---

## ✅ **Checklist نهایی قبل از شروع Development**

- [ ] VPS خریداری شده (4 CPU, 8GB RAM, 160GB SSD)
- [ ] Ubuntu 22.04 LTS نصب شده
- [ ] Docker + Docker Compose نصب شده
- [ ] PostgreSQL 16 راه‌اندازی شده (10 جداول ساخته شده)
- [ ] Redis 7 راه‌اندازی شده
- [ ] Python 3.12 + venv نصب شده
- [ ] requirements.txt نصب شده (بدون خطا)
- [ ] Nginx نصب شده
- [ ] Firewall تنظیم شده (UFW)
- [ ] Docker containers build و start شده‌اند
- [ ] Core modules از Sandbox کپی شده‌اند
- [ ] .env.production با secret keys پر شده
- [ ] Database connection test موفق
- [ ] Redis connection test موفق
- [ ] Docker network test موفق
- [ ] Backup script نصب شده
- [ ] SSH Key authentication فعال شده
- [ ] Fail2Ban نصب شده

---

## 🎓 **یادداشت برای دانشجویان/محققان**

این راهنما برای **تحقیقات آکادمیک** طراحی شده است. لطفاً:

1. ✅ **از مجوزهای لازم اطمینان حاصل کنید** (FBI, IRB, دانشگاه)
2. ✅ **فقط در محیط‌های ایزوله تست کنید**
3. ✅ **تمام فعالیت‌ها را log کنید** (برای حسابرسی)
4. ✅ **از Docker network isolation استفاده کنید**
5. ✅ **هرگز به سیستم‌های واقعی حمله نکنید**

---

**🚀 پس از اتمام این مراحل، VPS شما آماده است و می‌توانیم شروع به توسعه Backend کنیم!**

**تاریخ آخرین بروزرسانی:** 2025-01-15  
**نسخه:** 2.0.0 - Plan C Hybrid Architecture  
**نویسنده:** SecureRedLab Development Team
