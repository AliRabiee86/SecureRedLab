# 🔐 SecureRedLab Backend

**AI-Powered Penetration Testing System - FastAPI Backend**

## 📋 Overview

SecureRedLab Backend is a high-performance FastAPI application that powers the SecureRedLab penetration testing platform. It integrates:

- **RL Engine**: 5 Reinforcement Learning agents for intelligent attack optimization
- **Offline AI Core**: 4 LLM models with <5% hallucination rate
- **VLM Core**: 5 Vision Language Models with 3-Tier OCR Fallback
- **Execution Layer**: Docker-isolated security tool execution

## 🏗️ Architecture

```
backend/
├── app/
│   ├── api/v1/endpoints/      # 28 REST endpoints
│   ├── core/                  # 10 core modules (RL, Auth, Logging)
│   ├── ai/                    # 10 AI modules (LLM, VLM, OCR)
│   ├── models/                # 5 SQLAlchemy models
│   ├── schemas/               # 7 Pydantic schemas
│   ├── services/              # Business logic
│   ├── tasks/                 # Celery async tasks
│   ├── execution/             # Tool executors
│   └── main.py                # FastAPI app
├── tests/                     # Pytest test suite
├── alembic/                   # Database migrations
├── Dockerfile                 # Production container
└── requirements.txt           # Python dependencies
```

## 🚀 Quick Start

### 1. Environment Setup

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your configuration
nano .env
```

### 2. Local Development

```bash
# Install dependencies
pip install -r requirements-dev.txt

# Run database migrations
alembic upgrade head

# Start development server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 3. Docker Development

```bash
# Build image
docker build -t securedredlab-backend:latest .

# Run container
docker run -p 8000:8000 --env-file .env securedredlab-backend:latest
```

## 📚 API Documentation

Once running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### API Endpoints (28 total)

#### Authentication (4 endpoints)
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - Login
- `POST /api/v1/auth/refresh` - Refresh token
- `GET /api/v1/auth/me` - Get current user

#### Scans (5 endpoints)
- `POST /api/v1/scans` - Create scan
- `GET /api/v1/scans` - List scans
- `GET /api/v1/scans/{id}` - Get scan
- `DELETE /api/v1/scans/{id}` - Cancel scan
- `GET /api/v1/scans/{id}/results` - Get results

#### Attacks (5 endpoints)
- `POST /api/v1/attacks` - Create attack
- `GET /api/v1/attacks` - List attacks
- `GET /api/v1/attacks/{id}` - Get attack
- `POST /api/v1/attacks/{id}/stop` - Stop attack
- `GET /api/v1/attacks/{id}/results` - Get results

#### RL Engine (6 endpoints)
- `GET /api/v1/rl/episodes` - List episodes
- `GET /api/v1/rl/episodes/{id}` - Get episode
- `GET /api/v1/rl/stats` - Get statistics
- `POST /api/v1/rl/train` - Train agent
- `GET /api/v1/rl/models` - List models
- `POST /api/v1/rl/models/{type}/load` - Load model

#### AI (4 endpoints)
- `POST /api/v1/ai/generate` - Generate with LLM
- `POST /api/v1/ai/validate` - Validate output
- `GET /api/v1/ai/models` - List models
- `GET /api/v1/ai/stats` - Get statistics

#### VLM (4 endpoints)
- `POST /api/v1/vlm/process` - Process image URL
- `POST /api/v1/vlm/upload` - Upload and process
- `GET /api/v1/vlm/models` - List models
- `GET /api/v1/vlm/stats` - Get statistics

## 🧪 Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=app --cov-report=html

# Run specific test file
pytest tests/test_auth.py

# Run tests with markers
pytest -m "not slow"  # Skip slow tests
pytest -m integration  # Only integration tests
```

## 🛠️ Development

### Code Quality

```bash
# Format code
black app/ tests/

# Sort imports
isort app/ tests/

# Lint
flake8 app/ tests/

# Type checking
mypy app/
```

### Database Migrations

```bash
# Create migration
alembic revision -m "description"

# Apply migrations
alembic upgrade head

# Rollback
alembic downgrade -1

# Show current version
alembic current
```

## 📊 Performance

- **Async/Await**: All endpoints use `async def`
- **Connection Pooling**: SQLAlchemy with asyncpg
- **Caching**: Redis for frequently accessed data
- **Background Tasks**: Celery for long-running operations

## 🔒 Security

- **JWT Authentication**: Secure token-based auth
- **Password Hashing**: bcrypt with salt
- **Rate Limiting**: slowapi integration
- **CORS**: Configurable allowed origins
- **Input Validation**: Pydantic schemas
- **SQL Injection Protection**: SQLAlchemy ORM

## 🐳 Docker Deployment

See [FINAL_DEPLOYMENT_GUIDE.md](../docs/FINAL_DEPLOYMENT_GUIDE.md) for complete deployment instructions.

## 📝 License

Proprietary - For Authorized Use Only

## 👨‍💻 Author

SecureRedLab Team - معلم سختگیر (AI Assistant)

---

**Built with ❤️ for ethical security testing**
