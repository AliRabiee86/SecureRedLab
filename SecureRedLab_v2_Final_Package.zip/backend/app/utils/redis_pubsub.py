"""
Redis Pub/Sub Manager
Handles message passing between Celery tasks and WebSocket connections
"""

import json
import asyncio
import logging
from typing import Dict, Any, Callable, Optional
import redis.asyncio as aioredis
from redis.asyncio.client import PubSub

from app.config import settings

logger = logging.getLogger(__name__)


class RedisPubSubManager:
    """
    Manages Redis Pub/Sub for real-time updates.
    
    Celery tasks publish messages → Redis → WebSocket subscribers
    """
    
    def __init__(self):
        """Initialize Redis Pub/Sub manager"""
        self.redis_client: Optional[aioredis.Redis] = None
        self.pubsub: Optional[PubSub] = None
        self.subscribers: Dict[str, Callable] = {}
        self.listening_task: Optional[asyncio.Task] = None
        
        logger.info("RedisPubSubManager initialized")
    
    
    async def connect(self) -> None:
        """Connect to Redis"""
        try:
            self.redis_client = await aioredis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=True,
                max_connections=10,
            )
            
            self.pubsub = self.redis_client.pubsub()
            
            logger.info(f"Connected to Redis: {settings.REDIS_URL}")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    
    async def disconnect(self) -> None:
        """Disconnect from Redis"""
        if self.listening_task:
            self.listening_task.cancel()
            try:
                await self.listening_task
            except asyncio.CancelledError:
                pass
        
        if self.pubsub:
            await self.pubsub.close()
        
        if self.redis_client:
            await self.redis_client.close()
        
        logger.info("Disconnected from Redis")
    
    
    async def publish(
        self,
        channel: str,
        message: Dict[str, Any]
    ) -> int:
        """
        Publish a message to a Redis channel.
        
        Args:
            channel: Channel name (e.g., "scans:123", "attacks:456")
            message: Message data (will be JSON serialized)
            
        Returns:
            Number of subscribers that received the message
        """
        if not self.redis_client:
            logger.error("Redis client not connected")
            return 0
        
        try:
            message_json = json.dumps(message)
            result = await self.redis_client.publish(channel, message_json)
            
            logger.debug(f"Published to {channel}: {result} subscribers")
            return result
        except Exception as e:
            logger.error(f"Failed to publish message: {e}")
            return 0
    
    
    async def subscribe(
        self,
        channel: str,
        callback: Callable[[Dict[str, Any]], None]
    ) -> None:
        """
        Subscribe to a Redis channel.
        
        Args:
            channel: Channel name to subscribe to
            callback: Async function to call when message is received
        """
        if not self.pubsub:
            logger.error("PubSub not initialized")
            return
        
        try:
            await self.pubsub.subscribe(channel)
            self.subscribers[channel] = callback
            
            logger.info(f"Subscribed to channel: {channel}")
        except Exception as e:
            logger.error(f"Failed to subscribe to {channel}: {e}")
    
    
    async def unsubscribe(self, channel: str) -> None:
        """
        Unsubscribe from a Redis channel.
        
        Args:
            channel: Channel name to unsubscribe from
        """
        if not self.pubsub:
            return
        
        try:
            await self.pubsub.unsubscribe(channel)
            if channel in self.subscribers:
                del self.subscribers[channel]
            
            logger.info(f"Unsubscribed from channel: {channel}")
        except Exception as e:
            logger.error(f"Failed to unsubscribe from {channel}: {e}")
    
    
    async def listen(self) -> None:
        """
        Listen for messages on subscribed channels.
        
        This should run as a background task.
        """
        if not self.pubsub:
            logger.error("PubSub not initialized")
            return
        
        logger.info("Started listening for Redis messages")
        
        try:
            async for message in self.pubsub.listen():
                if message["type"] == "message":
                    channel = message["channel"]
                    data_str = message["data"]
                    
                    try:
                        data = json.loads(data_str)
                        
                        # Call subscriber callback
                        if channel in self.subscribers:
                            callback = self.subscribers[channel]
                            
                            # Run callback
                            if asyncio.iscoroutinefunction(callback):
                                await callback(data)
                            else:
                                callback(data)
                        
                    except json.JSONDecodeError as e:
                        logger.error(f"Invalid JSON in message: {e}")
                    except Exception as e:
                        logger.error(f"Error processing message: {e}")
        
        except asyncio.CancelledError:
            logger.info("Stopped listening for Redis messages")
            raise
        except Exception as e:
            logger.error(f"Error in listen loop: {e}")
    
    
    async def start_listening(self) -> None:
        """Start listening task in background"""
        if self.listening_task:
            logger.warning("Already listening")
            return
        
        self.listening_task = asyncio.create_task(self.listen())
        logger.info("Started Redis listening task")
    
    
    # Helper methods for specific resource types
    
    async def publish_scan_update(
        self,
        scan_id: str,
        update_type: str,
        data: Dict[str, Any]
    ) -> int:
        """
        Publish scan update.
        
        Args:
            scan_id: Scan ID
            update_type: Type of update (progress, status, result, etc.)
            data: Update data
            
        Returns:
            Number of subscribers
        """
        message = {
            "type": update_type,
            "scan_id": scan_id,
            "data": data,
        }
        
        return await self.publish(f"scans:{scan_id}", message)
    
    
    async def publish_attack_update(
        self,
        attack_id: str,
        update_type: str,
        data: Dict[str, Any]
    ) -> int:
        """
        Publish attack update.
        
        Args:
            attack_id: Attack ID
            update_type: Type of update (progress, status, result, etc.)
            data: Update data
            
        Returns:
            Number of subscribers
        """
        message = {
            "type": update_type,
            "attack_id": attack_id,
            "data": data,
        }
        
        return await self.publish(f"attacks:{attack_id}", message)
    
    
    async def publish_rl_update(
        self,
        episode_id: str,
        update_type: str,
        data: Dict[str, Any]
    ) -> int:
        """
        Publish RL episode update.
        
        Args:
            episode_id: Episode ID
            update_type: Type of update (progress, status, result, etc.)
            data: Update data
            
        Returns:
            Number of subscribers
        """
        message = {
            "type": update_type,
            "episode_id": episode_id,
            "data": data,
        }
        
        return await self.publish(f"rl:{episode_id}", message)


# Global Redis Pub/Sub manager instance
redis_pubsub_manager = RedisPubSubManager()
