"""
WebSocket Connection Manager
Manages WebSocket connections for real-time updates
"""

from typing import Dict, Set, Any, Optional
from fastapi import WebSocket, WebSocketDisconnect
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class ConnectionManager:
    """
    Manages WebSocket connections for real-time updates.
    
    Supports:
    - Multiple connections per resource (scan_id, attack_id, etc.)
    - Broadcasting messages to specific resources
    - Connection lifecycle management
    - Automatic cleanup on disconnect
    """
    
    def __init__(self):
        """Initialize connection manager"""
        # Active connections: {resource_type: {resource_id: Set[WebSocket]}}
        self.active_connections: Dict[str, Dict[str, Set[WebSocket]]] = {
            "scans": {},
            "attacks": {},
            "rl": {},
            "ai": {},
        }
        
        # Connection metadata: {websocket: {resource_type, resource_id, connected_at}}
        self.connection_metadata: Dict[WebSocket, Dict[str, Any]] = {}
        
        logger.info("ConnectionManager initialized")
    
    
    async def connect(
        self, 
        websocket: WebSocket, 
        resource_type: str, 
        resource_id: str
    ) -> None:
        """
        Accept and register a new WebSocket connection.
        
        Args:
            websocket: FastAPI WebSocket instance
            resource_type: Type of resource (scans, attacks, rl, ai)
            resource_id: Unique ID of the resource
        """
        await websocket.accept()
        
        # Initialize resource type if not exists
        if resource_type not in self.active_connections:
            self.active_connections[resource_type] = {}
        
        # Initialize resource ID set if not exists
        if resource_id not in self.active_connections[resource_type]:
            self.active_connections[resource_type][resource_id] = set()
        
        # Add connection
        self.active_connections[resource_type][resource_id].add(websocket)
        
        # Store metadata
        self.connection_metadata[websocket] = {
            "resource_type": resource_type,
            "resource_id": resource_id,
            "connected_at": datetime.utcnow().isoformat(),
        }
        
        logger.info(
            f"WebSocket connected: {resource_type}/{resource_id} "
            f"(Total: {len(self.active_connections[resource_type][resource_id])})"
        )
        
        # Send welcome message
        await self.send_personal_message(
            websocket,
            {
                "type": "connection_established",
                "resource_type": resource_type,
                "resource_id": resource_id,
                "timestamp": datetime.utcnow().isoformat(),
            }
        )
    
    
    def disconnect(self, websocket: WebSocket) -> None:
        """
        Remove a WebSocket connection.
        
        Args:
            websocket: FastAPI WebSocket instance to disconnect
        """
        if websocket not in self.connection_metadata:
            return
        
        metadata = self.connection_metadata[websocket]
        resource_type = metadata["resource_type"]
        resource_id = metadata["resource_id"]
        
        # Remove from active connections
        if (resource_type in self.active_connections and 
            resource_id in self.active_connections[resource_type]):
            self.active_connections[resource_type][resource_id].discard(websocket)
            
            # Clean up empty sets
            if not self.active_connections[resource_type][resource_id]:
                del self.active_connections[resource_type][resource_id]
        
        # Remove metadata
        del self.connection_metadata[websocket]
        
        logger.info(f"WebSocket disconnected: {resource_type}/{resource_id}")
    
    
    async def send_personal_message(
        self, 
        websocket: WebSocket, 
        message: Dict[str, Any]
    ) -> None:
        """
        Send a message to a specific WebSocket connection.
        
        Args:
            websocket: Target WebSocket
            message: Message data (will be JSON serialized)
        """
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Failed to send personal message: {e}")
            self.disconnect(websocket)
    
    
    async def broadcast_to_resource(
        self,
        resource_type: str,
        resource_id: str,
        message: Dict[str, Any]
    ) -> int:
        """
        Broadcast a message to all connections subscribed to a resource.
        
        Args:
            resource_type: Type of resource (scans, attacks, rl, ai)
            resource_id: Unique ID of the resource
            message: Message data (will be JSON serialized)
            
        Returns:
            Number of connections the message was sent to
        """
        if (resource_type not in self.active_connections or
            resource_id not in self.active_connections[resource_type]):
            logger.debug(
                f"No active connections for {resource_type}/{resource_id}"
            )
            return 0
        
        connections = self.active_connections[resource_type][resource_id].copy()
        sent_count = 0
        failed_connections = []
        
        for connection in connections:
            try:
                await connection.send_json(message)
                sent_count += 1
            except WebSocketDisconnect:
                logger.warning(f"Connection disconnected during broadcast")
                failed_connections.append(connection)
            except Exception as e:
                logger.error(f"Failed to broadcast message: {e}")
                failed_connections.append(connection)
        
        # Clean up failed connections
        for connection in failed_connections:
            self.disconnect(connection)
        
        logger.debug(
            f"Broadcast to {resource_type}/{resource_id}: "
            f"{sent_count} sent, {len(failed_connections)} failed"
        )
        
        return sent_count
    
    
    async def broadcast_progress(
        self,
        resource_type: str,
        resource_id: str,
        progress: int,
        message: str,
        data: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Broadcast progress update to all connections.
        
        Args:
            resource_type: Type of resource
            resource_id: Unique ID of the resource
            progress: Progress percentage (0-100)
            message: Progress message
            data: Additional data to include
            
        Returns:
            Number of connections the message was sent to
        """
        payload = {
            "type": "progress_update",
            "resource_type": resource_type,
            "resource_id": resource_id,
            "progress": progress,
            "message": message,
            "timestamp": datetime.utcnow().isoformat(),
        }
        
        if data:
            payload["data"] = data
        
        return await self.broadcast_to_resource(resource_type, resource_id, payload)
    
    
    async def broadcast_status(
        self,
        resource_type: str,
        resource_id: str,
        status: str,
        message: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Broadcast status change to all connections.
        
        Args:
            resource_type: Type of resource
            resource_id: Unique ID of the resource
            status: New status (running, completed, failed, etc.)
            message: Optional status message
            data: Additional data to include
            
        Returns:
            Number of connections the message was sent to
        """
        payload = {
            "type": "status_update",
            "resource_type": resource_type,
            "resource_id": resource_id,
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
        }
        
        if message:
            payload["message"] = message
        
        if data:
            payload["data"] = data
        
        return await self.broadcast_to_resource(resource_type, resource_id, payload)
    
    
    def get_connection_count(
        self, 
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None
    ) -> int:
        """
        Get the number of active connections.
        
        Args:
            resource_type: Optional filter by resource type
            resource_id: Optional filter by resource ID (requires resource_type)
            
        Returns:
            Number of active connections
        """
        if resource_type and resource_id:
            if (resource_type in self.active_connections and
                resource_id in self.active_connections[resource_type]):
                return len(self.active_connections[resource_type][resource_id])
            return 0
        
        if resource_type:
            if resource_type in self.active_connections:
                return sum(
                    len(connections) 
                    for connections in self.active_connections[resource_type].values()
                )
            return 0
        
        # Total connections
        return len(self.connection_metadata)
    
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get connection statistics.
        
        Returns:
            Dictionary with connection statistics
        """
        stats = {
            "total_connections": len(self.connection_metadata),
            "by_resource_type": {},
        }
        
        for resource_type in self.active_connections:
            resource_count = len(self.active_connections[resource_type])
            connection_count = sum(
                len(connections)
                for connections in self.active_connections[resource_type].values()
            )
            
            stats["by_resource_type"][resource_type] = {
                "resources": resource_count,
                "connections": connection_count,
            }
        
        return stats


# Global connection manager instance
connection_manager = ConnectionManager()
