"""
Celery Helper Functions
Utility functions for Celery tasks to publish real-time updates
"""

import redis
import json
from typing import Dict, Any
from app.config import settings


def get_redis_client():
    """Get synchronous Redis client for Celery tasks"""
    return redis.from_url(settings.REDIS_URL, decode_responses=True)


def publish_progress_update(
    resource_type: str,
    resource_id: str,
    progress: int,
    message: str,
    data: Dict[str, Any] = None
) -> int:
    """
    Publish progress update from Celery task.
    
    Args:
        resource_type: Type of resource (scans, attacks, rl)
        resource_id: Unique ID of the resource
        progress: Progress percentage (0-100)
        message: Progress message
        data: Additional data to include
        
    Returns:
        Number of subscribers that received the message
    """
    client = get_redis_client()
    channel = f"{resource_type}:{resource_id}"
    
    payload = {
        "type": "progress_update",
        f"{resource_type[:-1]}_id": resource_id,  # scan_id, attack_id, etc.
        "progress": progress,
        "message": message,
    }
    
    if data:
        payload["data"] = data
    
    result = client.publish(channel, json.dumps(payload))
    client.close()
    
    return result


def publish_status_update(
    resource_type: str,
    resource_id: str,
    status: str,
    message: str = None,
    data: Dict[str, Any] = None
) -> int:
    """
    Publish status update from Celery task.
    
    Args:
        resource_type: Type of resource (scans, attacks, rl)
        resource_id: Unique ID of the resource
        status: New status (running, completed, failed, etc.)
        message: Optional status message
        data: Additional data to include
        
    Returns:
        Number of subscribers that received the message
    """
    client = get_redis_client()
    channel = f"{resource_type}:{resource_id}"
    
    payload = {
        "type": "status_update",
        f"{resource_type[:-1]}_id": resource_id,
        "status": status,
    }
    
    if message:
        payload["message"] = message
    
    if data:
        payload["data"] = data
    
    result = client.publish(channel, json.dumps(payload))
    client.close()
    
    return result


def publish_result_update(
    resource_type: str,
    resource_id: str,
    result_data: Dict[str, Any]
) -> int:
    """
    Publish result update from Celery task.
    
    Args:
        resource_type: Type of resource (scans, attacks, rl)
        resource_id: Unique ID of the resource
        result_data: Result data to publish
        
    Returns:
        Number of subscribers that received the message
    """
    client = get_redis_client()
    channel = f"{resource_type}:{resource_id}"
    
    payload = {
        "type": "result_update",
        f"{resource_type[:-1]}_id": resource_id,
        "data": result_data,
    }
    
    result = client.publish(channel, json.dumps(payload))
    client.close()
    
    return result


def publish_error(
    resource_type: str,
    resource_id: str,
    error_message: str,
    error_details: Dict[str, Any] = None
) -> int:
    """
    Publish error from Celery task.
    
    Args:
        resource_type: Type of resource (scans, attacks, rl)
        resource_id: Unique ID of the resource
        error_message: Error message
        error_details: Additional error details
        
    Returns:
        Number of subscribers that received the message
    """
    client = get_redis_client()
    channel = f"{resource_type}:{resource_id}"
    
    payload = {
        "type": "error",
        f"{resource_type[:-1]}_id": resource_id,
        "message": error_message,
    }
    
    if error_details:
        payload["details"] = error_details
    
    result = client.publish(channel, json.dumps(payload))
    client.close()
    
    return result
