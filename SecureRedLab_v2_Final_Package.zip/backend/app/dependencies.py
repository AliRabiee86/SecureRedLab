"""
SecureRedLab Backend - Dependency Injection
FastAPI dependencies for authentication, database, etc.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from typing import Optional

from app.config import settings
from app.core.auth_system import AuthSystem

# Security
security = HTTPBearer()

# Global instances
auth_system = AuthSystem()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """
    Validate JWT token and return current user
    
    Args:
        credentials: HTTP Bearer token
        
    Returns:
        dict: User information
        
    Raises:
        HTTPException: If token is invalid
    """
    token = credentials.credentials
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        
        # TODO: Fetch user from database
        return {"user_id": user_id}
    
    except JWTError:
        raise credentials_exception


async def get_current_active_user(
    current_user: dict = Depends(get_current_user)
) -> dict:
    """
    Validate that current user is active
    
    Args:
        current_user: Current user from get_current_user
        
    Returns:
        dict: Active user information
        
    Raises:
        HTTPException: If user is inactive
    """
    # TODO: Check if user is active in database
    if current_user.get("is_active", True) is False:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Inactive user"
        )
    
    return current_user


async def get_current_admin_user(
    current_user: dict = Depends(get_current_user)
) -> dict:
    """
    Validate that current user is admin
    
    Args:
        current_user: Current user from get_current_user
        
    Returns:
        dict: Admin user information
        
    Raises:
        HTTPException: If user is not admin
    """
    # TODO: Check if user is admin in database
    if current_user.get("is_admin", False) is False:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin privileges required"
        )
    
    return current_user


# Database dependency (placeholder)
async def get_db():
    """
    Get database session
    
    Yields:
        Database session
    """
    # TODO: Implement database session management
    pass


# AI Engine dependency
async def get_ai_engine():
    """
    Get AI engine instance
    
    Returns:
        AI engine instance
    """
    from app.ai.scanner_ai_adapter import get_scanner_ai_engine
    return get_scanner_ai_engine()


# RL Engine dependency
async def get_rl_engine():
    """
    Get RL engine instance
    
    Returns:
        RL engine instance
    """
    from app.core.rl_engine import get_rl_engine
    return get_rl_engine()
