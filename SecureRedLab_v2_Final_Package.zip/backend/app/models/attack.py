"""
SecureRedLab Backend - Attack Model
SQLAlchemy model for attacks table
"""

from sqlalchemy import Column, String, Enum, Integer, JSON, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel


class AttackStatusEnum(str, enum.Enum):
    """Attack status enum"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


class AttackTypeEnum(str, enum.Enum):
    """Attack type enum"""
    DDOS = "ddos"
    SHELL_UPLOAD = "shell_upload"
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    DATA_EXTRACTION = "data_extraction"


class Attack(BaseModel):
    """Attack model"""
    __tablename__ = "attacks"
    
    target = Column(String(500), nullable=False, index=True)
    attack_type = Column(Enum(AttackTypeEnum), nullable=False, index=True)
    status = Column(Enum(AttackStatusEnum), nullable=False, default=AttackStatusEnum.PENDING, index=True)
    
    parameters = Column(JSON)
    use_rl = Column(Boolean, default=True)
    
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    progress = Column(Integer, default=0)
    
    results = Column(JSON)
    error = Column(Text)
    
    rl_episode_id = Column(String(36), index=True)
    
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    
    # Relationships
    # user = relationship("User", back_populates="attacks")
    
    def __repr__(self):
        return f"<Attack(id={self.id}, target={self.target}, type={self.attack_type}, status={self.status})>"
