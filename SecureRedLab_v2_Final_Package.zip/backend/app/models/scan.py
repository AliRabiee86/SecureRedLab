"""
SecureRedLab Backend - Scan Model
SQLAlchemy model for scans table
"""

from sqlalchemy import Column, String, Enum, Integer, JSON, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel


class ScanStatusEnum(str, enum.Enum):
    """Scan status enum"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ScanTypeEnum(str, enum.Enum):
    """Scan type enum"""
    PORT_SCAN = "port_scan"
    VULNERABILITY_SCAN = "vulnerability_scan"
    WEB_SCAN = "web_scan"
    FULL_SCAN = "full_scan"


class Scan(BaseModel):
    """Scan model"""
    __tablename__ = "scans"
    
    target = Column(String(255), nullable=False, index=True)
    scan_type = Column(Enum(ScanTypeEnum), nullable=False, default=ScanTypeEnum.PORT_SCAN)
    status = Column(Enum(ScanStatusEnum), nullable=False, default=ScanStatusEnum.PENDING, index=True)
    
    ports = Column(String(255))
    options = Column(JSON)
    
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    progress = Column(Integer, default=0)
    
    results = Column(JSON)
    error = Column(Text)
    
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    
    # Relationships
    # user = relationship("User", back_populates="scans")
    
    def __repr__(self):
        return f"<Scan(id={self.id}, target={self.target}, type={self.scan_type}, status={self.status})>"
