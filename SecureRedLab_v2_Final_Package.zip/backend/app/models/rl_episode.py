"""
SecureRedLab Backend - RL Episode Model
SQLAlchemy model for RL episodes table
"""

from sqlalchemy import Column, String, Enum, Integer, Float, JSON, DateTime, Text
import enum

from app.models.base import BaseModel


class RLAgentTypeEnum(str, enum.Enum):
    """RL Agent type enum"""
    DDOS = "ddos"
    SHELL = "shell"
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    DATA_EXTRACTION = "data_extraction"


class RLEpisodeStatusEnum(str, enum.Enum):
    """RL Episode status enum"""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class RLEpisode(BaseModel):
    """RL Episode model"""
    __tablename__ = "rl_episodes"
    
    agent_type = Column(Enum(RLAgentTypeEnum), nullable=False, index=True)
    status = Column(Enum(RLEpisodeStatusEnum), nullable=False, default=RLEpisodeStatusEnum.RUNNING, index=True)
    
    total_reward = Column(Float, default=0.0)
    steps = Column(Integer, default=0)
    success_rate = Column(Float, default=0.0)
    
    initial_state = Column(JSON)
    final_state = Column(JSON)
    actions = Column(JSON)
    
    completed_at = Column(DateTime)
    metadata = Column(JSON)
    error = Column(Text)
    
    attack_id = Column(String(36), index=True)
    
    def __repr__(self):
        return f"<RLEpisode(id={self.id}, agent={self.agent_type}, status={self.status}, reward={self.total_reward})>"


class RLExperience(BaseModel):
    """RL Experience model (for training)"""
    __tablename__ = "rl_experiences"
    
    episode_id = Column(String(36), nullable=False, index=True)
    agent_type = Column(Enum(RLAgentTypeEnum), nullable=False, index=True)
    
    state = Column(JSON, nullable=False)
    action = Column(JSON, nullable=False)
    reward = Column(Float, nullable=False)
    next_state = Column(JSON, nullable=False)
    done = Column(String(10), nullable=False)
    
    def __repr__(self):
        return f"<RLExperience(id={self.id}, episode={self.episode_id}, reward={self.reward})>"


class RLModel(BaseModel):
    """RL Model storage"""
    __tablename__ = "rl_models"
    
    agent_type = Column(Enum(RLAgentTypeEnum), nullable=False, unique=True, index=True)
    version = Column(String(20), nullable=False)
    
    trained_episodes = Column(Integer, default=0)
    avg_reward = Column(Float, default=0.0)
    success_rate = Column(Float, default=0.0)
    
    model_path = Column(String(500))
    file_size_mb = Column(Float)
    
    metadata = Column(JSON)
    
    def __repr__(self):
        return f"<RLModel(agent={self.agent_type}, version={self.version}, reward={self.avg_reward})>"
