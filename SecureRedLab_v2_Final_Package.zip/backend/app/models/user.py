"""
SecureRedLab Backend - User Model
SQLAlchemy model for users table
"""

from sqlalchemy import Column, String, Boolean, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime

from app.models.base import BaseModel


class User(BaseModel):
    """User model"""
    __tablename__ = "users"
    
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(100))
    
    is_active = Column(Boolean, default=True, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    
    last_login = Column(DateTime)
    last_password_change = Column(DateTime)
    failed_login_attempts = Column(String(10), default="0")
    
    # Relationships
    # scans = relationship("Scan", back_populates="user", cascade="all, delete-orphan")
    # attacks = relationship("Attack", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(id={self.id}, username={self.username}, email={self.email})>"
    
    def to_dict(self):
        """Convert to dictionary (exclude password)"""
        data = super().to_dict()
        data.pop('password_hash', None)
        return data
