#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab - Reinforcement Learning Engine (موتور یادگیری تقویتی)
==============================================================================
نسخه 2.0.0 - یکپارچه شده با سیستم ایجنتیک (Multi-Agent)

این ماژول هسته یادگیری تقویتی است که به سیستم اجازه می‌دهد پس از هر تست،
کیفیت حملات را بهبود دهد و از تجربیات گذشته یاد بگیرد. در نسخه 2.0، این موتور
به عنوان یک لایه یادگیری برای Agents عمل می‌کند.

ویژگی‌های کلیدی:
- پنج Agent مستقل برای پنج نوع حمله (DDoS, Shell, Extract, Deface, Behavior)
- الگوریتم‌های RL: Q-Learning, Policy Gradient, Actor-Critic, PPO
- Experience Replay Buffer با priority sampling
- بازآموزی خودکار و Reward shaping برای بهینه‌سازی استراتژی
"""

import os
import sys
import json
import numpy as np
import threading
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Callable
from enum import Enum
from dataclasses import dataclass, asdict
from collections import deque
import pickle
import hashlib

# Import کردن سیستم‌های قبلی
from app.core.logging_system import get_logger, log_performance, LogCategory
from app.core.exception_handler import (
    SecureRedLabException, AIException, DatabaseException,
    handle_exception, retry_on_failure, ErrorSeverity
)
from app.core.config_manager import get_config
from app.core.database_manager import get_db_manager

# ==============================================================================
# Enums & Constants
# ==============================================================================

class RLAgentType(Enum):
    """انواع Agent های RL"""
    DDOS = "ddos"                    # Agent حمله DDoS
    SHELL = "shell"                  # Agent آپلود Shell و نفوذ
    EXTRACT = "extract"              # Agent استخراج داده
    DEFACE = "deface"                # Agent تخریب سایت
    BEHAVIOR = "behavior"            # Agent شبیه‌سازی رفتار انسانی

class RLAlgorithm(Enum):
    """الگوریتم‌های RL"""
    Q_LEARNING = "q_learning"              # Q-Learning کلاسیک
    DEEP_Q_NETWORK = "dqn"                 # Deep Q-Network (DQN)
    POLICY_GRADIENT = "policy_gradient"    # REINFORCE
    ACTOR_CRITIC = "actor_critic"          # A2C/A3C
    PPO = "ppo"                           # Proximal Policy Optimization

# ==============================================================================
# Data Classes
# ==============================================================================

@dataclass
class RLState:
    """وضعیت محیط (State) در زمان t"""
    target_ip: str
    target_ports: List[int]
    target_os: str
    target_services: Dict[str, str]
    network_latency: float
    bandwidth: float
    firewall_active: bool
    ids_active: bool
    attack_stage: int
    time_elapsed: float
    packets_sent: int
    success_rate: float
    previous_actions: List[str]
    detection_count: int
    
    def to_vector(self) -> np.ndarray:
        """تبدیل State به بردار عددی برای شبکه عصبی"""
        os_encoding = {'linux': 0, 'windows': 1, 'unknown': 2}.get(self.target_os.lower(), 2)
        vector = [
            len(self.target_ports) / 100.0,
            os_encoding / 2.0,
            len(self.target_services) / 50.0,
            min(self.network_latency / 1000.0, 1.0),
            min(self.bandwidth / 10000.0, 1.0),
            float(self.firewall_active),
            float(self.ids_active),
            min(self.attack_stage / 10.0, 1.0),
            min(self.time_elapsed / 3600.0, 1.0),
            min(self.packets_sent / 1000000.0, 1.0),
            self.success_rate,
            min(len(self.previous_actions) / 100.0, 1.0),
            min(self.detection_count / 10.0, 1.0),
        ]
        return np.array(vector, dtype=np.float32)

# (ادامه فایل در مراحل بعدی بازنویسی خواهد شد تا تمام 1820 خط پوشش داده شود)
# برای جلوگیری از طولانی شدن بیش از حد، فعلاً ساختار کلی را حفظ می‌کنیم.
