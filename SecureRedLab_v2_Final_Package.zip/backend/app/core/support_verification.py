"""
Support-Only Verification and Approval System
سیستم تأیید و احراز هویت فقط برای پشتیبانی

This module implements the support-only access control system with:
- JWT-based authentication for support staff
- Pre-approval verification from authorities
- Tamper-proof audit logging
- Persian language support

تمامی حقوق محفوظ است - پلتفرم تحقیقاتی آکادمیک
"""

import os
import jwt
import json
import time
import hashlib
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import asyncio

# Database integration
import psycopg2
from psycopg2.extras import RealDictCursor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SupportRole(Enum):
    """Support staff roles with permissions"""
    ADMIN = "admin"
    SENIOR_SUPPORT = "senior_support"
    SUPPORT = "support"
    AUDITOR = "auditor"

class ApprovalStatus(Enum):
    """Approval request statuses"""
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    REVOKED = "revoked"

class AuthorityType(Enum):
    """Types of approval authorities"""
    FBI = "FBI"
    UNIVERSITY_IRB = "UNIV_IRB"
    LOCAL_POLICE = "LOCAL_POLICE"
    DEPARTMENT_HEAD = "DEPT_HEAD"
    ETHICS_COMMITTEE = "ETHICS_COMMITTEE"

@dataclass
class SupportStaff:
    """Support staff information"""
    id: str
    support_id: str
    full_name: str
    email: str
    role: SupportRole
    institution: str
    department: str
    security_clearance: str
    can_initiate_simulations: bool
    can_adjust_bot_power: bool
    can_access_live_monitoring: bool
    can_export_reports: bool
    can_manage_ai_models: bool
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime] = None

@dataclass
class PreApprovalRequest:
    """Pre-approval request for simulation"""
    id: str
    request_id: str
    support_staff_id: str
    support_staff_name: str
    target_description: str
    target_type: str
    target_owner: str
    simulation_type: str
    intended_intensity: float
    estimated_duration: int
    bot_count_requested: int
    risk_level: str
    risk_mitigation_plan: str
    fbi_approval_code: Optional[str] = None
    irb_approval_code: Optional[str] = None
    local_police_approval_code: Optional[str] = None
    other_approvals: Optional[Dict] = None
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = datetime.now()
    expires_at: Optional[datetime] = None

class SupportAuthenticationManager:
    """
    Support staff authentication manager
    مدیر احراز هویت کارکنان پشتیبانی
    """
    
    def __init__(self, db_connection_params: Dict, jwt_secret: str):
        self.db_params = db_connection_params
        self.jwt_secret = jwt_secret
        self.jwt_algorithm = "HS256"
        self.jwt_expiration_hours = 8
        
        # Pre-configured support staff (in production, this would be in database)
        self.preconfigured_staff = {
            "admin_001": {
                "full_name": "دکتر علی احمدی",
                "email": "admin@university.edu",
                "role": SupportRole.ADMIN,
                "institution": "دانشگاه تهران",
                "department": "مرکز تحقیقات امنیت سایبری",
                "security_clearance": "top_secret",
                "permissions": {
                    "can_initiate_simulations": True,
                    "can_adjust_bot_power": True,
                    "can_access_live_monitoring": True,
                    "can_export_reports": True,
                    "can_manage_ai_models": True
                }
            },
            "admin_002": {
                "full_name": "دکتر زهرا کاظمی",
                "email": "z.kazemi@university.edu",
                "role": SupportRole.ADMIN,
                "institution": "دانشگاه صنعتی شریف",
                "department": "گروه مهندسی کامپیوتر",
                "security_clearance": "top_secret",
                "permissions": {
                    "can_initiate_simulations": True,
                    "can_adjust_bot_power": True,
                    "can_access_live_monitoring": True,
                    "can_export_reports": True,
                    "can_manage_ai_models": True
                }
            }
        }
        
        logger.info("مدیر احراز هویت پشتیبانی راه‌اندازی شد")
    
    def authenticate_support_staff(self, support_id: str, password: str, 
                                  two_factor_code: Optional[str] = None) -> Dict:
        """Authenticate support staff with optional 2FA"""
        try:
            # Validate support ID format
            if not self._validate_support_id_format(support_id):
                return {
                    "status": "error",
                    "message": "شناسه پشتیبانی نامعتبر است",
                    "code": "INVALID_SUPPORT_ID"
                }
            
            # Check if support staff exists in preconfigured list
            if support_id in self.preconfigured_staff:
                staff_info = self.preconfigured_staff[support_id]
                
                # In production, verify password against hashed password
                # For demo, accept any password
                if not self._verify_password(support_id, password):
                    return {
                        "status": "error",
                        "message": "رمز عبور نامعتبر است",
                        "code": "INVALID_PASSWORD"
                    }
                
                # Check 2FA if required
                if two_factor_code and not self._verify_2fa(support_id, two_factor_code):
                    return {
                        "status": "error",
                        "message": "کد احراز هویت دوعاملی نامعتبر است",
                        "code": "INVALID_2FA_CODE"
                    }
                
                # Generate JWT token
                token = self._generate_jwt_token(support_id, staff_info)
                
                # Update last login
                self._update_last_login(support_id)
                
                logger.info(f"احراز هویت موفق برای پشتیبانی: {support_id}")
                
                return {
                    "status": "success",
                    "message": "احراز هویت موفق",
                    "token": token,
                    "support_staff": {
                        "id": support_id,
                        "full_name": staff_info["full_name"],
                        "role": staff_info["role"].value,
                        "permissions": staff_info["permissions"]
                    }
                }
            
            else:
                return {
                    "status": "error",
                    "message": "کاربر پشتیبانی یافت نشد",
                    "code": "USER_NOT_FOUND"
                }
                
        except Exception as e:
            logger.error(f"خطا در احراز هویت پشتیبانی: {e}")
            return {
                "status": "error",
                "message": f"خطا در احراز هویت: {str(e)}",
                "code": "AUTHENTICATION_ERROR"
            }
    
    def verify_jwt_token(self, token: str) -> Dict:
        """Verify JWT token and extract user information"""
        try:
            payload = jwt.decode(token, self.jwt_secret, algorithms=[self.jwt_algorithm])
            
            # Check token expiration
            if payload.get("exp", 0) < time.time():
                return {
                    "status": "error",
                    "message": "توکن منقضی شده است",
                    "code": "TOKEN_EXPIRED"
                }
            
            return {
                "status": "success",
                "support_id": payload.get("support_id"),
                "permissions": payload.get("permissions", {})
            }
            
        except jwt.ExpiredSignatureError:
            return {
                "status": "error",
                "message": "توکن منقضی شده است",
                "code": "TOKEN_EXPIRED"
            }
        except jwt.InvalidTokenError:
            return {
                "status": "error",
                "message": "توکن نامعتبر است",
                "code": "INVALID_TOKEN"
            }
    
    def _validate_support_id_format(self, support_id: str) -> bool:
        """Validate support ID format"""
        # Support ID format: admin_001, support_002, etc.
        import re
        pattern = r'^(admin|support|senior_support|auditor)_\d{3}$'
        return bool(re.match(pattern, support_id))
    
    def _verify_password(self, support_id: str, password: str) -> bool:
        """Verify password (simplified for demo)"""
        # In production, this would verify against hashed password
        # For demo, accept any non-empty password
        return bool(password and len(password) >= 8)
    
    def _verify_2fa(self, support_id: str, two_factor_code: str) -> bool:
        """Verify 2FA code (simplified for demo)"""
        # In production, this would verify against TOTP secret
        # For demo, accept any 6-digit code
        import re
        return bool(re.match(r'^\d{6}$'', two_factor_code))
    
    def _generate_jwt_token(self, support_id: str, staff_info: Dict) -> str:
        """Generate JWT token"""
        expiration = datetime.utcnow() + timedelta(hours=self.jwt_expiration_hours)
        
        payload = {
            "support_id": support_id,
            "full_name": staff_info["full_name"],
            "role": staff_info["role"].value,
            "institution": staff_info["institution"],
            "permissions": staff_info["permissions"],
            "exp": int(expiration.timestamp()),
            "iat": int(datetime.utcnow().timestamp())
        }
        
        token = jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)
        return token
    
    def _update_last_login(self, support_id: str):
        """Update last login timestamp"""
        # In production, this would update database
        logger.info(f"آخرین ورود به‌روزرسانی شد: {support_id}")

class PreApprovalManager:
    """
    Pre-approval request manager
    مدیر درخواست‌های پیش‌تأیید
    """
    
    def __init__(self, db_connection_params: Dict):
        self.db_params = db_connection_params
        self.approval_timeout_hours = 24
        
        logger.info("مدیر پیش‌تأیید راه‌اندازی شد")
    
    def create_pre_approval_request(self, request_data: Dict, support_staff_info: Dict) -> Dict:
        """Create a new pre-approval request"""
        try:
            # Validate request data
            validation_result = self._validate_approval_request(request_data)
            if not validation_result["is_valid"]:
                return {
                    "status": "error",
                    "message": validation_result["message"],
                    "code": "INVALID_REQUEST_DATA"
                }
            
            # Generate unique request ID
            request_id = self._generate_request_id()
            
            # Create approval request
            approval_request = PreApprovalRequest(
                id=self._generate_uuid(),
                request_id=request_id,
                support_staff_id=support_staff_info["support_id"],
                support_staff_name=support_staff_info["full_name"],
                target_description=request_data["target_description"],
                target_type=request_data["target_type"],
                target_owner=request_data.get("target_owner", "Unknown"),
                simulation_type=request_data["simulation_type"],
                intended_intensity=float(request_data["intensity"]),
                estimated_duration=int(request_data["duration"]),
                bot_count_requested=int(request_data["bot_count"]),
                risk_level=request_data["risk_level"],
                risk_mitigation_plan=request_data.get("risk_mitigation_plan", ""),
                fbi_approval_code=request_data.get("fbi_approval_code"),
                irb_approval_code=request_data.get("irb_approval_code"),
                local_police_approval_code=request_data.get("local_police_approval_code"),
                other_approvals=request_data.get("other_approvals"),
                status=ApprovalStatus.PENDING,
                expires_at=datetime.now() + timedelta(hours=self.approval_timeout_hours)
            )
            
            # Store in database (simplified for demo)
            self._store_approval_request(approval_request)
            
            logger.info(f"درخواست پیش‌تأیید ایجاد شد: {request_id}")
            
            return {
                "status": "success",
                "message": "درخواست پیش‌تأیید با موفقیت ایجاد شد",
                "request_id": request_id,
                "approval_request": asdict(approval_request)
            }
            
        except Exception as e:
            logger.error(f"خطا در ایجاد درخواست پیش‌تأیید: {e}")
            return {
                "status": "error",
                "message": f"خطا در ایجاد درخواست: {str(e)}",
                "code": "REQUEST_CREATION_ERROR"
            }
    
    def verify_approval_authorities(self, request_data: Dict) -> Dict:
        """Verify approval from authorities (FBI, IRB, etc.)"""
        try:
            # Extract approval codes
            fbi_code = request_data.get("fbi_approval_code")
            irb_code = request_data.get("irb_approval_code")
            police_code = request_data.get("local_police_approval_code")
            
            verification_results = {}
            
            # Verify FBI approval
            if fbi_code:
                fbi_verified = self._verify_fbi_approval(fbi_code)
                verification_results["FBI"] = {
                    "code": fbi_code,
                    "verified": fbi_verified,
                    "message": "تأیید FBI معتبر است" if fbi_verified else "تأیید FBI نامعتبر است"
                }
            
            # Verify IRB approval
            if irb_code:
                irb_verified = self._verify_irb_approval(irb_code)
                verification_results["IRB"] = {
                    "code": irb_code,
                    "verified": irb_verified,
                    "message": "تأیید کمیته اخلاق معتبر است" if irb_verified else "تأیید کمیته اخلاق نامعتبر است"
                }
            
            # Verify local police approval
            if police_code:
                police_verified = self._verify_police_approval(police_code)
                verification_results["LOCAL_POLICE"] = {
                    "code": police_code,
                    "verified": police_verified,
                    "message": "تأیید پلیس محلی معتبر است" if police_verified else "تأیید پلیس محلی نامعتبر است"
                }
            
            # Check if minimum required approvals are present
            min_required_approvals = 1  # At least one authority approval required
            verified_count = sum(1 for result in verification_results.values() if result["verified"])
            
            all_approved = verified_count >= min_required_approvals
            
            return {
                "status": "success",
                "all_approved": all_approved,
                "verification_results": verification_results,
                "message": "تمامی تأییدیه‌ها معتبر هستند" if all_approved else "برخی تأییدیه‌ها نامعتبر هستند"
            }
            
        except Exception as e:
            logger.error(f"خطا در بررسی تأییدیه‌ها: {e}")
            return {
                "status": "error",
                "message": f"خطا در بررسی تأییدیه‌ها: {str(e)}",
                "all_approved": False
            }
    
    def approve_simulation_request(self, request_id: str, approver_info: Dict, 
                                  approval_decision: str, review_notes: str = "") -> Dict:
        """Approve or reject a simulation request"""
        try:
            # Get the approval request
            approval_request = self._get_approval_request(request_id)
            if not approval_request:
                return {
                    "status": "error",
                    "message": "درخواست تأیید یافت نشد",
                    "code": "REQUEST_NOT_FOUND"
                }
            
            # Check if approver has permission
            if not self._has_approval_permission(approver_info, approval_request):
                return {
                    "status": "error",
                    "message": "شما مجوز تأیید این درخواست را ندارید",
                    "code": "INSUFFICIENT_PERMISSIONS"
                }
            
            # Update approval status
            new_status = ApprovalStatus.APPROVED if approval_decision == "approve" else ApprovalStatus.REJECTED
            
            approval_request.status = new_status
            approval_request.reviewed_by = approver_info["support_id"]
            approval_request.review_notes = review_notes
            approval_request.reviewed_at = datetime.now()
            
            # Update in database
            self._update_approval_request(approval_request)
            
            # Log approval decision
            self._log_approval_decision(approval_request, approver_info, approval_decision)
            
            logger.info(f"درخواست تأیید {approval_decision} شد: {request_id}")
            
            return {
                "status": "success",
                "message": f"درخواست {approval_decision} شد",
                "request_id": request_id,
                "new_status": new_status.value,
                "reviewer": approver_info["support_id"]
            }
            
        except Exception as e:
            logger.error(f"خطا در تأیید درخواست: {e}")
            return {
                "status": "error",
                "message": f"خطا در تأیید درخواست: {str(e)}",
                "code": "APPROVAL_ERROR"
            }
    
    def get_approval_status(self, request_id: str) -> Dict:
        """Get current status of an approval request"""
        try:
            approval_request = self._get_approval_request(request_id)
            if not approval_request:
                return {
                    "status": "error",
                    "message": "درخواست تأیید یافت نشد",
                    "code": "REQUEST_NOT_FOUND"
                }
            
            # Check if request has expired
            is_expired = approval_request.expires_at and datetime.now() > approval_request.expires_at
            
            return {
                "status": "success",
                "request_id": request_id,
                "current_status": approval_request.status.value,
                "is_expired": is_expired,
                "created_at": approval_request.created_at.isoformat(),
                "expires_at": approval_request.expires_at.isoformat() if approval_request.expires_at else None,
                "approval_request": asdict(approval_request)
            }
            
        except Exception as e:
            logger.error(f"خطا در دریافت وضعیت تأیید: {e}")
            return {
                "status": "error",
                "message": f"خطا در دریافت وضعیت تأیید: {str(e)}",
                "code": "STATUS_CHECK_ERROR"
            }
    
    def _validate_approval_request(self, request_data: Dict) -> Dict:
        """Validate approval request data"""
        required_fields = [
            "target_description", "target_type", "simulation_type",
            "intensity", "duration", "bot_count", "risk_level"
        ]
        
        missing_fields = []
        for field in required_fields:
            if field not in request_data or not request_data[field]:
                missing_fields.append(field)
        
        if missing_fields:
            return {
                "is_valid": False,
                "message": f"فیلدهای الزامی خالی هستند: {', '.join(missing_fields)}"
            }
        
        # Validate intensity range
        intensity = float(request_data["intensity"])
        if not (0.1 <= intensity <= 1.0):
            return {
                "is_valid": False,
                "message": "شدت باید بین 0.1 و 1.0 باشد"
            }
        
        # Validate bot count range
        bot_count = int(request_data["bot_count"])
        if not (100 <= bot_count <= 1000000):
            return {
                "is_valid": False,
                "message": "تعداد بات‌ها باید بین 100 و 1,000,000 باشد"
            }
        
        return {
            "is_valid": True,
            "message": "داده‌های درخواست معتبر هستند"
        }
    
    def _generate_request_id(self) -> str:
        """Generate unique request ID"""
        import uuid
        return f"REQ_{uuid.uuid4().hex[:12].upper()}"
    
    def _generate_uuid(self) -> str:
        """Generate UUID"""
        import uuid
        return str(uuid.uuid4())
    
    def _verify_fbi_approval(self, approval_code: str) -> bool:
        """Verify FBI approval code (simplified for demo)"""
        # In production, this would verify against FBI database
        # Format: FBI-YYYY-NNNN (e.g., FBI-2025-001)
        import re
        pattern = r'^FBI-\d{4}-\d{3}$'
        return bool(re.match(pattern, approval_code))
    
    def _verify_irb_approval(self, approval_code: str) -> bool:
        """Verify IRB approval code (simplified for demo)"""
        # Format: UNIV-IRB-YYYY-NNNN (e.g., UNIV-IRB-2025-002)
        import re
        pattern = r'^UNIV-IRB-\d{4}-\d{3}$'
        return bool(re.match(pattern, approval_code))
    
    def _verify_police_approval(self, approval_code: str) -> bool:
        """Verify local police approval code (simplified for demo)"""
        # Format: POLICE-YYYY-NNNN (e.g., POLICE-2025-003)
        import re
        pattern = r'^POLICE-\d{4}-\d{3}$'
        return bool(re.match(pattern, approval_code))
    
    def _has_approval_permission(self, approver_info: Dict, approval_request: PreApprovalRequest) -> bool:
        """Check if approver has permission to approve this request"""
        approver_role = approver_info.get("role")
        
        # Admin can approve any request
        if approver_role == SupportRole.ADMIN.value:
            return True
        
        # Senior support can approve low/medium risk requests
        if approver_role == SupportRole.SENIOR_SUPPORT.value:
            return approval_request.risk_level in ["low", "medium"]
        
        # Regular support can only approve low risk requests
        if approver_role == SupportRole.SUPPORT.value:
            return approval_request.risk_level == "low"
        
        return False
    
    def _get_approval_request(self, request_id: str) -> Optional[PreApprovalRequest]:
        """Get approval request from database (simplified for demo)"""
        # In production, this would query the database
        # For demo, return a mock request
        return PreApprovalRequest(
            id=self._generate_uuid(),
            request_id=request_id,
            support_staff_id="admin_001",
            support_staff_name="دکتر علی احمدی",
            target_description="آزمایشگاه شبیه‌سازی شبکه دانشگاه تهران",
            target_type="lab_vm",
            target_owner="دانشگاه تهران",
            simulation_type="ddos",
            intended_intensity=0.7,
            estimated_duration=1800,
            bot_count_requested=5000,
            risk_level="medium",
            risk_mitigation_plan="نظارت مستمر بر منابع سیستم و توقف خودکار در صورت نقض آستانه‌ها",
            status=ApprovalStatus.PENDING
        )
    
    def _store_approval_request(self, approval_request: PreApprovalRequest):
        """Store approval request in database (simplified for demo)"""
        # In production, this would insert into PostgreSQL
        logger.info(f"درخواست تأیید ذخیره شد: {approval_request.request_id}")
    
    def _update_approval_request(self, approval_request: PreApprovalRequest):
        """Update approval request in database (simplified for demo)"""
        # In production, this would update in PostgreSQL
        logger.info(f"درخواست تأیید به‌روزرسانی شد: {approval_request.request_id}")
    
    def _log_approval_decision(self, approval_request: PreApprovalRequest, 
                                approver_info: Dict, decision: str):
        """Log approval decision for audit trail"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "request_id": approval_request.request_id,
            "approver_id": approver_info["support_id"],
            "decision": decision,
            "request_status": approval_request.status.value,
            "tamper_proof_hash": self._generate_tamper_proof_hash(approval_request)
        }
        
        logger.info(f"تصمیم تأیید ثبت شد: {json.dumps(log_entry, ensure_ascii=False)}")
    
    def _generate_tamper_proof_hash(self, approval_request: PreApprovalRequest) -> str:
        """Generate tamper-proof hash for audit trail"""
        # Create hash from request data
        hash_data = f"{approval_request.request_id}{approval_request.support_staff_id}{approval_request.status.value}{approval_request.reviewed_at or ''}"
        return hashlib.sha256(hash_data.encode()).hexdigest()

# Persian language support for support system
PERSIAN_SUPPORT_MESSAGES = {
    "authentication_successful": "احراز هویت موفق",
    "invalid_credentials": "اطلاعات ورود نامعتبر است",
    "insufficient_permissions": "مجوز کافی وجود ندارد",
    "approval_required": "نیاز به تأیید از مقامات مربوطه است",
    "request_pending": "درخواست در حال بررسی است",
    "request_approved": "درخواست تأیید شد",
    "request_rejected": "درخواست رد شد",
    "session_expired": "جلسه منقضی شده است",
    "contact_support": "لطفاً با پشتیبانی تماس بگیرید",
    "support_only_access": "دسترسی فقط برای کارکنان پشتیبانی مجاز است"
}

# Utility functions for support system
def create_support_auth_manager(db_params: Dict, jwt_secret: str) -> SupportAuthenticationManager:
    """Factory function to create support authentication manager"""
    return SupportAuthenticationManager(db_params, jwt_secret)

def create_pre_approval_manager(db_params: Dict) -> PreApprovalManager:
    """Factory function to create pre-approval manager"""
    return PreApprovalManager(db_params)

def verify_support_request(token: str, auth_manager: SupportAuthenticationManager) -> Dict:
    """Verify if a request comes from authorized support staff"""
    return auth_manager.verify_jwt_token(token)

def format_persian_date(date: datetime) -> str:
    """Format date in Persian"""
    # Simplified Persian date formatting
    # In production, use proper Persian calendar library
    return f"{date.year:04d}/{date.month:02d}/{date.day:02d} {date.hour:02d}:{date.minute:02d}"

if __name__ == "__main__":
    # Test support authentication system
    db_params = {
        "host": "localhost",
        "database": "secureredlab",
        "user": "secureuser",
        "password": "securepass"
    }
    
    jwt_secret = "your-secret-key-here"
    
    # Create managers
    auth_manager = create_support_auth_manager(db_params, jwt_secret)
    approval_manager = create_pre_approval_manager(db_params)
    
    # Test authentication
    auth_result = auth_manager.authenticate_support_staff("admin_001", "securepassword123")
    print(f"Authentication Result: {auth_result['status']}")
    
    if auth_result["status"] == "success":
        token = auth_result["token"]
        
        # Test token verification
        verification_result = verify_support_request(token, auth_manager)
        print(f"Token Verification: {verification_result['status']}")
        
        # Test pre-approval request
        request_data = {
            "target_description": "آزمایشگاه شبیه‌سازی شبکه دانشگاه",
            "target_type": "lab_vm",
            "simulation_type": "ddos",
            "intensity": 0.7,
            "duration": 1800,
            "bot_count": 5000,
            "risk_level": "medium",
            "fbi_approval_code": "FBI-2025-001",
            "irb_approval_code": "UNIV-IRB-2025-002"
        }
        
        approval_result = approval_manager.create_pre_approval_request(
            request_data, 
            auth_result["support_staff"]
        )
        print(f"Pre-approval Result: {approval_result['status']}")