"""
SecureRedLab Backend - FastAPI Application
==========================================
نسخه 2.0.0 - معماری ایجنتیک (Multi-Agent)

این فایل هسته اصلی بک‌اِند پروژه است که وظایف زیر را بر عهده دارد:
1. مدیریت درخواست‌های HTTP و WebSocket
2. یکپارچه‌سازی با سیستم ایجنتیک جدید (Multi-Agent System)
3. مدیریت خطاها و لاگ‌گذاری حرفه‌ای
4. اتصال به Redis برای ارتباطات Real-time
"""

import time
import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# وارد کردن ماژول‌های داخلی پروژه
from app.core.logging_system import LoggingSystem
from app.core.exception_handler import ExceptionHandler
from app.api.router import api_router, websocket_router
from app.utils.redis_pubsub import redis_pubsub_manager

# وارد کردن سیستم ایجنتیک جدید v2.0
from app.integration.legacy_integration import IntegratedAgentSystem, FastAPIIntegration

# مقداردهی اولیه سیستم لاگ‌گذاری
logging_system = LoggingSystem()
logger = logging_system.get_logger("fastapi")

# مقداردهی اولیه مدیریت خطاها
exception_handler = ExceptionHandler()

# ایجاد اپلیکیشن FastAPI
app = FastAPI(
    title="SecureRedLab API v2.0",
    description="سیستم تست نفوذ هوشمند مبتنی بر هوش مصنوعی ایجنتیک (Multi-Agent)",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# تنظیمات CORS برای اجازه دسترسی به فرانت‌اِند
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://*.pages.dev",    # Cloudflare Pages
        "http://localhost:3000",  # توسعه محلی (React/Next.js)
        "http://localhost:5173",  # سرور توسعه Vite
        "http://localhost:8080",  # پورت جایگزین
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# میان‌افزار (Middleware) برای لاگ‌گذاری تمام درخواست‌ها
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """لاگ‌گذاری تمام درخواست‌های HTTP ورودی و خروجی"""
    start_time = time.time()
    logger.info(f"درخواست ورودی: {request.method} {request.url.path}")
    
    try:
        response = await call_next(request)
        duration = time.time() - start_time
        logger.info(
            f"پاسخ خروجی: {request.method} {request.url.path} - "
            f"وضعیت: {response.status_code} - زمان اجرا: {duration:.3f} ثانیه"
        )
        return response
    except Exception as e:
        logger.error(f"خطا در پردازش درخواست: {str(e)}", exc_info=True)
        raise

# نقاط دسترسی (Endpoints) پایه
@app.get("/health")
async def health_check():
    """بررسی وضعیت سلامت سیستم"""
    return {
        "status": "healthy",
        "service": "SecureRedLab Agentic Backend",
        "version": "2.0.0",
        "agents_status": "active"
    }

@app.get("/")
async def root():
    """نقطه ورود اصلی API"""
    return {
        "message": "به API سیستم SecureRedLab v2.0 خوش آمدید",
        "version": "2.0.0",
        "docs": "/docs",
        "health": "/health"
    }

# ثبت مسیرهای API قدیمی (v1)
app.include_router(api_router, prefix="/api/v1")

# ثبت مسیرهای WebSocket
app.include_router(websocket_router, tags=["WebSocket"])

# --- یکپارچه‌سازی با سیستم ایجنتیک جدید v2.0 ---
# مقداردهی اولیه سیستم ایجنتیک
agent_system = IntegratedAgentSystem(vllm_endpoint="http://localhost:8000/v1")
# ثبت مسیرهای API جدید (v2) برای سیستم ایجنتیک
agent_api = FastAPIIntegration(agent_system)
agent_api.register_routes(app)

# مدیریت خطاهای سراسری
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """مدیریت تمام خطاهای پیش‌بینی نشده در سطح اپلیکیشن"""
    logger.error(f"خطای مدیریت نشده: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "یک خطای داخلی در سرور رخ داده است.",
            "detail": str(exc),
            "type": type(exc).__name__
        }
    )

# رویدادهای زمان شروع به کار (Startup)
@app.on_event("startup")
async def startup_event():
    """اجرا در زمان بالا آمدن اپلیکیشن"""
    logger.info("در حال راه‌اندازی بک‌اِند SecureRedLab v2.0...")
    
    # اتصال به Redis Pub/Sub
    try:
        await redis_pubsub_manager.connect()
        await redis_pubsub_manager.start_listening()
        logger.info("اتصال به Redis با موفقیت برقرار شد.")
    except Exception as e:
        logger.error(f"خطا در اتصال به Redis: {e}")
    
    logger.info("سیستم ایجنتیک (Multi-Agent) آماده به کار است.")
    logger.info("بک‌اِند با موفقیت اجرا شد!")

# رویدادهای زمان توقف (Shutdown)
@app.on_event("shutdown")
async def shutdown_event():
    """اجرا در زمان متوقف شدن اپلیکیشن"""
    logger.info("در حال متوقف کردن بک‌اِند SecureRedLab...")
    
    # قطع اتصال Redis
    try:
        await redis_pubsub_manager.disconnect()
        logger.info("اتصال Redis قطع شد.")
    except Exception as e:
        logger.error(f"خطا در قطع اتصال Redis: {e}")
    
    logger.info("بک‌اِند با موفقیت متوقف شد.")

if __name__ == "__main__":
    # اجرای سرور با استفاده از uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
