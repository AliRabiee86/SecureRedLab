"""
SecureRedLab Backend - Scan Schemas
Pydantic models for vulnerability scanning endpoints
"""

from pydantic import BaseModel, Field, IPvAnyAddress
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

from app.schemas.common import TimestampMixin, PaginatedResponse


# Enums
class ScanStatus(str, Enum):
    """Scan status enum"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ScanType(str, Enum):
    """Scan type enum"""
    PORT_SCAN = "port_scan"
    VULNERABILITY_SCAN = "vulnerability_scan"
    WEB_SCAN = "web_scan"
    FULL_SCAN = "full_scan"


# Request Schemas
class ScanCreate(BaseModel):
    """Scan creation request"""
    target: str = Field(..., description="Target IP or domain")
    scan_type: ScanType = Field(default=ScanType.PORT_SCAN)
    ports: Optional[str] = Field(None, description="Ports to scan (e.g., '80,443' or '1-1000')")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
    class Config:
        json_schema_extra = {
            "example": {
                "target": "192.168.1.1",
                "scan_type": "port_scan",
                "ports": "1-1000",
                "options": {
                    "timeout": 300,
                    "aggressive": False
                }
            }
        }


# Response Schemas
class ScanResponse(BaseModel, TimestampMixin):
    """Scan response model"""
    scan_id: str
    target: str
    scan_type: ScanType
    status: ScanStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: int = Field(default=0, ge=0, le=100)
    results: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    user_id: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "scan_id": "550e8400-e29b-41d4-a716-446655440000",
                "target": "192.168.1.1",
                "scan_type": "port_scan",
                "status": "completed",
                "created_at": "2025-12-21T10:00:00Z",
                "started_at": "2025-12-21T10:00:05Z",
                "completed_at": "2025-12-21T10:05:30Z",
                "progress": 100,
                "results": {
                    "open_ports": [22, 80, 443],
                    "services": {
                        "22": "SSH",
                        "80": "HTTP",
                        "443": "HTTPS"
                    }
                }
            }
        }


class ScanListResponse(PaginatedResponse):
    """List of scans response"""
    scans: List[ScanResponse]


class ScanResultsResponse(BaseModel):
    """Detailed scan results"""
    scan_id: str
    target: str
    results: Dict[str, Any]
    summary: Optional[Dict[str, Any]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "scan_id": "550e8400-e29b-41d4-a716-446655440000",
                "target": "192.168.1.1",
                "results": {
                    "open_ports": [22, 80, 443],
                    "services": {
                        "22": {"name": "SSH", "version": "OpenSSH 8.2"},
                        "80": {"name": "HTTP", "version": "Apache 2.4.41"},
                        "443": {"name": "HTTPS", "version": "Apache 2.4.41"}
                    },
                    "os_detection": "Linux 5.x",
                    "vulnerabilities": []
                },
                "summary": {
                    "total_ports_scanned": 1000,
                    "open_ports_count": 3,
                    "vulnerabilities_count": 0
                }
            }
        }


class ScanCancelRequest(BaseModel):
    """Scan cancellation request"""
    reason: Optional[str] = Field(None, max_length=500)
