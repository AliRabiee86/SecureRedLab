"""
SecureRedLab Backend - VLM (Vision Language Model) Schemas
Pydantic models for image analysis endpoints
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import List, Optional, Dict, Any
from enum import Enum


# Enums
class VLMTaskType(str, Enum):
    """VLM Task types"""
    SCREENSHOT_ANALYSIS = "screenshot_analysis"
    VULNERABILITY_DETECTION = "vulnerability_detection"
    CODE_SCREENSHOT = "code_screenshot"
    UI_ANALYSIS = "ui_analysis"
    OCR_EXTRACTION = "ocr_extraction"
    GENERAL = "general"


class OCRTier(str, Enum):
    """OCR Tier types"""
    HUNYUAN = "hunyuan"
    PADDLEOCR = "paddleocr"
    TESSERACT = "tesseract"
    NONE = "none"


# Request Schemas
class VLMProcessRequest(BaseModel):
    """VLM processing request (for URL)"""
    image_url: HttpUrl = Field(..., description="Public image URL")
    task_type: VLMTaskType = Field(default=VLMTaskType.GENERAL)
    prompt: Optional[str] = Field(None, description="Additional prompt for analysis")
    use_ocr_fallback: bool = Field(default=True, description="Use 3-Tier OCR Fallback if needed")
    
    class Config:
        json_schema_extra = {
            "example": {
                "image_url": "https://example.com/screenshot.png",
                "task_type": "screenshot_analysis",
                "prompt": "Identify any security vulnerabilities in this interface",
                "use_ocr_fallback": True
            }
        }


# Response Schemas
class VLMProcessResponse(BaseModel):
    """VLM processing response"""
    analysis: str
    model_used: str
    task_type: VLMTaskType
    ocr_text: Optional[str] = None
    ocr_tier_used: Optional[OCRTier] = None
    is_hallucination: bool = False
    confidence_score: float = Field(ge=0.0, le=1.0)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        json_schema_extra = {
            "example": {
                "analysis": "The screenshot shows a login page with potential SQL injection vulnerability...",
                "model_used": "InternVL3-78B",
                "task_type": "screenshot_analysis",
                "ocr_text": "Username: admin\nPassword: ******",
                "ocr_tier_used": "hunyuan",
                "is_hallucination": False,
                "confidence_score": 0.92,
                "metadata": {
                    "processing_time": 3.5,
                    "image_resolution": "1920x1080",
                    "vram_used": "42GB"
                }
            }
        }


class VLMModelInfo(BaseModel):
    """VLM Model information"""
    name: str
    type: str
    vram: str
    capabilities: List[str]
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "InternVL3-78B",
                "type": "complex",
                "vram": "48GB",
                "capabilities": ["complex_reasoning", "scene_understanding"]
            }
        }


class VLMModelsResponse(BaseModel):
    """Available VLM models response"""
    models: List[VLMModelInfo]
    total: int


class VLMStatsResponse(BaseModel):
    """VLM Engine statistics"""
    total_images_processed: int
    avg_processing_time: float
    ocr_fallback_rate: float = Field(ge=0.0, le=1.0)
    model_usage: Dict[str, int]
    ocr_tier_usage: Dict[str, int]
    
    class Config:
        json_schema_extra = {
            "example": {
                "total_images_processed": 500,
                "avg_processing_time": 3.2,
                "ocr_fallback_rate": 0.15,
                "model_usage": {
                    "complex": 300,
                    "document": 150,
                    "ocr": 50
                },
                "ocr_tier_usage": {
                    "hunyuan": 120,
                    "paddleocr": 25,
                    "tesseract": 5
                }
            }
        }


class VLMBatchProcessRequest(BaseModel):
    """VLM batch processing request"""
    image_urls: List[HttpUrl] = Field(..., max_items=10)
    task_type: VLMTaskType = Field(default=VLMTaskType.GENERAL)
    prompt: Optional[str] = None
    use_ocr_fallback: bool = True
    
    class Config:
        json_schema_extra = {
            "example": {
                "image_urls": [
                    "https://example.com/screen1.png",
                    "https://example.com/screen2.png"
                ],
                "task_type": "screenshot_analysis",
                "use_ocr_fallback": True
            }
        }


class VLMBatchProcessResponse(BaseModel):
    """VLM batch processing response"""
    results: List[VLMProcessResponse]
    total: int
    successful: int
    failed: int
