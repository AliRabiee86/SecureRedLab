"""
SecureRedLab Backend - Common Schemas
Base Pydantic models used across multiple endpoints
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class BaseResponse(BaseModel):
    """Base response model"""
    success: bool = True
    message: Optional[str] = None


class PaginationParams(BaseModel):
    """Pagination parameters"""
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)


class PaginatedResponse(BaseModel):
    """Paginated response base"""
    total: int
    page: int
    page_size: int
    pages: int
    
    @classmethod
    def create(cls, items, total: int, page: int, page_size: int):
        """Create paginated response"""
        pages = (total + page_size - 1) // page_size
        return {
            "items": items,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": pages
        }


class TimestampMixin(BaseModel):
    """Timestamp mixin for models"""
    created_at: datetime
    updated_at: Optional[datetime] = None


class UserBaseMixin(BaseModel):
    """User base information mixin"""
    user_id: str
    username: str


# Common status enums (can be imported by other schemas)
class Status(BaseModel):
    """Generic status model"""
    status: str
    message: Optional[str] = None
