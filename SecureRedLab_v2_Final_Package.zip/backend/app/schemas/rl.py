"""
SecureRedLab Backend - RL (Reinforcement Learning) Schemas
Pydantic models for RL engine endpoints
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

from app.schemas.common import TimestampMixin


# Enums
class RLAgentType(str, Enum):
    """RL Agent types"""
    DDOS = "ddos"
    SHELL = "shell"
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    DATA_EXTRACTION = "data_extraction"


class RLEpisodeStatus(str, Enum):
    """RL Episode status"""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


# Request Schemas
class RLTrainRequest(BaseModel):
    """RL Training request"""
    agent_type: RLAgentType
    episodes: int = Field(default=10, ge=1, le=1000)
    batch_size: int = Field(default=32, ge=8, le=256)
    learning_rate: Optional[float] = Field(default=0.001, ge=0.0001, le=0.1)
    
    class Config:
        json_schema_extra = {
            "example": {
                "agent_type": "ddos",
                "episodes": 100,
                "batch_size": 32,
                "learning_rate": 0.001
            }
        }


# Response Schemas
class RLEpisodeResponse(BaseModel, TimestampMixin):
    """RL Episode response"""
    episode_id: str
    agent_type: RLAgentType
    status: RLEpisodeStatus
    total_reward: float = 0.0
    steps: int = 0
    success_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    created_at: datetime
    completed_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "episode_id": "episode-550e8400",
                "agent_type": "ddos",
                "status": "completed",
                "total_reward": 0.85,
                "steps": 45,
                "success_rate": 0.9,
                "created_at": "2025-12-21T10:00:00Z",
                "completed_at": "2025-12-21T10:15:00Z"
            }
        }


class RLStatsResponse(BaseModel):
    """RL Statistics response"""
    total_episodes: int
    total_experiences: int
    avg_reward: float
    success_rate: float
    agent_stats: Dict[str, Any]
    
    class Config:
        json_schema_extra = {
            "example": {
                "total_episodes": 1000,
                "total_experiences": 45000,
                "avg_reward": 0.75,
                "success_rate": 0.85,
                "agent_stats": {
                    "ddos": {"episodes": 250, "avg_reward": 0.8},
                    "shell": {"episodes": 300, "avg_reward": 0.75}
                }
            }
        }


class RLModelResponse(BaseModel):
    """RL Model response"""
    agent_type: RLAgentType
    version: str
    trained_episodes: int
    avg_reward: float
    success_rate: float
    created_at: datetime
    file_size_mb: Optional[float] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "agent_type": "ddos",
                "version": "1.2.0",
                "trained_episodes": 1000,
                "avg_reward": 0.85,
                "success_rate": 0.9,
                "created_at": "2025-12-21T00:00:00Z",
                "file_size_mb": 15.3
            }
        }


class RLModelListResponse(BaseModel):
    """List of RL models"""
    models: List[RLModelResponse]
    total: int


class RLTrainJobResponse(BaseModel):
    """RL Training job response"""
    job_id: str
    agent_type: RLAgentType
    episodes: int
    status: str
    created_at: datetime
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "train-job-123",
                "agent_type": "ddos",
                "episodes": 100,
                "status": "queued",
                "created_at": "2025-12-21T10:00:00Z"
            }
        }
