"""
SecureRedLab Backend - AI Generation Schemas
Pydantic models for LLM text generation endpoints
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum


# Enums
class AITaskType(str, Enum):
    """AI Task types"""
    VULNERABILITY_ANALYSIS = "vulnerability_analysis"
    EXPLOIT_GENERATION = "exploit_generation"
    PAYLOAD_OPTIMIZATION = "payload_optimization"
    REPORT_GENERATION = "report_generation"
    CODE_ANALYSIS = "code_analysis"
    GENERAL = "general"


class AIModelType(str, Enum):
    """AI Model types"""
    REASONING = "reasoning"
    NON_REASONING = "non_reasoning"
    AUTO = "auto"


# Request Schemas
class AIGenerateRequest(BaseModel):
    """AI generation request"""
    prompt: str = Field(..., min_length=1, max_length=10000)
    task_type: AITaskType = Field(default=AITaskType.GENERAL)
    model_type: AIModelType = Field(default=AIModelType.AUTO)
    max_tokens: Optional[int] = Field(default=2000, ge=100, le=8000)
    temperature: Optional[float] = Field(default=0.7, ge=0.0, le=2.0)
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
    class Config:
        json_schema_extra = {
            "example": {
                "prompt": "Analyze port 80 running Apache 2.4.41 for potential vulnerabilities",
                "task_type": "vulnerability_analysis",
                "model_type": "reasoning",
                "max_tokens": 2000,
                "temperature": 0.7
            }
        }


class AIValidateRequest(BaseModel):
    """AI output validation request"""
    output: str = Field(..., min_length=1)
    task_type: AITaskType = Field(default=AITaskType.GENERAL)


# Response Schemas
class AIGenerateResponse(BaseModel):
    """AI generation response"""
    output: str
    model_used: str
    task_type: AITaskType
    tokens_used: int
    is_hallucination: bool = False
    confidence_score: float = Field(ge=0.0, le=1.0)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        json_schema_extra = {
            "example": {
                "output": "Apache 2.4.41 has several known vulnerabilities...",
                "model_used": "Qwen3-235B-A22B",
                "task_type": "vulnerability_analysis",
                "tokens_used": 450,
                "is_hallucination": False,
                "confidence_score": 0.95,
                "metadata": {
                    "processing_time": 2.3,
                    "anti_hallucination_layers_passed": 7
                }
            }
        }


class AIValidateResponse(BaseModel):
    """AI validation response"""
    is_valid: bool
    is_hallucination: bool
    confidence_score: float = Field(ge=0.0, le=1.0)
    issues: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    
    class Config:
        json_schema_extra = {
            "example": {
                "is_valid": True,
                "is_hallucination": False,
                "confidence_score": 0.95,
                "issues": [],
                "recommendations": ["Consider adding more context"]
            }
        }


class AIModelInfo(BaseModel):
    """AI Model information"""
    name: str
    type: str
    size: str
    capabilities: List[str]
    vram_required: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "Qwen3-235B-A22B",
                "type": "reasoning",
                "size": "235B",
                "capabilities": ["reasoning", "complex_analysis"],
                "vram_required": "80GB"
            }
        }


class AIModelsResponse(BaseModel):
    """Available AI models response"""
    models: List[AIModelInfo]
    total: int


class AIStatsResponse(BaseModel):
    """AI Engine statistics"""
    total_generations: int
    avg_tokens_per_generation: float
    hallucination_rate: float = Field(ge=0.0, le=1.0)
    model_usage: Dict[str, int]
    
    class Config:
        json_schema_extra = {
            "example": {
                "total_generations": 1000,
                "avg_tokens_per_generation": 450.5,
                "hallucination_rate": 0.03,
                "model_usage": {
                    "reasoning": 600,
                    "non_reasoning": 400
                }
            }
        }
