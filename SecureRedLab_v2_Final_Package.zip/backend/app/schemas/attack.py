"""
SecureRedLab Backend - Attack Schemas
Pydantic models for attack execution endpoints
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

from app.schemas.common import TimestampMixin, PaginatedResponse


# Enums
class AttackStatus(str, Enum):
    """Attack status enum"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


class AttackType(str, Enum):
    """Attack type enum"""
    DDOS = "ddos"
    SHELL_UPLOAD = "shell_upload"
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    DATA_EXTRACTION = "data_extraction"


# Request Schemas
class AttackCreate(BaseModel):
    """Attack creation request"""
    target: str = Field(..., description="Target IP or URL")
    attack_type: AttackType
    parameters: Optional[Dict[str, Any]] = Field(default_factory=dict)
    use_rl: bool = Field(default=True, description="Use RL Engine for optimization")
    
    class Config:
        json_schema_extra = {
            "example": {
                "target": "http://testphp.vulnweb.com",
                "attack_type": "sql_injection",
                "parameters": {
                    "technique": "union",
                    "timeout": 300
                },
                "use_rl": True
            }
        }


# Response Schemas
class AttackResponse(BaseModel, TimestampMixin):
    """Attack response model"""
    attack_id: str
    target: str
    attack_type: AttackType
    status: AttackStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: int = Field(default=0, ge=0, le=100)
    results: Optional[Dict[str, Any]] = None
    rl_episode_id: Optional[str] = None
    error: Optional[str] = None
    user_id: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "attack_id": "550e8400-e29b-41d4-a716-446655440000",
                "target": "http://testphp.vulnweb.com",
                "attack_type": "sql_injection",
                "status": "completed",
                "created_at": "2025-12-21T10:00:00Z",
                "started_at": "2025-12-21T10:00:05Z",
                "completed_at": "2025-12-21T10:15:30Z",
                "progress": 100,
                "results": {
                    "success": True,
                    "vulnerabilities_found": 2
                },
                "rl_episode_id": "episode-123"
            }
        }


class AttackListResponse(PaginatedResponse):
    """List of attacks response"""
    attacks: List[AttackResponse]


class AttackResultsResponse(BaseModel):
    """Detailed attack results"""
    attack_id: str
    target: str
    results: Dict[str, Any]
    rl_metrics: Optional[Dict[str, Any]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "attack_id": "550e8400-e29b-41d4-a716-446655440000",
                "target": "http://testphp.vulnweb.com",
                "results": {
                    "success": True,
                    "duration_seconds": 930,
                    "actions_taken": ["scan", "inject", "exploit"],
                    "data_extracted": {"users": 10, "tables": 5}
                },
                "rl_metrics": {
                    "total_reward": 0.85,
                    "exploration_rate": 0.1,
                    "success_rate": 0.9,
                    "steps": 45
                }
            }
        }


class AttackStopRequest(BaseModel):
    """Attack stop request"""
    reason: Optional[str] = Field(None, max_length=500)
