"""
SecureRedLab Backend - Celery Application
Async task queue for long-running operations
"""

from celery import Celery
from app.config import settings

# Create Celery app
celery_app = Celery(
    "securedredlab",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.tasks.execution_tasks",
        "app.tasks.ai_tasks",
        "app.tasks.rl_tasks",
        "app.tasks.report_tasks",
    ]
)

# Celery configuration
celery_app.conf.update(
    # Task settings
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    
    # Result backend settings
    result_expires=3600,  # 1 hour
    result_backend_transport_options={
        "master_name": "mymaster",
        "retry_policy": {
            "timeout": 5.0
        }
    },
    
    # Task routing
    task_routes={
        "app.tasks.execution_tasks.*": {"queue": "execution"},
        "app.tasks.ai_tasks.*": {"queue": "ai"},
        "app.tasks.rl_tasks.*": {"queue": "rl"},
        "app.tasks.report_tasks.*": {"queue": "reports"},
    },
    
    # Worker settings
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
    
    # Task execution settings
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_track_started=True,
    
    # Task time limits
    task_soft_time_limit=300,  # 5 minutes
    task_time_limit=600,  # 10 minutes
)


@celery_app.task(bind=True)
def debug_task(self):
    """Debug task for testing"""
    return f"Request: {self.request!r}"


if __name__ == "__main__":
    celery_app.start()
