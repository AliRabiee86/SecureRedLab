"""
SecureRedLab Backend - Execution Tasks with Real-time Progress
Phase 7.1: Enhanced with BaseExecutor integration

Celery tasks for security tool execution with real-time WebSocket updates
"""

from celery import Task
from app.tasks.celery_app import celery_app
from app.utils.celery_helpers import (
    publish_progress_update,
    publish_status_update,
    publish_result_update,
    publish_error
)
from app.execution.nmap_executor import NmapExecutor  # Real Nmap executor (Phase 7.2)
from app.execution.metasploit_executor import MetasploitExecutor  # Real Metasploit executor (Phase 7.3)
from app.execution.sqlmap_executor import SQLMapExecutor  # Real SQLMap executor (Phase 7.4)
from app.execution.nuclei_executor import NucleiExecutor  # Real Nuclei executor (Phase 7.5)
import logging
import asyncio

logger = logging.getLogger(__name__)


class ExecutionTask(Task):
    """Base task for execution operations with error handling"""
    
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        """Handle task failure"""
        logger.error(f"Task {task_id} failed: {exc}")
        
        # Extract ID from args
        entity_id = args[0] if args else None
        if entity_id:
            # Publish error via Redis Pub/Sub
            asyncio.run(publish_error(
                task_id=task_id,
                entity_id=entity_id,
                error=str(exc)
            ))
    
    def on_success(self, retval, task_id, args, kwargs):
        """Handle task success"""
        logger.info(f"Task {task_id} completed successfully")


def _create_progress_callback(task_id: str, entity_id: str):
    """
    Create progress callback for BaseExecutor
    
    Args:
        task_id: Celery task ID
        entity_id: Scan/Attack ID
        
    Returns:
        Async callback function
    """
    async def callback(progress: int, message: str):
        """Progress callback that publishes to Redis"""
        await publish_progress_update(
            task_id=task_id,
            entity_id=entity_id,
            progress=progress,
            message=message
        )
    
    return callback


@celery_app.task(bind=True, base=ExecutionTask, max_retries=3, default_retry_delay=60)
def run_nmap_scan(self, scan_id: str, target: str, ports: str = "1-1000", scan_type: str = "syn") -> dict:
    """
    Execute Nmap scan with real-time progress updates
    
    Args:
        scan_id: Scan UUID
        target: Target IP or domain
        ports: Port range (e.g., "1-1000" or "80,443")
        scan_type: Scan type (syn, tcp, udp)
        
    Returns:
        dict: Scan results
    """
    try:
        logger.info(f"[NMAP] Starting scan {scan_id} for {target} (ports: {ports})")
        
        # Publish status update: started
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=scan_id,
            status="running",
            message=f"Starting Nmap scan on {target}"
        ))
        
        # Create progress callback
        progress_callback = _create_progress_callback(self.request.id, scan_id)
        
        # Execute Nmap scan
        executor = NmapExecutor(progress_callback=progress_callback)
        results = asyncio.run(executor.execute(
            target=target,
            ports=ports,
            scan_type=scan_type,
            scan_id=scan_id
        ))
        
        # Publish result update
        asyncio.run(publish_result_update(
            task_id=self.request.id,
            entity_id=scan_id,
            result=results
        ))
        
        # Publish status update: completed
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=scan_id,
            status="completed",
            message="Nmap scan completed successfully"
        ))
        
        logger.info(f"[NMAP] Scan {scan_id} completed successfully")
        return results
    
    except Exception as exc:
        logger.error(f"[NMAP] Scan {scan_id} failed: {exc}")
        
        # Publish error
        asyncio.run(publish_error(
            task_id=self.request.id,
            entity_id=scan_id,
            error=str(exc)
        ))
        
        # Retry
        self.retry(exc=exc)


@celery_app.task(bind=True, base=ExecutionTask, max_retries=3, default_retry_delay=60)
def run_metasploit_exploit(
    self, 
    attack_id: str, 
    target: str, 
    module: str,
    payload: str = None,
    options: dict = None
) -> dict:
    """
    Execute Metasploit exploit with real-time progress updates
    
    Args:
        attack_id: Attack UUID
        target: Target IP or URL
        module: Metasploit module name
        payload: Payload to use
        options: Module options
        
    Returns:
        dict: Attack results
    """
    try:
        logger.info(f"[METASPLOIT] Starting attack {attack_id} against {target} (module: {module})")
        
        # Publish status update: started
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=attack_id,
            status="running",
            message=f"Starting Metasploit exploit on {target}"
        ))
        
        # Create progress callback
        progress_callback = _create_progress_callback(self.request.id, attack_id)
        
        # Execute Metasploit exploit
        executor = MetasploitExecutor(progress_callback=progress_callback)
        results = asyncio.run(executor.execute(
            target=target,
            module=module,
            payload=payload,
            options=options or {},
            attack_id=attack_id
        ))
        
        # Publish result update
        asyncio.run(publish_result_update(
            task_id=self.request.id,
            entity_id=attack_id,
            result=results
        ))
        
        # Publish status update: completed
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=attack_id,
            status="completed",
            message="Metasploit exploit completed"
        ))
        
        logger.info(f"[METASPLOIT] Attack {attack_id} completed")
        return results
    
    except Exception as exc:
        logger.error(f"[METASPLOIT] Attack {attack_id} failed: {exc}")
        
        # Publish error
        asyncio.run(publish_error(
            task_id=self.request.id,
            entity_id=attack_id,
            error=str(exc)
        ))
        
        # Retry
        self.retry(exc=exc)


@celery_app.task(bind=True, base=ExecutionTask, max_retries=3, default_retry_delay=60)
def run_sqlmap_injection(
    self, 
    attack_id: str, 
    target: str, 
    parameters: list = None,
    technique: str = "BEUSTQ",
    level: int = 1,
    risk: int = 1
) -> dict:
    """
    Execute SQLMap SQL injection test with real-time progress updates
    
    Args:
        attack_id: Attack UUID
        target: Target URL
        parameters: Parameters to test
        technique: SQLMap techniques
        level: Test level (1-5)
        risk: Risk level (1-3)
        
    Returns:
        dict: Attack results
    """
    try:
        logger.info(f"[SQLMAP] Starting attack {attack_id} against {target}")
        
        # Publish status update: started
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=attack_id,
            status="running",
            message=f"Starting SQLMap injection test on {target}"
        ))
        
        # Create progress callback
        progress_callback = _create_progress_callback(self.request.id, attack_id)
        
        # Execute SQLMap injection
        executor = SQLMapExecutor(progress_callback=progress_callback)
        results = asyncio.run(executor.execute(
            target=target,
            parameters=parameters,
            technique=technique,
            level=level,
            risk=risk,
            attack_id=attack_id
        ))
        
        # Publish result update
        asyncio.run(publish_result_update(
            task_id=self.request.id,
            entity_id=attack_id,
            result=results
        ))
        
        # Publish status update: completed
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=attack_id,
            status="completed",
            message="SQLMap injection test completed"
        ))
        
        logger.info(f"[SQLMAP] Attack {attack_id} completed")
        return results
    
    except Exception as exc:
        logger.error(f"[SQLMAP] Attack {attack_id} failed: {exc}")
        
        # Publish error
        asyncio.run(publish_error(
            task_id=self.request.id,
            entity_id=attack_id,
            error=str(exc)
        ))
        
        # Retry
        self.retry(exc=exc)


@celery_app.task(bind=True, base=ExecutionTask, max_retries=3, default_retry_delay=60)
def run_nuclei_scan(
    self, 
    scan_id: str, 
    target: str, 
    templates: list = None,
    severity: str = None,
    tags: list = None
) -> dict:
    """
    Execute Nuclei vulnerability scan with real-time progress updates
    
    Args:
        scan_id: Scan UUID
        target: Target URL
        templates: Nuclei templates to use
        severity: Filter by severity
        tags: Filter by tags
        
    Returns:
        dict: Scan results
    """
    try:
        logger.info(f"[NUCLEI] Starting scan {scan_id} for {target}")
        
        # Publish status update: started
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=scan_id,
            status="running",
            message=f"Starting Nuclei vulnerability scan on {target}"
        ))
        
        # Create progress callback
        progress_callback = _create_progress_callback(self.request.id, scan_id)
        
        # Execute Nuclei scan
        executor = NucleiExecutor(progress_callback=progress_callback)
        results = asyncio.run(executor.execute(
            target=target,
            templates=templates,
            severity=severity,
            tags=tags,
            scan_id=scan_id
        ))
        
        # Publish result update
        asyncio.run(publish_result_update(
            task_id=self.request.id,
            entity_id=scan_id,
            result=results
        ))
        
        # Publish status update: completed
        asyncio.run(publish_status_update(
            task_id=self.request.id,
            entity_id=scan_id,
            status="completed",
            message="Nuclei vulnerability scan completed"
        ))
        
        logger.info(f"[NUCLEI] Scan {scan_id} completed")
        return results
    
    except Exception as exc:
        logger.error(f"[NUCLEI] Scan {scan_id} failed: {exc}")
        
        # Publish error
        asyncio.run(publish_error(
            task_id=self.request.id,
            entity_id=scan_id,
            error=str(exc)
        ))
        
        # Retry
        self.retry(exc=exc)


# Export all tasks
__all__ = [
    "run_nmap_scan",
    "run_metasploit_exploit",
    "run_sqlmap_injection",
    "run_nuclei_scan"
]
