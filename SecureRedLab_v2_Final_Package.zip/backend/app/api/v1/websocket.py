"""
WebSocket Endpoints
Real-time updates for scans, attacks, and RL episodes
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException
from typing import Dict, Any
import logging
import asyncio

from app.utils.websocket import connection_manager
from app.utils.redis_pubsub import redis_pubsub_manager

logger = logging.getLogger(__name__)

router = APIRouter()


@router.websocket("/ws/scans/{scan_id}")
async def websocket_scan_updates(
    websocket: WebSocket,
    scan_id: str
):
    """
    WebSocket endpoint for real-time scan updates.
    
    Client receives:
    - connection_established: When connection is accepted
    - progress_update: Scan progress updates (0-100%)
    - status_update: Scan status changes
    - result_update: Scan results (vulnerabilities found)
    - error: Error messages
    """
    await connection_manager.connect(websocket, "scans", scan_id)
    
    try:
        # Subscribe to Redis channel for this scan
        async def redis_callback(message: Dict[str, Any]):
            """Forward Redis messages to WebSocket"""
            await connection_manager.broadcast_to_resource(
                "scans",
                scan_id,
                message
            )
        
        await redis_pubsub_manager.subscribe(f"scans:{scan_id}", redis_callback)
        
        # Keep connection alive and handle client messages
        while True:
            try:
                # Receive message from client (optional - for client → server communication)
                data = await websocket.receive_text()
                
                # Echo back or handle commands
                await websocket.send_json({
                    "type": "echo",
                    "message": f"Received: {data}"
                })
                
            except WebSocketDisconnect:
                logger.info(f"Client disconnected from scan {scan_id}")
                break
            except Exception as e:
                logger.error(f"Error in scan WebSocket: {e}")
                break
    
    finally:
        # Cleanup
        await redis_pubsub_manager.unsubscribe(f"scans:{scan_id}")
        connection_manager.disconnect(websocket)


@router.websocket("/ws/attacks/{attack_id}")
async def websocket_attack_updates(
    websocket: WebSocket,
    attack_id: str
):
    """
    WebSocket endpoint for real-time attack updates.
    
    Client receives:
    - connection_established: When connection is accepted
    - progress_update: Attack progress updates
    - status_update: Attack status changes
    - result_update: Attack results
    - error: Error messages
    """
    await connection_manager.connect(websocket, "attacks", attack_id)
    
    try:
        # Subscribe to Redis channel for this attack
        async def redis_callback(message: Dict[str, Any]):
            """Forward Redis messages to WebSocket"""
            await connection_manager.broadcast_to_resource(
                "attacks",
                attack_id,
                message
            )
        
        await redis_pubsub_manager.subscribe(f"attacks:{attack_id}", redis_callback)
        
        # Keep connection alive
        while True:
            try:
                data = await websocket.receive_text()
                
                # Handle client commands
                await websocket.send_json({
                    "type": "echo",
                    "message": f"Received: {data}"
                })
                
            except WebSocketDisconnect:
                logger.info(f"Client disconnected from attack {attack_id}")
                break
            except Exception as e:
                logger.error(f"Error in attack WebSocket: {e}")
                break
    
    finally:
        # Cleanup
        await redis_pubsub_manager.unsubscribe(f"attacks:{attack_id}")
        connection_manager.disconnect(websocket)


@router.websocket("/ws/rl/{episode_id}")
async def websocket_rl_updates(
    websocket: WebSocket,
    episode_id: str
):
    """
    WebSocket endpoint for real-time RL episode updates.
    
    Client receives:
    - connection_established: When connection is accepted
    - progress_update: Episode progress updates
    - status_update: Episode status changes
    - reward_update: Reward updates
    - result_update: Episode results
    - error: Error messages
    """
    await connection_manager.connect(websocket, "rl", episode_id)
    
    try:
        # Subscribe to Redis channel for this episode
        async def redis_callback(message: Dict[str, Any]):
            """Forward Redis messages to WebSocket"""
            await connection_manager.broadcast_to_resource(
                "rl",
                episode_id,
                message
            )
        
        await redis_pubsub_manager.subscribe(f"rl:{episode_id}", redis_callback)
        
        # Keep connection alive
        while True:
            try:
                data = await websocket.receive_text()
                
                # Handle client commands
                await websocket.send_json({
                    "type": "echo",
                    "message": f"Received: {data}"
                })
                
            except WebSocketDisconnect:
                logger.info(f"Client disconnected from RL episode {episode_id}")
                break
            except Exception as e:
                logger.error(f"Error in RL WebSocket: {e}")
                break
    
    finally:
        # Cleanup
        await redis_pubsub_manager.unsubscribe(f"rl:{episode_id}")
        connection_manager.disconnect(websocket)


@router.get("/ws/stats")
async def websocket_stats():
    """
    Get WebSocket connection statistics.
    
    Returns:
        Connection statistics including total connections and breakdown by resource type
    """
    return connection_manager.get_stats()
