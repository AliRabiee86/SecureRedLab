"""
SecureRedLab Backend - AI Generation Endpoints
Handles LLM text generation for security analysis
"""

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from enum import Enum

from app.dependencies import get_current_user, get_ai_engine

router = APIRouter()


# Enums
class AITaskType(str, Enum):
    """AI Task types"""
    VULNERABILITY_ANALYSIS = "vulnerability_analysis"
    EXPLOIT_GENERATION = "exploit_generation"
    PAYLOAD_OPTIMIZATION = "payload_optimization"
    REPORT_GENERATION = "report_generation"
    CODE_ANALYSIS = "code_analysis"
    GENERAL = "general"


class AIModelType(str, Enum):
    """AI Model types"""
    REASONING = "reasoning"
    NON_REASONING = "non_reasoning"
    AUTO = "auto"


# Pydantic Models
class AIGenerateRequest(BaseModel):
    """AI generation request"""
    prompt: str = Field(..., min_length=1, max_length=10000)
    task_type: AITaskType = Field(default=AITaskType.GENERAL)
    model_type: AIModelType = Field(default=AIModelType.AUTO)
    max_tokens: Optional[int] = Field(default=2000, ge=100, le=8000)
    temperature: Optional[float] = Field(default=0.7, ge=0.0, le=2.0)
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)


class AIGenerateResponse(BaseModel):
    """AI generation response"""
    output: str
    model_used: str
    task_type: AITaskType
    tokens_used: int
    is_hallucination: bool = False
    confidence_score: float = Field(ge=0.0, le=1.0)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AIModelsResponse(BaseModel):
    """Available AI models response"""
    models: List[Dict[str, Any]]
    total: int


# Endpoints
@router.post("/generate", response_model=AIGenerateResponse)
async def generate_with_ai(
    request: AIGenerateRequest,
    current_user: dict = Depends(get_current_user),
    ai_engine = Depends(get_ai_engine)
):
    """
    Generate text using AI (LLM)
    
    This endpoint uses the Offline AI Core with:
    - 4 LLM Models (Qwen, GLM, DeepSeek)
    - Dual-Track Router (Reasoning/Non-Reasoning)
    - 7-Layer Anti-Hallucination System
    
    Args:
        request: Generation request
        current_user: Current authenticated user
        ai_engine: AI Engine instance
        
    Returns:
        AIGenerateResponse: Generated text with metadata
        
    Raises:
        HTTPException: If generation fails
    """
    try:
        if not ai_engine:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="AI Engine not available"
            )
        
        # Map task type to AI model type
        task_type_map = {
            AITaskType.VULNERABILITY_ANALYSIS: "REASONING",
            AITaskType.EXPLOIT_GENERATION: "NON_REASONING",
            AITaskType.PAYLOAD_OPTIMIZATION: "REASONING",
            AITaskType.REPORT_GENERATION: "NON_REASONING",
            AITaskType.CODE_ANALYSIS: "REASONING",
            AITaskType.GENERAL: "AUTO"
        }
        
        # Get AI model type
        from app.ai.offline_core import AIModelType as OfflineAIModelType
        
        if request.model_type == AIModelType.AUTO:
            model_type_str = task_type_map.get(request.task_type, "AUTO")
        else:
            model_type_str = request.model_type.value.upper()
        
        # Map to offline_core enum
        model_type_enum = getattr(OfflineAIModelType, model_type_str, OfflineAIModelType.QWEN_14B)
        
        # Generate using AI Engine
        result = await ai_engine.generate(
            prompt=request.prompt,
            model_type=model_type_enum,
            max_tokens=request.max_tokens,
            temperature=request.temperature,
            task_type=request.task_type.value,
            context=request.context
        )
        
        if not result or result.get("status") != "success":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="AI generation failed"
            )
        
        return AIGenerateResponse(
            output=result.get("output", ""),
            model_used=result.get("model_used", "unknown"),
            task_type=request.task_type,
            tokens_used=result.get("tokens_used", 0),
            is_hallucination=result.get("is_hallucination", False),
            confidence_score=result.get("confidence_score", 0.0),
            metadata=result.get("metadata", {})
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"AI generation failed: {str(e)}"
        )


@router.get("/models", response_model=AIModelsResponse)
async def list_ai_models(
    current_user: dict = Depends(get_current_user),
    ai_engine = Depends(get_ai_engine)
):
    """
    List available AI models
    
    Args:
        current_user: Current authenticated user
        ai_engine: AI Engine instance
        
    Returns:
        AIModelsResponse: List of available models
    """
    try:
        if not ai_engine:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="AI Engine not available"
            )
        
        # TODO: Get models from AI Engine
        
        models = [
            {
                "name": "Qwen3-235B-A22B",
                "type": "reasoning",
                "size": "235B",
                "capabilities": ["reasoning", "complex_analysis"]
            },
            {
                "name": "GLM-4.6-Reasoning",
                "type": "reasoning",
                "size": "4.6B",
                "capabilities": ["reasoning", "step_by_step"]
            },
            {
                "name": "DeepSeek-V3.2-Exp",
                "type": "non_reasoning",
                "size": "3.2B",
                "capabilities": ["fast_generation", "general"]
            },
            {
                "name": "GLM-4.6",
                "type": "non_reasoning",
                "size": "4.6B",
                "capabilities": ["fast_generation", "general"]
            }
        ]
        
        return AIModelsResponse(
            models=models,
            total=len(models)
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list models: {str(e)}"
        )


@router.post("/validate")
async def validate_ai_output(
    output: str = Field(..., min_length=1),
    task_type: AITaskType = Field(default=AITaskType.GENERAL),
    current_user: dict = Depends(get_current_user)
):
    """
    Validate AI output for hallucinations
    
    Uses the 7-Layer Anti-Hallucination System.
    
    Args:
        output: AI-generated output to validate
        task_type: Task type for context
        current_user: Current authenticated user
        
    Returns:
        dict: Validation results
    """
    try:
        from app.core.ai_output_validator import AIOutputValidator
        
        validator = AIOutputValidator()
        
        # Validate output
        result = validator.validate_output(
            output=output,
            task_type=task_type.value
        )
        
        return {
            "is_valid": result.get("is_valid", False),
            "is_hallucination": result.get("is_hallucination", True),
            "confidence_score": result.get("confidence_score", 0.0),
            "issues": result.get("issues", []),
            "recommendations": result.get("recommendations", [])
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Validation failed: {str(e)}"
        )


@router.get("/stats")
async def get_ai_stats(
    current_user: dict = Depends(get_current_user),
    ai_engine = Depends(get_ai_engine)
):
    """
    Get AI Engine statistics
    
    Args:
        current_user: Current authenticated user
        ai_engine: AI Engine instance
        
    Returns:
        dict: AI statistics
    """
    try:
        if not ai_engine:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="AI Engine not available"
            )
        
        # TODO: Get stats from AI Engine
        
        return {
            "total_generations": 0,
            "avg_tokens_per_generation": 0,
            "hallucination_rate": 0.0,
            "model_usage": {
                "reasoning": 0,
                "non_reasoning": 0
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get AI stats: {str(e)}"
        )
