"""
SecureRedLab Backend - VLM (Vision Language Model) Endpoints
Handles image analysis and OCR for security assessment
"""

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, Dict, Any, List
from enum import Enum
import base64

from app.dependencies import get_current_user

router = APIRouter()


# Enums
class VLMTaskType(str, Enum):
    """VLM Task types"""
    SCREENSHOT_ANALYSIS = "screenshot_analysis"
    VULNERABILITY_DETECTION = "vulnerability_detection"
    CODE_SCREENSHOT = "code_screenshot"
    UI_ANALYSIS = "ui_analysis"
    OCR_EXTRACTION = "ocr_extraction"
    GENERAL = "general"


# Pydantic Models
class VLMProcessRequest(BaseModel):
    """VLM processing request (for URL)"""
    image_url: HttpUrl = Field(..., description="Public image URL")
    task_type: VLMTaskType = Field(default=VLMTaskType.GENERAL)
    prompt: Optional[str] = Field(None, description="Additional prompt for analysis")
    use_ocr_fallback: bool = Field(default=True, description="Use 3-Tier OCR Fallback if needed")


class VLMProcessResponse(BaseModel):
    """VLM processing response"""
    analysis: str
    model_used: str
    task_type: VLMTaskType
    ocr_text: Optional[str] = None
    ocr_tier_used: Optional[str] = None
    is_hallucination: bool = False
    confidence_score: float = Field(ge=0.0, le=1.0)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class VLMModelsResponse(BaseModel):
    """Available VLM models response"""
    models: List[Dict[str, Any]]
    total: int


# Endpoints
@router.post("/process", response_model=VLMProcessResponse)
async def process_image_url(
    request: VLMProcessRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    Process image from URL using VLM
    
    This endpoint uses the VLM Core with:
    - 5 VLM Models (InternVL3, Qwen2.5-VL, Hunyuan-OCR, etc.)
    - 3-Track Router (Complex, Document, OCR)
    - 3-Tier OCR Fallback (Hunyuan → PaddleOCR → Tesseract)
    
    Args:
        request: VLM processing request
        current_user: Current authenticated user
        
    Returns:
        VLMProcessResponse: Image analysis with metadata
        
    Raises:
        HTTPException: If processing fails
    """
    try:
        from app.ai.vlm_core import VLMCore, VLMTaskType as VLMCoreTaskType
        
        vlm_core = VLMCore()
        
        # Map task type
        task_type_map = {
            VLMTaskType.SCREENSHOT_ANALYSIS: VLMCoreTaskType.COMPLEX,
            VLMTaskType.VULNERABILITY_DETECTION: VLMCoreTaskType.COMPLEX,
            VLMTaskType.CODE_SCREENSHOT: VLMCoreTaskType.DOCUMENT,
            VLMTaskType.UI_ANALYSIS: VLMCoreTaskType.COMPLEX,
            VLMTaskType.OCR_EXTRACTION: VLMCoreTaskType.DOCUMENT,
            VLMTaskType.GENERAL: VLMCoreTaskType.GENERAL
        }
        
        vlm_task_type = task_type_map.get(request.task_type, VLMCoreTaskType.GENERAL)
        
        # Process image
        result = await vlm_core.process_image(
            image_url=str(request.image_url),
            task_type=vlm_task_type,
            prompt=request.prompt,
            use_ocr_fallback=request.use_ocr_fallback
        )
        
        if not result or result.get("status") != "success":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="VLM processing failed"
            )
        
        return VLMProcessResponse(
            analysis=result.get("analysis", ""),
            model_used=result.get("model_used", "unknown"),
            task_type=request.task_type,
            ocr_text=result.get("ocr_text"),
            ocr_tier_used=result.get("ocr_tier_used"),
            is_hallucination=result.get("is_hallucination", False),
            confidence_score=result.get("confidence_score", 0.0),
            metadata=result.get("metadata", {})
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"VLM processing failed: {str(e)}"
        )


@router.post("/upload", response_model=VLMProcessResponse)
async def process_image_upload(
    file: UploadFile = File(..., description="Image file to process"),
    task_type: VLMTaskType = VLMTaskType.GENERAL,
    prompt: Optional[str] = None,
    use_ocr_fallback: bool = True,
    current_user: dict = Depends(get_current_user)
):
    """
    Process uploaded image using VLM
    
    Args:
        file: Uploaded image file
        task_type: VLM task type
        prompt: Additional prompt for analysis
        use_ocr_fallback: Use 3-Tier OCR Fallback if needed
        current_user: Current authenticated user
        
    Returns:
        VLMProcessResponse: Image analysis with metadata
        
    Raises:
        HTTPException: If processing fails
    """
    try:
        # Validate file type
        allowed_types = ["image/jpeg", "image/jpg", "image/png", "image/webp"]
        if file.content_type not in allowed_types:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid file type. Allowed: {', '.join(allowed_types)}"
            )
        
        # Read file
        contents = await file.read()
        
        # Validate file size (max 10MB)
        max_size = 10 * 1024 * 1024
        if len(contents) > max_size:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File size exceeds 10MB limit"
            )
        
        # Encode to base64
        image_base64 = base64.b64encode(contents).decode("utf-8")
        
        from app.ai.vlm_core import VLMCore, VLMTaskType as VLMCoreTaskType
        
        vlm_core = VLMCore()
        
        # Map task type
        task_type_map = {
            VLMTaskType.SCREENSHOT_ANALYSIS: VLMCoreTaskType.COMPLEX,
            VLMTaskType.VULNERABILITY_DETECTION: VLMCoreTaskType.COMPLEX,
            VLMTaskType.CODE_SCREENSHOT: VLMCoreTaskType.DOCUMENT,
            VLMTaskType.UI_ANALYSIS: VLMCoreTaskType.COMPLEX,
            VLMTaskType.OCR_EXTRACTION: VLMCoreTaskType.DOCUMENT,
            VLMTaskType.GENERAL: VLMCoreTaskType.GENERAL
        }
        
        vlm_task_type = task_type_map.get(task_type, VLMCoreTaskType.GENERAL)
        
        # Process image
        result = await vlm_core.process_image(
            image_base64=image_base64,
            task_type=vlm_task_type,
            prompt=prompt,
            use_ocr_fallback=use_ocr_fallback
        )
        
        if not result or result.get("status") != "success":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="VLM processing failed"
            )
        
        return VLMProcessResponse(
            analysis=result.get("analysis", ""),
            model_used=result.get("model_used", "unknown"),
            task_type=task_type,
            ocr_text=result.get("ocr_text"),
            ocr_tier_used=result.get("ocr_tier_used"),
            is_hallucination=result.get("is_hallucination", False),
            confidence_score=result.get("confidence_score", 0.0),
            metadata=result.get("metadata", {})
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"VLM processing failed: {str(e)}"
        )


@router.get("/models", response_model=VLMModelsResponse)
async def list_vlm_models(
    current_user: dict = Depends(get_current_user)
):
    """
    List available VLM models
    
    Args:
        current_user: Current authenticated user
        
    Returns:
        VLMModelsResponse: List of available VLM models
    """
    try:
        models = [
            {
                "name": "InternVL3-78B",
                "type": "complex",
                "vram": "48GB",
                "capabilities": ["complex_reasoning", "scene_understanding"]
            },
            {
                "name": "Qwen2.5-VL-72B-AWQ",
                "type": "complex",
                "vram": "40GB",
                "capabilities": ["complex_reasoning", "multilingual"]
            },
            {
                "name": "Hunyuan-OCR",
                "type": "document",
                "vram": "24GB",
                "capabilities": ["ocr", "document_analysis", "92%_accuracy"]
            },
            {
                "name": "MiniCPM-V-4.5",
                "type": "ocr",
                "vram": "16GB",
                "capabilities": ["ocr", "lightweight"]
            },
            {
                "name": "InternVL2-8B",
                "type": "light",
                "vram": "16GB",
                "capabilities": ["general", "fast"]
            }
        ]
        
        return VLMModelsResponse(
            models=models,
            total=len(models)
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list models: {str(e)}"
        )


@router.get("/stats")
async def get_vlm_stats(
    current_user: dict = Depends(get_current_user)
):
    """
    Get VLM Engine statistics
    
    Args:
        current_user: Current authenticated user
        
    Returns:
        dict: VLM statistics
    """
    try:
        # TODO: Get stats from VLM Core
        
        return {
            "total_images_processed": 0,
            "avg_processing_time": 0.0,
            "ocr_fallback_rate": 0.0,
            "model_usage": {
                "complex": 0,
                "document": 0,
                "ocr": 0
            },
            "ocr_tier_usage": {
                "hunyuan": 0,
                "paddleocr": 0,
                "tesseract": 0
            }
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get VLM stats: {str(e)}"
        )
