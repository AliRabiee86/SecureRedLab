"""
SecureRedLab Backend - Authentication Endpoints
Handles user login, registration, and token management
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer
from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime, timedelta
from jose import jwt

from app.config import settings
from app.core.auth_system import AuthSystem

router = APIRouter()
security = HTTPBearer()

# Global auth system instance
auth_system = AuthSystem()


# Pydantic Models (temporary - will move to schemas/)
class LoginRequest(BaseModel):
    """Login request model"""
    username: str
    password: str


class RegisterRequest(BaseModel):
    """Registration request model"""
    username: str
    email: EmailStr
    password: str
    full_name: Optional[str] = None


class TokenResponse(BaseModel):
    """Token response model"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class UserResponse(BaseModel):
    """User response model"""
    user_id: str
    username: str
    email: str
    full_name: Optional[str] = None
    is_active: bool = True
    created_at: datetime


# Endpoints
@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(request: RegisterRequest):
    """
    Register a new user
    
    Args:
        request: Registration data
        
    Returns:
        UserResponse: Created user information
        
    Raises:
        HTTPException: If username/email already exists
    """
    try:
        # TODO: Check if username/email exists in database
        
        # Create user using auth system
        user = auth_system.create_user(
            username=request.username,
            email=request.email,
            password=request.password
        )
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to create user"
            )
        
        # TODO: Save user to database
        
        return UserResponse(
            user_id=user.get("user_id", "test-user-id"),
            username=request.username,
            email=request.email,
            full_name=request.full_name,
            is_active=True,
            created_at=datetime.utcnow()
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {str(e)}"
        )


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest):
    """
    Login with username and password
    
    Args:
        request: Login credentials
        
    Returns:
        TokenResponse: JWT access token
        
    Raises:
        HTTPException: If credentials are invalid
    """
    try:
        # Validate credentials using auth system
        user = auth_system.authenticate_user(
            username=request.username,
            password=request.password
        )
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create JWT token
        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        expire = datetime.utcnow() + access_token_expires
        
        token_data = {
            "sub": user.get("user_id", request.username),
            "username": request.username,
            "exp": expire
        }
        
        access_token = jwt.encode(
            token_data,
            settings.SECRET_KEY,
            algorithm=settings.ALGORITHM
        )
        
        return TokenResponse(
            access_token=access_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    credentials: str = Depends(security)
):
    """
    Refresh access token
    
    Args:
        credentials: Current JWT token
        
    Returns:
        TokenResponse: New JWT access token
        
    Raises:
        HTTPException: If token is invalid
    """
    try:
        # Decode current token
        payload = jwt.decode(
            credentials.credentials,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        
        username = payload.get("username")
        user_id = payload.get("sub")
        
        if not username or not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create new token
        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        expire = datetime.utcnow() + access_token_expires
        
        token_data = {
            "sub": user_id,
            "username": username,
            "exp": expire
        }
        
        access_token = jwt.encode(
            token_data,
            settings.SECRET_KEY,
            algorithm=settings.ALGORITHM
        )
        
        return TokenResponse(
            access_token=access_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Token refresh failed: {str(e)}",
            headers={"WWW-Authenticate": "Bearer"},
        )


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    credentials: str = Depends(security)
):
    """
    Get current user information
    
    Args:
        credentials: JWT token
        
    Returns:
        UserResponse: Current user information
        
    Raises:
        HTTPException: If token is invalid
    """
    try:
        # Decode token
        payload = jwt.decode(
            credentials.credentials,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        
        user_id = payload.get("sub")
        username = payload.get("username")
        
        if not user_id or not username:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        
        # TODO: Fetch full user info from database
        
        return UserResponse(
            user_id=user_id,
            username=username,
            email=f"{username}@example.com",  # TODO: Get from DB
            full_name=None,
            is_active=True,
            created_at=datetime.utcnow()
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Failed to get user info: {str(e)}"
        )
