"""
SecureRedLab Backend - Main API Router
Includes all API endpoints
"""

from fastapi import APIRouter

from app.api.v1.endpoints import auth, scans, attacks, rl, ai, vlm
from app.api.v1 import websocket

# Main API router
api_router = APIRouter()

# Include sub-routers
api_router.include_router(
    auth.router,
    prefix="/auth",
    tags=["Authentication"]
)

api_router.include_router(
    scans.router,
    prefix="/scans",
    tags=["Scans"]
)

api_router.include_router(
    attacks.router,
    prefix="/attacks",
    tags=["Attacks"]
)

api_router.include_router(
    rl.router,
    prefix="/rl",
    tags=["Reinforcement Learning"]
)

api_router.include_router(
    ai.router,
    prefix="/ai",
    tags=["AI Generation"]
)

api_router.include_router(
    vlm.router,
    prefix="/vlm",
    tags=["Vision Language Models"]
)

# WebSocket endpoints (no prefix - mounted at root)
websocket_router = websocket.router
