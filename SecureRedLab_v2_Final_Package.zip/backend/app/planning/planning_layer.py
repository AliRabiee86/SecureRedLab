#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Planning Layer
==================================

لایه برنامه‌ریزی - قلب استراتژیک سیستم ایجنتیک

این لایه شامل سه ماژول اصلی است:

1. Attack Chain Planner:
   - طراحی زنجیره حملات چند مرحله‌ای
   - تعیین dependencies بین مراحل
   - مدیریت fallback plans
   - بهینه‌سازی ترتیب اجرا

2. Strategy Generator:
   - تولید استراتژی‌های adaptive
   - انتخاب تکنیک‌های evasion
   - تعیین اولویت اهداف
   - تطبیق با محیط دفاعی

3. Goal Decomposer:
   - تجزیه اهداف پیچیده به زیر-اهداف
   - ایجاد درخت هدف (Goal Tree)
   - تعیین وابستگی‌های منطقی
   - اولویت‌بندی زیر-اهداف

این لایه به Decision Agent کمک می‌کند تا برنامه‌های حمله بهینه و واقع‌گرایانه طراحی کند.

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک

LEGAL REQUIREMENTS:
- FBI Clearance
- IRB Ethics Committee Approval
- Local Police Department Authorization
- University Research Committee Approval

ONLY FOR ACADEMIC RESEARCH - تنها برای تحقیقات آکادمیک
"""

import asyncio
import json
from typing import Dict, Any, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

# تنظیم logger
logger = logging.getLogger(__name__)


# ==============================================================================
# Enums و Data Classes
# ==============================================================================

class GoalStatus(Enum):
    """وضعیت هدف"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"  # منتظر تکمیل پیش‌نیازها


class StrategyType(Enum):
    """نوع استراتژی"""
    STEALTH = "stealth"           # مخفیانه (کم سر و صدا)
    AGGRESSIVE = "aggressive"     # تهاجمی (سریع و پرقدرت)
    BALANCED = "balanced"         # متعادل
    ADAPTIVE = "adaptive"         # تطبیقی (تغییر بر اساس واکنش)


@dataclass
class Goal:
    """
    یک هدف (Goal)
    """
    goal_id: str                       # شناسه هدف
    description: str                   # توضیحات
    parent_goal_id: Optional[str]      # هدف والد (برای زیر-اهداف)
    sub_goals: List[str]               # لیست زیر-اهداف (goal_id ها)
    prerequisites: List[str]           # پیش‌نیازها (goal_id ها)
    status: GoalStatus                 # وضعیت
    priority: int                      # اولویت (1-10، 10 = بالاترین)
    estimated_difficulty: float        # سختی تخمینی (0-1)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'goal_id': self.goal_id,
            'description': self.description,
            'parent_goal_id': self.parent_goal_id,
            'sub_goals': self.sub_goals,
            'prerequisites': self.prerequisites,
            'status': self.status.value,
            'priority': self.priority,
            'estimated_difficulty': self.estimated_difficulty,
            'metadata': self.metadata
        }


@dataclass
class AttackStrategy:
    """
    استراتژی حمله
    """
    strategy_id: str                   # شناسه استراتژی
    strategy_type: StrategyType        # نوع استراتژی
    description: str                   # توضیحات
    evasion_techniques: List[str]      # تکنیک‌های فرار
    tools_preference: List[str]        # ابزارهای ترجیحی
    timing_strategy: str               # استراتژی زمان‌بندی
    detection_risk_threshold: float    # آستانه ریسک شناسایی (0-1)
    success_criteria: Dict[str, Any]   # معیارهای موفقیت
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'strategy_id': self.strategy_id,
            'strategy_type': self.strategy_type.value,
            'description': self.description,
            'evasion_techniques': self.evasion_techniques,
            'tools_preference': self.tools_preference,
            'timing_strategy': self.timing_strategy,
            'detection_risk_threshold': self.detection_risk_threshold,
            'success_criteria': self.success_criteria,
            'metadata': self.metadata
        }


@dataclass
class AttackChain:
    """
    زنجیره حملات
    """
    chain_id: str                      # شناسه زنجیره
    goal_id: str                       # هدف مرتبط
    steps: List[Dict[str, Any]]        # مراحل حمله
    dependencies: Dict[str, List[str]] # وابستگی‌ها (step_id -> [prerequisite_step_ids])
    fallback_chains: List[str]         # زنجیره‌های جایگزین
    estimated_time: float              # زمان تخمینی کل (دقیقه)
    risk_score: float                  # امتیاز ریسک کل (0-10)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'chain_id': self.chain_id,
            'goal_id': self.goal_id,
            'steps': self.steps,
            'dependencies': self.dependencies,
            'fallback_chains': self.fallback_chains,
            'estimated_time': self.estimated_time,
            'risk_score': self.risk_score,
            'metadata': self.metadata
        }


# ==============================================================================
# Goal Decomposer
# ==============================================================================

class GoalDecomposer:
    """
    تجزیه‌کننده اهداف
    
    این کلاس اهداف پیچیده را به زیر-اهداف قابل اجرا تجزیه می‌کند.
    
    مثال:
        هدف: "دسترسی به دیتابیس و استخراج داده"
        
        زیر-اهداف:
        1. شناسایی پورت‌های باز
        2. شناسایی نسخه MySQL
        3. یافتن آسیب‌پذیری SQL Injection
        4. Exploit کردن SQL Injection
        5. دسترسی به دیتابیس
        6. استخراج داده
    
    استفاده:
        decomposer = GoalDecomposer()
        
        goal_tree = decomposer.decompose_goal(
            "دسترسی به دیتابیس و استخراج داده",
            target_info={'ip': '192.168.1.100', 'ports': [3306]}
        )
    """
    
    def __init__(self):
        """مقداردهی اولیه"""
        self.goals: Dict[str, Goal] = {}  # ذخیره اهداف
        logger.info("Goal Decomposer initialized")
    
    def decompose_goal(
        self,
        main_goal: str,
        target_info: Dict[str, Any],
        max_depth: int = 3
    ) -> Goal:
        """
        تجزیه یک هدف اصلی به زیر-اهداف
        
        Args:
            main_goal: هدف اصلی (مثلاً "data exfiltration")
            target_info: اطلاعات هدف
            max_depth: حداکثر عمق درخت هدف
        
        Returns:
            Goal (ریشه درخت هدف)
        """
        logger.info(f"Decomposing goal: {main_goal}")
        
        # ایجاد هدف اصلی
        root_goal = Goal(
            goal_id="GOAL-ROOT",
            description=main_goal,
            parent_goal_id=None,
            sub_goals=[],
            prerequisites=[],
            status=GoalStatus.PENDING,
            priority=10,
            estimated_difficulty=0.8
        )
        
        # تجزیه بر اساس نوع هدف
        if "data" in main_goal.lower() or "exfiltration" in main_goal.lower():
            sub_goals = self._decompose_data_exfiltration(root_goal, target_info)
        elif "privilege" in main_goal.lower() or "escalation" in main_goal.lower():
            sub_goals = self._decompose_privilege_escalation(root_goal, target_info)
        elif "access" in main_goal.lower():
            sub_goals = self._decompose_access_goal(root_goal, target_info)
        else:
            # تجزیه عمومی
            sub_goals = self._decompose_generic(root_goal, target_info)
        
        # اضافه کردن زیر-اهداف به هدف اصلی
        root_goal.sub_goals = [g.goal_id for g in sub_goals]
        
        # ذخیره اهداف
        self.goals[root_goal.goal_id] = root_goal
        for goal in sub_goals:
            self.goals[goal.goal_id] = goal
        
        logger.info(f"Goal decomposed into {len(sub_goals)} sub-goals")
        
        return root_goal
    
    def _decompose_data_exfiltration(
        self,
        parent_goal: Goal,
        target_info: Dict[str, Any]
    ) -> List[Goal]:
        """
        تجزیه هدف "استخراج داده"
        
        زیر-اهداف:
        1. Reconnaissance
        2. Find vulnerability
        3. Exploit vulnerability
        4. Access database
        5. Extract data
        6. Exfiltrate data
        """
        sub_goals = []
        
        # 1. Reconnaissance
        g1 = Goal(
            goal_id="GOAL-1",
            description="شناسایی و جمع‌آوری اطلاعات هدف",
            parent_goal_id=parent_goal.goal_id,
            sub_goals=[],
            prerequisites=[],
            status=GoalStatus.PENDING,
            priority=10,
            estimated_difficulty=0.2
        )
        sub_goals.append(g1)
        
        # 2. Find vulnerability
        g2 = Goal(
            goal_id="GOAL-2",
            description="شناسایی آسیب‌پذیری‌های قابل استفاده",
            parent_goal_id=parent_goal.goal_id,
            sub_goals=[],
            prerequisites=["GOAL-1"],
            status=GoalStatus.PENDING,
            priority=9,
            estimated_difficulty=0.5
        )
        sub_goals.append(g2)
        
        # 3. Exploit vulnerability
        g3 = Goal(
            goal_id="GOAL-3",
            description="Exploit کردن آسیب‌پذیری",
            parent_goal_id=parent_goal.goal_id,
            sub_goals=[],
            prerequisites=["GOAL-2"],
            status=GoalStatus.PENDING,
            priority=8,
            estimated_difficulty=0.7
        )
        sub_goals.append(g3)
        
        # 4. Access database
        g4 = Goal(
            goal_id="GOAL-4",
            description="دسترسی به دیتابیس",
            parent_goal_id=parent_goal.goal_id,
            sub_goals=[],
            prerequisites=["GOAL-3"],
            status=GoalStatus.PENDING,
            priority=7,
            estimated_difficulty=0.6
        )
        sub_goals.append(g4)
        
        # 5. Extract data
        g5 = Goal(
            goal_id="GOAL-5",
            description="استخراج داده از دیتابیس",
            parent_goal_id=parent_goal.goal_id,
            sub_goals=[],
            prerequisites=["GOAL-4"],
            status=GoalStatus.PENDING,
            priority=6,
            estimated_difficulty=0.4
        )
        sub_goals.append(g5)
        
        # 6. Exfiltrate data
        g6 = Goal(
            goal_id="GOAL-6",
            description="انتقال داده به خارج از شبکه",
            parent_goal_id=parent_goal.goal_id,
            sub_goals=[],
            prerequisites=["GOAL-5"],
            status=GoalStatus.PENDING,
            priority=5,
            estimated_difficulty=0.5
        )
        sub_goals.append(g6)
        
        return sub_goals
    
    def _decompose_privilege_escalation(
        self,
        parent_goal: Goal,
        target_info: Dict[str, Any]
    ) -> List[Goal]:
        """تجزیه هدف "ارتقا دسترسی"""
        # پیاده‌سازی مشابه _decompose_data_exfiltration
        return []
    
    def _decompose_access_goal(
        self,
        parent_goal: Goal,
        target_info: Dict[str, Any]
    ) -> List[Goal]:
        """تجزیه هدف "دسترسی"""
        # پیاده‌سازی مشابه
        return []
    
    def _decompose_generic(
        self,
        parent_goal: Goal,
        target_info: Dict[str, Any]
    ) -> List[Goal]:
        """تجزیه عمومی"""
        # پیاده‌سازی عمومی
        return []
    
    def get_executable_goals(self) -> List[Goal]:
        """
        دریافت اهدافی که آماده اجرا هستند
        
        یک هدف آماده اجرا است اگر:
        - وضعیت آن PENDING باشد
        - تمام پیش‌نیازهایش تکمیل شده باشند
        
        Returns:
            لیست اهداف آماده اجرا (مرتب شده بر اساس اولویت)
        """
        executable = []
        
        for goal in self.goals.values():
            if goal.status != GoalStatus.PENDING:
                continue
            
            # بررسی پیش‌نیازها
            all_prerequisites_met = True
            for prereq_id in goal.prerequisites:
                prereq = self.goals.get(prereq_id)
                if not prereq or prereq.status != GoalStatus.COMPLETED:
                    all_prerequisites_met = False
                    break
            
            if all_prerequisites_met:
                executable.append(goal)
        
        # مرتب‌سازی بر اساس اولویت
        executable.sort(key=lambda g: g.priority, reverse=True)
        
        return executable


# ==============================================================================
# Strategy Generator
# ==============================================================================

class StrategyGenerator:
    """
    تولیدکننده استراتژی
    
    این کلاس استراتژی‌های حمله adaptive تولید می‌کند.
    
    استفاده:
        generator = StrategyGenerator()
        
        strategy = generator.generate_strategy(
            goal="data_exfiltration",
            target_info={'defenses': ['firewall', 'ids']},
            constraints={'stealth_level': 'high'}
        )
    """
    
    def __init__(self):
        """مقداردهی اولیه"""
        logger.info("Strategy Generator initialized")
    
    def generate_strategy(
        self,
        goal: str,
        target_info: Dict[str, Any],
        constraints: Optional[Dict[str, Any]] = None
    ) -> AttackStrategy:
        """
        تولید استراتژی حمله
        
        Args:
            goal: هدف حمله
            target_info: اطلاعات هدف (شامل دفاع‌ها)
            constraints: محدودیت‌ها (مثلاً stealth_level، max_time)
        
        Returns:
            AttackStrategy
        """
        logger.info(f"Generating strategy for goal: {goal}")
        
        constraints = constraints or {}
        
        # تعیین نوع استراتژی بر اساس محدودیت‌ها
        stealth_level = constraints.get('stealth_level', 'medium')
        
        if stealth_level == 'high':
            strategy_type = StrategyType.STEALTH
            evasion_techniques = [
                'time-based delays',
                'traffic obfuscation',
                'low-and-slow',
                'polymorphic payloads'
            ]
            detection_risk_threshold = 0.3
        elif stealth_level == 'low':
            strategy_type = StrategyType.AGGRESSIVE
            evasion_techniques = ['basic obfuscation']
            detection_risk_threshold = 0.8
        else:
            strategy_type = StrategyType.BALANCED
            evasion_techniques = [
                'traffic obfuscation',
                'polymorphic payloads'
            ]
            detection_risk_threshold = 0.5
        
        # انتخاب ابزارها بر اساس هدف
        if 'sql' in goal.lower() or 'database' in goal.lower():
            tools_preference = ['sqlmap', 'burp', 'custom-scripts']
        elif 'web' in goal.lower():
            tools_preference = ['burp', 'zap', 'nikto']
        elif 'network' in goal.lower():
            tools_preference = ['nmap', 'metasploit', 'wireshark']
        else:
            tools_preference = ['nmap', 'metasploit', 'burp']
        
        # ایجاد استراتژی
        strategy = AttackStrategy(
            strategy_id=f"STRATEGY-{int(time.time())}",
            strategy_type=strategy_type,
            description=f"استراتژی {strategy_type.value} برای {goal}",
            evasion_techniques=evasion_techniques,
            tools_preference=tools_preference,
            timing_strategy="adaptive",
            detection_risk_threshold=detection_risk_threshold,
            success_criteria={
                'goal_achieved': True,
                'detection_avoided': True,
                'time_within_limit': True
            }
        )
        
        logger.info(f"Strategy generated: {strategy.strategy_id} ({strategy.strategy_type.value})")
        
        return strategy


# ==============================================================================
# Attack Chain Planner
# ==============================================================================

class AttackChainPlanner:
    """
    برنامه‌ریز زنجیره حملات
    
    این کلاس زنجیره حملات چند مرحله‌ای طراحی می‌کند.
    
    استفاده:
        planner = AttackChainPlanner()
        
        chain = planner.plan_attack_chain(
            goal=goal_obj,
            strategy=strategy_obj,
            vulnerabilities=[...]
        )
    """
    
    def __init__(self):
        """مقداردهی اولیه"""
        logger.info("Attack Chain Planner initialized")
    
    def plan_attack_chain(
        self,
        goal: Goal,
        strategy: AttackStrategy,
        vulnerabilities: List[Dict[str, Any]]
    ) -> AttackChain:
        """
        طراحی زنجیره حملات
        
        Args:
            goal: هدف
            strategy: استراتژی
            vulnerabilities: آسیب‌پذیری‌های شناسایی شده
        
        Returns:
            AttackChain
        """
        logger.info(f"Planning attack chain for goal: {goal.goal_id}")
        
        # ایجاد مراحل بر اساس آسیب‌پذیری‌ها
        steps = []
        dependencies = {}
        
        for i, vuln in enumerate(vulnerabilities):
            step_id = f"STEP-{i+1:03d}"
            
            step = {
                'step_id': step_id,
                'step_number': i + 1,
                'attack_type': vuln.get('vuln_type', 'unknown'),
                'target': vuln.get('target', ''),
                'description': vuln.get('description', ''),
                'prerequisites': [f"STEP-{i:03d}"] if i > 0 else [],
                'estimated_time': 5.0 + (i * 2.0),
                'risk_score': 5.0,
                'tools_required': strategy.tools_preference[:2],
                'evasion_techniques': strategy.evasion_techniques,
                'fallback_steps': []
            }
            
            steps.append(step)
            dependencies[step_id] = step['prerequisites']
        
        # محاسبه زمان و ریسک کل
        total_time = sum(s['estimated_time'] for s in steps)
        avg_risk = sum(s['risk_score'] for s in steps) / len(steps) if steps else 0
        
        # ایجاد AttackChain
        chain = AttackChain(
            chain_id=f"CHAIN-{goal.goal_id}",
            goal_id=goal.goal_id,
            steps=steps,
            dependencies=dependencies,
            fallback_chains=[],
            estimated_time=total_time,
            risk_score=avg_risk
        )
        
        logger.info(
            f"Attack chain planned: {chain.chain_id}, "
            f"{len(steps)} steps, "
            f"{total_time:.1f} min"
        )
        
        return chain
    
    def optimize_chain(self, chain: AttackChain) -> AttackChain:
        """
        بهینه‌سازی زنجیره حملات
        
        - حذف مراحل اضافی
        - بهینه‌سازی ترتیب اجرا
        - کاهش ریسک
        
        Args:
            chain: زنجیره حملات
        
        Returns:
            زنجیره بهینه شده
        """
        # پیاده‌سازی الگوریتم بهینه‌سازی
        # برای مثال، می‌توان از Topological Sort برای ترتیب بهینه استفاده کرد
        
        logger.info(f"Optimizing attack chain: {chain.chain_id}")
        
        # در اینجا فقط chain را برمی‌گردانیم (بدون تغییر)
        return chain


# ==============================================================================
# مثال استفاده
# ==============================================================================

async def example_usage():
    """مثال استفاده از Planning Layer"""
    import time
    
    # 1. Goal Decomposer
    decomposer = GoalDecomposer()
    
    root_goal = decomposer.decompose_goal(
        main_goal="دسترسی به دیتابیس و استخراج داده",
        target_info={'ip': '192.168.1.100', 'ports': [3306]}
    )
    
    print(f"Root Goal: {root_goal.description}")
    print(f"Sub-goals: {len(root_goal.sub_goals)}")
    
    executable_goals = decomposer.get_executable_goals()
    print(f"Executable goals: {len(executable_goals)}")
    
    # 2. Strategy Generator
    generator = StrategyGenerator()
    
    strategy = generator.generate_strategy(
        goal="data_exfiltration",
        target_info={'defenses': ['firewall', 'ids']},
        constraints={'stealth_level': 'high'}
    )
    
    print(f"Strategy: {strategy.strategy_type.value}")
    print(f"Evasion techniques: {strategy.evasion_techniques}")
    
    # 3. Attack Chain Planner
    planner = AttackChainPlanner()
    
    vulnerabilities = [
        {'vuln_type': 'sql_injection', 'target': 'http://target/login.php'},
        {'vuln_type': 'file_upload', 'target': 'http://target/upload.php'}
    ]
    
    chain = planner.plan_attack_chain(
        goal=root_goal,
        strategy=strategy,
        vulnerabilities=vulnerabilities
    )
    
    print(f"Attack Chain: {chain.chain_id}")
    print(f"Steps: {len(chain.steps)}")
    print(f"Estimated time: {chain.estimated_time:.1f} min")


if __name__ == "__main__":
    import time
    import logging
    logging.basicConfig(level=logging.INFO)
    
    asyncio.run(example_usage())
