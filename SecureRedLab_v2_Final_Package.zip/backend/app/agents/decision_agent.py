#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Decision Agent
==================================

ایجنت تصمیم‌گیری - مغز سیستم ایجنتیک

این agent مسئول:
- تحلیل هدف و شناسایی آسیب‌پذیری‌های احتمالی
- طراحی استراتژی حمله (Attack Strategy Planning)
- تصمیم‌گیری در مورد اقدامات بعدی
- ارزیابی ریسک و احتمال موفقیت
- تعیین اولویت اهداف
- طراحی زنجیره حملات چند مرحله‌ای

مدل‌های استفاده شده:
- Primary: DeepSeek-R1 (بهترین مدل برای Reasoning و Planning)
- Secondary: NVIDIA Nemotron-Cascade (Reasoning + Instruction Following)
- Fallback: Qwen3-235B-A22B (Deep Analysis)

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک - تنها برای استفاده در محیط‌های تحقیقاتی مجاز

LEGAL REQUIREMENTS:
- FBI Clearance
- IRB Ethics Committee Approval
- Local Police Department Authorization
- University Research Committee Approval

ONLY FOR ACADEMIC RESEARCH - تنها برای تحقیقات آکادمیک
"""

import asyncio
import json
import re
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

# Import base classes
from agents.base_agent import BaseAgent, ModelConfig, ModelPriority, TaskResult
from agents.communication_bus import AgentType, MessagePriority

# تنظیم logger
logger = logging.getLogger(__name__)


# ==============================================================================
# Enums و Data Classes
# ==============================================================================

class AttackType(Enum):
    """انواع حملات"""
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    CSRF = "csrf"
    FILE_UPLOAD = "file_upload"
    COMMAND_INJECTION = "command_injection"
    PATH_TRAVERSAL = "path_traversal"
    DDOS = "ddos"
    BRUTE_FORCE = "brute_force"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DATA_EXFILTRATION = "data_exfiltration"


class RiskLevel(Enum):
    """سطح ریسک"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Vulnerability:
    """
    آسیب‌پذیری شناسایی شده
    """
    vuln_id: str                       # شناسه آسیب‌پذیری
    vuln_type: AttackType              # نوع آسیب‌پذیری
    severity: RiskLevel                # شدت آسیب‌پذیری
    target: str                        # هدف (IP، URL، etc.)
    description: str                   # توضیحات
    exploit_difficulty: float          # سختی exploit (0-1)
    success_probability: float         # احتمال موفقیت (0-1)
    detection_risk: float              # ریسک شناسایی (0-1)
    allows_privilege_escalation: bool  # آیا امکان privilege escalation دارد؟
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'vuln_id': self.vuln_id,
            'vuln_type': self.vuln_type.value,
            'severity': self.severity.value,
            'target': self.target,
            'description': self.description,
            'exploit_difficulty': self.exploit_difficulty,
            'success_probability': self.success_probability,
            'detection_risk': self.detection_risk,
            'allows_privilege_escalation': self.allows_privilege_escalation,
            'metadata': self.metadata
        }


@dataclass
class AttackStep:
    """
    یک مرحله از زنجیره حملات
    """
    step_id: str                       # شناسه مرحله
    step_number: int                   # شماره مرحله
    attack_type: AttackType            # نوع حمله
    target: str                        # هدف
    description: str                   # توضیحات
    prerequisites: List[str]           # پیش‌نیازها (step_id های قبلی)
    estimated_time: float              # زمان تخمینی (دقیقه)
    risk_score: float                  # امتیاز ریسک (0-10)
    tools_required: List[str]          # ابزارهای مورد نیاز
    evasion_techniques: List[str]      # تکنیک‌های فرار
    fallback_steps: List[str]          # مراحل جایگزین در صورت شکست
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'step_id': self.step_id,
            'step_number': self.step_number,
            'attack_type': self.attack_type.value,
            'target': self.target,
            'description': self.description,
            'prerequisites': self.prerequisites,
            'estimated_time': self.estimated_time,
            'risk_score': self.risk_score,
            'tools_required': self.tools_required,
            'evasion_techniques': self.evasion_techniques,
            'fallback_steps': self.fallback_steps,
            'metadata': self.metadata
        }


@dataclass
class AttackPlan:
    """
    برنامه حمله کامل
    """
    plan_id: str                       # شناسه برنامه
    goal: str                          # هدف نهایی
    target_info: Dict[str, Any]        # اطلاعات هدف
    vulnerabilities: List[Vulnerability]  # آسیب‌پذیری‌های شناسایی شده
    attack_chain: List[AttackStep]     # زنجیره حملات
    total_estimated_time: float        # زمان کل تخمینی (دقیقه)
    overall_risk_score: float          # امتیاز ریسک کلی (0-10)
    success_probability: float         # احتمال موفقیت کلی (0-1)
    reasoning: str                     # استدلال و توضیحات
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'plan_id': self.plan_id,
            'goal': self.goal,
            'target_info': self.target_info,
            'vulnerabilities': [v.to_dict() for v in self.vulnerabilities],
            'attack_chain': [s.to_dict() for s in self.attack_chain],
            'total_estimated_time': self.total_estimated_time,
            'overall_risk_score': self.overall_risk_score,
            'success_probability': self.success_probability,
            'reasoning': self.reasoning,
            'metadata': self.metadata
        }


# ==============================================================================
# Decision Agent
# ==============================================================================

class DecisionAgent(BaseAgent):
    """
    ایجنت تصمیم‌گیری - مغز سیستم
    
    این agent با استفاده از مدل‌های Reasoning پیشرفته (DeepSeek-R1، Nemotron-Cascade)
    استراتژی حمله را طراحی می‌کند.
    
    جریان کار:
    1. دریافت اطلاعات هدف
    2. تحلیل هدف و شناسایی آسیب‌پذیری‌ها
    3. طراحی زنجیره حملات
    4. ارزیابی ریسک و احتمال موفقیت
    5. ارسال برنامه به Execution Agent
    
    استفاده:
        agent = DecisionAgent()
        
        # تحلیل هدف
        result = await agent.analyze_target({
            'ip': '192.168.1.100',
            'ports': [80, 443, 22, 3306],
            'os': 'Ubuntu 22.04',
            'services': ['nginx', 'mysql', 'openssh']
        })
        
        # طراحی برنامه حمله
        plan = await agent.plan_attack(
            target_info=result['target_info'],
            goal='data_exfiltration'
        )
    """
    
    def __init__(self, vllm_endpoint: str = "http://localhost:8000/v1"):
        """
        مقداردهی اولیه Decision Agent
        
        Args:
            vllm_endpoint: endpoint سرور vLLM
        """
        super().__init__(
            agent_type=AgentType.DECISION,
            agent_name="Decision Agent (DeepSeek-R1)"
        )
        
        # اضافه کردن مدل‌ها
        self._setup_models(vllm_endpoint)
        
        # تنظیمات
        self.max_attack_chain_length = 10  # حداکثر طول زنجیره حملات
        self.min_success_probability = 0.3  # حداقل احتمال موفقیت
        
        logger.info("Decision Agent initialized with DeepSeek-R1 + Nemotron-Cascade")
    
    def _setup_models(self, vllm_endpoint: str):
        """
        تنظیم مدل‌های LLM
        
        Args:
            vllm_endpoint: endpoint سرور vLLM
        """
        # Primary: DeepSeek-R1
        self.add_model(ModelConfig(
            model_name="deepseek-r1",
            model_path=f"{vllm_endpoint}/deepseek-r1",
            priority=ModelPriority.PRIMARY,
            max_tokens=8192,
            temperature=0.7,
            top_p=0.9,
            timeout=120,
            metadata={
                'description': 'Best for reasoning and planning',
                'mmlu': 88.5,
                'humaneval': 88.4
            }
        ))
        
        # Secondary: NVIDIA Nemotron-Cascade
        self.add_model(ModelConfig(
            model_name="nemotron-cascade",
            model_path=f"{vllm_endpoint}/nemotron-cascade",
            priority=ModelPriority.SECONDARY,
            max_tokens=8192,
            temperature=0.7,
            top_p=0.9,
            timeout=120,
            metadata={
                'description': 'Fast reasoning with instruction following',
                'mmlu': 85.4,
                'humaneval': 84.7
            }
        ))
        
        # Fallback: Qwen3-235B
        self.add_model(ModelConfig(
            model_name="qwen3-235b-a22b",
            model_path=f"{vllm_endpoint}/qwen3-235b",
            priority=ModelPriority.FALLBACK,
            max_tokens=8192,
            temperature=0.7,
            top_p=0.9,
            timeout=120,
            metadata={
                'description': 'Deep analysis and research',
                'mmlu': 88.6,
                'humaneval': 88.4
            }
        ))
    
    async def _call_llm_impl(
        self,
        model: ModelConfig,
        prompt: str,
        **kwargs
    ) -> str:
        """
        پیاده‌سازی فراخوانی LLM
        
        این متد از OpenAI-compatible API استفاده می‌کند (vLLM)
        
        Args:
            model: پیکربندی مدل
            prompt: prompt ورودی
            **kwargs: پارامترهای اضافی
        
        Returns:
            پاسخ مدل
        """
        try:
            # Import OpenAI client
            from openai import AsyncOpenAI
            
            # ایجاد client
            client = AsyncOpenAI(
                base_url=model.model_path,
                api_key="dummy"  # vLLM نیازی به API key ندارد
            )
            
            # تنظیمات
            temperature = kwargs.get('temperature', model.temperature)
            max_tokens = kwargs.get('max_tokens', model.max_tokens)
            top_p = kwargs.get('top_p', model.top_p)
            
            # فراخوانی API
            response = await client.chat.completions.create(
                model=model.model_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a cybersecurity expert specializing in penetration testing and red team operations. You provide detailed, strategic analysis for academic research purposes only."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p
            )
            
            # استخراج پاسخ
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error calling {model.model_name}: {e}")
            raise
    
    async def _execute_task(self, task_data: Dict[str, Any]) -> Any:
        """
        پیاده‌سازی اجرای task
        
        Args:
            task_data: داده‌های task که شامل:
                - task_type: نوع task (analyze_target، plan_attack، etc.)
                - target_info: اطلاعات هدف
                - goal: هدف نهایی
                - ...
        
        Returns:
            نتیجه task
        """
        task_type = task_data.get('task_type')
        
        if task_type == 'analyze_target':
            return await self.analyze_target(task_data.get('target_info', {}))
        
        elif task_type == 'plan_attack':
            return await self.plan_attack(
                target_info=task_data.get('target_info', {}),
                goal=task_data.get('goal', 'penetration_test'),
                constraints=task_data.get('constraints', {})
            )
        
        elif task_type == 'evaluate_risk':
            return await self.evaluate_risk(task_data.get('attack_plan'))
        
        else:
            raise ValueError(f"Unknown task type: {task_type}")
    
    # ==========================================================================
    # تحلیل هدف
    # ==========================================================================
    
    async def analyze_target(self, target_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحلیل هدف و شناسایی آسیب‌پذیری‌های احتمالی
        
        این متد:
        1. اطلاعات هدف را تحلیل می‌کند
        2. آسیب‌پذیری‌های احتمالی را شناسایی می‌کند
        3. اولویت‌بندی می‌کند
        4. توصیه‌های اولیه می‌دهد
        
        Args:
            target_info: اطلاعات هدف شامل:
                - ip: آدرس IP
                - ports: لیست پورت‌های باز
                - os: سیستم عامل
                - services: سرویس‌های در حال اجرا
                - web_technologies: تکنولوژی‌های وب (در صورت وجود)
                - ...
        
        Returns:
            دیکشنری شامل:
                - target_info: اطلاعات تکمیل شده هدف
                - vulnerabilities: لیست آسیب‌پذیری‌های شناسایی شده
                - attack_surface: سطح حمله
                - recommendations: توصیه‌ها
        """
        logger.info(f"Analyzing target: {target_info.get('ip', 'unknown')}")
        
        # ساخت prompt
        prompt = self._build_analysis_prompt(target_info)
        
        # فراخوانی LLM
        response = await self.call_llm(prompt, temperature=0.7)
        
        # پارس پاسخ
        analysis = self._parse_analysis_response(response, target_info)
        
        # ذخیره در context
        self.update_context('target_analysis', analysis)
        
        logger.info(
            f"Target analysis complete: {len(analysis['vulnerabilities'])} "
            f"vulnerabilities identified"
        )
        
        return analysis
    
    def _build_analysis_prompt(self, target_info: Dict[str, Any]) -> str:
        """
        ساخت prompt برای تحلیل هدف
        
        Args:
            target_info: اطلاعات هدف
        
        Returns:
            prompt
        """
        prompt = f"""
You are a cybersecurity expert analyzing a target for penetration testing.

TARGET INFORMATION:
{json.dumps(target_info, indent=2)}

TASK:
Analyze this target and identify potential vulnerabilities.

Consider:
1. Open ports and services
2. Operating system and version
3. Web technologies (if applicable)
4. Common misconfigurations
5. Known vulnerabilities (CVEs)
6. Attack surface

OUTPUT FORMAT (JSON):
{{
    "target_summary": "Brief summary of the target",
    "attack_surface": {{
        "network": ["list of network attack vectors"],
        "web": ["list of web attack vectors"],
        "system": ["list of system attack vectors"]
    }},
    "vulnerabilities": [
        {{
            "vuln_id": "VULN-001",
            "vuln_type": "sql_injection",
            "severity": "high",
            "target": "http://target/login.php",
            "description": "SQL injection in login form",
            "exploit_difficulty": 0.3,
            "success_probability": 0.7,
            "detection_risk": 0.4,
            "allows_privilege_escalation": true
        }}
    ],
    "recommendations": ["list of recommended attack strategies"]
}}

Provide your analysis in valid JSON format.
"""
        return prompt
    
    def _parse_analysis_response(
        self,
        response: str,
        target_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        پارس پاسخ تحلیل هدف
        
        Args:
            response: پاسخ LLM
            target_info: اطلاعات اصلی هدف
        
        Returns:
            دیکشنری تحلیل
        """
        try:
            # استخراج JSON از پاسخ
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                analysis_data = json.loads(json_match.group())
            else:
                # اگر JSON نبود، یک پاسخ پیش‌فرض بساز
                analysis_data = {
                    'target_summary': 'Analysis failed',
                    'attack_surface': {},
                    'vulnerabilities': [],
                    'recommendations': []
                }
            
            # تبدیل vulnerabilities به Vulnerability objects
            vulnerabilities = []
            for vuln_data in analysis_data.get('vulnerabilities', []):
                vuln = Vulnerability(
                    vuln_id=vuln_data.get('vuln_id', f"VULN-{len(vulnerabilities)+1}"),
                    vuln_type=AttackType(vuln_data.get('vuln_type', 'sql_injection')),
                    severity=RiskLevel(vuln_data.get('severity', 'medium')),
                    target=vuln_data.get('target', target_info.get('ip', 'unknown')),
                    description=vuln_data.get('description', ''),
                    exploit_difficulty=vuln_data.get('exploit_difficulty', 0.5),
                    success_probability=vuln_data.get('success_probability', 0.5),
                    detection_risk=vuln_data.get('detection_risk', 0.5),
                    allows_privilege_escalation=vuln_data.get('allows_privilege_escalation', False)
                )
                vulnerabilities.append(vuln)
            
            return {
                'target_info': target_info,
                'target_summary': analysis_data.get('target_summary', ''),
                'attack_surface': analysis_data.get('attack_surface', {}),
                'vulnerabilities': vulnerabilities,
                'recommendations': analysis_data.get('recommendations', [])
            }
            
        except Exception as e:
            logger.error(f"Error parsing analysis response: {e}")
            # بازگشت یک پاسخ پیش‌فرض
            return {
                'target_info': target_info,
                'target_summary': 'Analysis parsing failed',
                'attack_surface': {},
                'vulnerabilities': [],
                'recommendations': []
            }
    
    # ==========================================================================
    # طراحی برنامه حمله
    # ==========================================================================
    
    async def plan_attack(
        self,
        target_info: Dict[str, Any],
        goal: str,
        constraints: Optional[Dict[str, Any]] = None
    ) -> AttackPlan:
        """
        طراحی برنامه حمله کامل
        
        این متد:
        1. از نتایج تحلیل هدف استفاده می‌کند
        2. زنجیره حملات چند مرحله‌ای طراحی می‌کند
        3. dependencies بین مراحل را تعیین می‌کند
        4. ریسک و احتمال موفقیت را محاسبه می‌کند
        5. fallback plans اضافه می‌کند
        
        Args:
            target_info: اطلاعات هدف
            goal: هدف نهایی (مثلاً "data_exfiltration"، "privilege_escalation")
            constraints: محدودیت‌ها (مثلاً max_time، stealth_level)
        
        Returns:
            AttackPlan کامل
        """
        logger.info(f"Planning attack for goal: {goal}")
        
        # دریافت تحلیل هدف (اگر وجود دارد)
        target_analysis = self.get_context('target_analysis')
        if not target_analysis:
            # اگر تحلیل وجود ندارد، ابتدا تحلیل کن
            target_analysis = await self.analyze_target(target_info)
        
        # ساخت prompt
        prompt = self._build_planning_prompt(target_analysis, goal, constraints or {})
        
        # فراخوانی LLM
        response = await self.call_llm(prompt, temperature=0.7)
        
        # پارس پاسخ
        attack_plan = self._parse_planning_response(response, target_analysis, goal)
        
        # ذخیره در context
        self.update_context('attack_plan', attack_plan.to_dict())
        
        logger.info(
            f"Attack plan created: {len(attack_plan.attack_chain)} steps, "
            f"estimated time: {attack_plan.total_estimated_time:.1f} minutes"
        )
        
        # ارسال به Execution Agent
        await self.send_message(
            to_agent=AgentType.EXECUTION,
            message_type="attack_plan_ready",
            content={'attack_plan': attack_plan.to_dict()},
            priority=MessagePriority.HIGH
        )
        
        return attack_plan
    
    def _build_planning_prompt(
        self,
        target_analysis: Dict[str, Any],
        goal: str,
        constraints: Dict[str, Any]
    ) -> str:
        """
        ساخت prompt برای طراحی برنامه حمله
        
        Args:
            target_analysis: نتایج تحلیل هدف
            goal: هدف نهایی
            constraints: محدودیت‌ها
        
        Returns:
            prompt
        """
        # تبدیل vulnerabilities به dict
        vulns_dict = [v.to_dict() for v in target_analysis.get('vulnerabilities', [])]
        
        prompt = f"""
You are a cybersecurity expert designing a multi-step attack strategy.

TARGET ANALYSIS:
{json.dumps({
    'target_info': target_analysis.get('target_info', {}),
    'vulnerabilities': vulns_dict,
    'attack_surface': target_analysis.get('attack_surface', {})
}, indent=2)}

GOAL: {goal}

CONSTRAINTS:
{json.dumps(constraints, indent=2)}

TASK:
Design a multi-step attack chain to achieve the goal.

Consider:
1. Dependencies between steps (some steps require others to complete first)
2. Risk vs reward for each step
3. Evasion techniques to avoid detection
4. Fallback plans if a step fails
5. Tools required for each step
6. Estimated time for each step

OUTPUT FORMAT (JSON):
{{
    "reasoning": "Detailed explanation of the strategy",
    "attack_chain": [
        {{
            "step_id": "STEP-001",
            "step_number": 1,
            "attack_type": "sql_injection",
            "target": "http://target/login.php",
            "description": "Exploit SQL injection to bypass authentication",
            "prerequisites": [],
            "estimated_time": 5.0,
            "risk_score": 3.5,
            "tools_required": ["sqlmap", "burp"],
            "evasion_techniques": ["time-based blind", "waf bypass"],
            "fallback_steps": ["STEP-001-ALT"]
        }}
    ],
    "total_estimated_time": 30.0,
    "overall_risk_score": 6.5,
    "success_probability": 0.75
}}

Provide your attack plan in valid JSON format.
"""
        return prompt
    
    def _parse_planning_response(
        self,
        response: str,
        target_analysis: Dict[str, Any],
        goal: str
    ) -> AttackPlan:
        """
        پارس پاسخ طراحی برنامه حمله
        
        Args:
            response: پاسخ LLM
            target_analysis: تحلیل هدف
            goal: هدف نهایی
        
        Returns:
            AttackPlan
        """
        try:
            # استخراج JSON
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                plan_data = json.loads(json_match.group())
            else:
                # پاسخ پیش‌فرض
                plan_data = {
                    'reasoning': 'Planning failed',
                    'attack_chain': [],
                    'total_estimated_time': 0.0,
                    'overall_risk_score': 0.0,
                    'success_probability': 0.0
                }
            
            # تبدیل attack_chain به AttackStep objects
            attack_chain = []
            for step_data in plan_data.get('attack_chain', []):
                step = AttackStep(
                    step_id=step_data.get('step_id', f"STEP-{len(attack_chain)+1:03d}"),
                    step_number=step_data.get('step_number', len(attack_chain)+1),
                    attack_type=AttackType(step_data.get('attack_type', 'sql_injection')),
                    target=step_data.get('target', ''),
                    description=step_data.get('description', ''),
                    prerequisites=step_data.get('prerequisites', []),
                    estimated_time=step_data.get('estimated_time', 5.0),
                    risk_score=step_data.get('risk_score', 5.0),
                    tools_required=step_data.get('tools_required', []),
                    evasion_techniques=step_data.get('evasion_techniques', []),
                    fallback_steps=step_data.get('fallback_steps', [])
                )
                attack_chain.append(step)
            
            # ایجاد AttackPlan
            plan = AttackPlan(
                plan_id=f"PLAN-{int(time.time())}",
                goal=goal,
                target_info=target_analysis.get('target_info', {}),
                vulnerabilities=target_analysis.get('vulnerabilities', []),
                attack_chain=attack_chain,
                total_estimated_time=plan_data.get('total_estimated_time', 0.0),
                overall_risk_score=plan_data.get('overall_risk_score', 0.0),
                success_probability=plan_data.get('success_probability', 0.0),
                reasoning=plan_data.get('reasoning', '')
            )
            
            return plan
            
        except Exception as e:
            logger.error(f"Error parsing planning response: {e}")
            # بازگشت یک plan خالی
            return AttackPlan(
                plan_id=f"PLAN-{int(time.time())}",
                goal=goal,
                target_info=target_analysis.get('target_info', {}),
                vulnerabilities=target_analysis.get('vulnerabilities', []),
                attack_chain=[],
                total_estimated_time=0.0,
                overall_risk_score=0.0,
                success_probability=0.0,
                reasoning='Planning parsing failed'
            )
    
    # ==========================================================================
    # ارزیابی ریسک
    # ==========================================================================
    
    async def evaluate_risk(self, attack_plan: AttackPlan) -> Dict[str, Any]:
        """
        ارزیابی ریسک یک برنامه حمله
        
        این متد ریسک‌های مختلف را ارزیابی می‌کند:
        - ریسک شناسایی
        - ریسک قانونی
        - ریسک فنی
        - ریسک زمانی
        
        Args:
            attack_plan: برنامه حمله
        
        Returns:
            دیکشنری ارزیابی ریسک
        """
        logger.info(f"Evaluating risk for plan: {attack_plan.plan_id}")
        
        # محاسبه ریسک‌های مختلف
        detection_risk = sum(step.risk_score for step in attack_plan.attack_chain) / len(attack_plan.attack_chain) if attack_plan.attack_chain else 0
        
        risk_assessment = {
            'plan_id': attack_plan.plan_id,
            'overall_risk_score': attack_plan.overall_risk_score,
            'detection_risk': detection_risk,
            'success_probability': attack_plan.success_probability,
            'total_estimated_time': attack_plan.total_estimated_time,
            'recommendation': 'PROCEED' if attack_plan.success_probability > self.min_success_probability else 'REVISE_PLAN'
        }
        
        return risk_assessment


# ==============================================================================
# مثال استفاده
# ==============================================================================

async def example_usage():
    """مثال استفاده از Decision Agent"""
    # ایجاد agent
    agent = DecisionAgent(vllm_endpoint="http://localhost:8000/v1")
    
    # اطلاعات هدف
    target_info = {
        'ip': '192.168.1.100',
        'ports': [80, 443, 22, 3306],
        'os': 'Ubuntu 22.04',
        'services': {
            '80': 'nginx 1.18.0',
            '443': 'nginx 1.18.0 (SSL)',
            '22': 'OpenSSH 8.2',
            '3306': 'MySQL 8.0.27'
        },
        'web_technologies': ['PHP 7.4', 'WordPress 5.8']
    }
    
    # تحلیل هدف
    analysis = await agent.analyze_target(target_info)
    print(f"Vulnerabilities found: {len(analysis['vulnerabilities'])}")
    
    # طراحی برنامه حمله
    plan = await agent.plan_attack(
        target_info=target_info,
        goal='data_exfiltration',
        constraints={'max_time': 60, 'stealth_level': 'high'}
    )
    
    print(f"Attack plan: {len(plan.attack_chain)} steps")
    print(f"Success probability: {plan.success_probability:.2%}")
    
    # ارزیابی ریسک
    risk = await agent.evaluate_risk(plan)
    print(f"Risk assessment: {risk['recommendation']}")


if __name__ == "__main__":
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    asyncio.run(example_usage())
