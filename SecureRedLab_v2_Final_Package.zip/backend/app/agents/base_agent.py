#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Base Agent Class
====================================

کلاس پایه برای تمام agents در سیستم

این ماژول شامل:
- کلاس پایه Agent با قابلیت‌های مشترک
- مدیریت مدل‌های LLM (Primary، Secondary، Fallback)
- سیستم logging و monitoring
- مدیریت خطا و retry logic
- یکپارچه‌سازی با Communication Bus

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک - تنها برای استفاده در محیط‌های تحقیقاتی مجاز

LEGAL REQUIREMENTS:
- FBI Clearance
- IRB Ethics Committee Approval
- Local Police Department Authorization
- University Research Committee Approval

ONLY FOR ACADEMIC RESEARCH - تنها برای تحقیقات آکادمیک
"""

import asyncio
import json
import time
import traceback
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, Any, List, Optional, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

# Import Communication Bus
from agents.communication_bus import (
    AgentCommunicationBus,
    AgentType,
    MessagePriority,
    get_communication_bus
)

# تنظیم logger
logger = logging.getLogger(__name__)


# ==============================================================================
# Enums و Data Classes
# ==============================================================================

class ModelPriority(Enum):
    """اولویت مدل"""
    PRIMARY = "primary"        # مدل اصلی
    SECONDARY = "secondary"    # مدل پشتیبان
    FALLBACK = "fallback"      # مدل آخرین راه


class TaskStatus(Enum):
    """وضعیت task"""
    PENDING = "pending"          # در انتظار
    RUNNING = "running"          # در حال اجرا
    SUCCESS = "success"          # موفق
    FAILED = "failed"            # ناموفق
    RETRYING = "retrying"        # در حال تلاش مجدد
    CANCELLED = "cancelled"      # لغو شده


@dataclass
class ModelConfig:
    """
    پیکربندی یک مدل LLM
    
    این کلاس شامل تمام تنظیمات لازم برای استفاده از یک مدل است
    """
    model_name: str                    # نام مدل (مثلاً "deepseek-r1")
    model_path: str                    # مسیر مدل یا endpoint
    priority: ModelPriority            # اولویت مدل
    max_tokens: int = 4096             # حداکثر تعداد توکن‌های خروجی
    temperature: float = 0.7           # temperature برای sampling
    top_p: float = 0.9                 # top-p برای nucleus sampling
    timeout: int = 60                  # timeout برای درخواست (ثانیه)
    max_retries: int = 3               # حداکثر تعداد تلاش مجدد
    enabled: bool = True               # آیا مدل فعال است؟
    metadata: Dict[str, Any] = field(default_factory=dict)  # metadata اضافی
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'model_name': self.model_name,
            'model_path': self.model_path,
            'priority': self.priority.value,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'top_p': self.top_p,
            'timeout': self.timeout,
            'max_retries': self.max_retries,
            'enabled': self.enabled,
            'metadata': self.metadata
        }


@dataclass
class TaskResult:
    """
    نتیجه یک task
    
    این کلاس شامل تمام اطلاعات مربوط به نتیجه اجرای یک task است
    """
    task_id: str                       # شناسه task
    status: TaskStatus                 # وضعیت task
    result: Optional[Any] = None       # نتیجه (در صورت موفقیت)
    error: Optional[str] = None        # پیام خطا (در صورت شکست)
    model_used: Optional[str] = None   # نام مدلی که استفاده شد
    execution_time: float = 0.0        # زمان اجرا (ثانیه)
    retries: int = 0                   # تعداد تلاش‌های مجدد
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'task_id': self.task_id,
            'status': self.status.value,
            'result': self.result,
            'error': self.error,
            'model_used': self.model_used,
            'execution_time': self.execution_time,
            'retries': self.retries,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata
        }
    
    @property
    def is_success(self) -> bool:
        """آیا task موفق بود؟"""
        return self.status == TaskStatus.SUCCESS
    
    @property
    def is_failed(self) -> bool:
        """آیا task ناموفق بود؟"""
        return self.status == TaskStatus.FAILED


# ==============================================================================
# Base Agent Class
# ==============================================================================

class BaseAgent(ABC):
    """
    کلاس پایه برای تمام agents
    
    این کلاس شامل قابلیت‌های مشترک بین تمام agents است:
    - مدیریت مدل‌های LLM (Primary، Secondary، Fallback)
    - ارتباط با Communication Bus
    - مدیریت خطا و retry logic
    - Logging و monitoring
    - آمارگیری
    
    هر agent باید از این کلاس ارث‌بری کند و متدهای abstract را پیاده‌سازی کند.
    
    استفاده:
        class MyAgent(BaseAgent):
            def __init__(self):
                super().__init__(
                    agent_type=AgentType.DECISION,
                    agent_name="My Decision Agent"
                )
                
                # تنظیم مدل‌ها
                self.add_model(ModelConfig(
                    model_name="deepseek-r1",
                    model_path="http://localhost:8000/v1",
                    priority=ModelPriority.PRIMARY
                ))
            
            async def _execute_task(self, task_data: Dict) -> Any:
                # پیاده‌سازی منطق اصلی agent
                pass
    """
    
    def __init__(
        self,
        agent_type: AgentType,
        agent_name: str,
        communication_bus: Optional[AgentCommunicationBus] = None
    ):
        """
        مقداردهی اولیه agent
        
        Args:
            agent_type: نوع agent (Decision، Execution، Analysis، Vision)
            agent_name: نام agent (برای logging)
            communication_bus: باس ارتباطی (اگر None باشد، از singleton استفاده می‌شود)
        """
        self.agent_type = agent_type
        self.agent_name = agent_name
        
        # دریافت Communication Bus
        self.bus = communication_bus or get_communication_bus()
        
        # مدل‌های LLM (به ترتیب اولویت)
        self.models: Dict[ModelPriority, ModelConfig] = {}
        
        # وضعیت agent
        self.is_running = False
        self.current_task_id: Optional[str] = None
        
        # آمار
        self.stats = {
            'tasks_completed': 0,
            'tasks_failed': 0,
            'total_execution_time': 0.0,
            'models_usage': {},  # تعداد استفاده از هر مدل
            'start_time': datetime.now()
        }
        
        # تاریخچه tasks
        self.task_history: List[TaskResult] = []
        
        logger.info(f"{self.agent_name} ({self.agent_type.value}) initialized")
    
    # ==========================================================================
    # مدیریت مدل‌ها
    # ==========================================================================
    
    def add_model(self, model_config: ModelConfig):
        """
        اضافه کردن یک مدل به agent
        
        Args:
            model_config: پیکربندی مدل
        """
        self.models[model_config.priority] = model_config
        logger.info(
            f"{self.agent_name}: Model added - {model_config.model_name} "
            f"({model_config.priority.value})"
        )
    
    def get_model(self, priority: ModelPriority) -> Optional[ModelConfig]:
        """
        دریافت یک مدل بر اساس اولویت
        
        Args:
            priority: اولویت مدل
        
        Returns:
            پیکربندی مدل یا None
        """
        return self.models.get(priority)
    
    def get_available_model(self) -> Optional[ModelConfig]:
        """
        دریافت اولین مدل در دسترس (به ترتیب اولویت)
        
        Returns:
            پیکربندی مدل یا None
        """
        # ترتیب اولویت: Primary -> Secondary -> Fallback
        for priority in [ModelPriority.PRIMARY, ModelPriority.SECONDARY, ModelPriority.FALLBACK]:
            model = self.models.get(priority)
            if model and model.enabled:
                return model
        
        return None
    
    async def call_llm(
        self,
        prompt: str,
        model_priority: Optional[ModelPriority] = None,
        **kwargs
    ) -> str:
        """
        فراخوانی مدل LLM
        
        این متد به صورت خودکار:
        1. مدل مناسب را انتخاب می‌کند
        2. درخواست را ارسال می‌کند
        3. در صورت خطا، به مدل بعدی fallback می‌کند
        4. آمار را به‌روزرسانی می‌کند
        
        Args:
            prompt: prompt ورودی
            model_priority: اولویت مدل (اگر None باشد، از Primary شروع می‌کند)
            **kwargs: پارامترهای اضافی (temperature، max_tokens، etc.)
        
        Returns:
            پاسخ مدل (string)
        
        Raises:
            Exception: اگر هیچ مدلی در دسترس نباشد یا همه مدل‌ها خطا دهند
        """
        # تعیین ترتیب مدل‌ها
        if model_priority:
            priorities = [model_priority]
        else:
            priorities = [ModelPriority.PRIMARY, ModelPriority.SECONDARY, ModelPriority.FALLBACK]
        
        last_error = None
        
        # تلاش با هر مدل
        for priority in priorities:
            model = self.models.get(priority)
            
            if not model or not model.enabled:
                continue
            
            try:
                logger.debug(f"{self.agent_name}: Calling {model.model_name}...")
                
                # فراخوانی مدل (این متد باید توسط subclass پیاده‌سازی شود)
                response = await self._call_llm_impl(model, prompt, **kwargs)
                
                # به‌روزرسانی آمار
                self.stats['models_usage'][model.model_name] = \
                    self.stats['models_usage'].get(model.model_name, 0) + 1
                
                logger.debug(f"{self.agent_name}: {model.model_name} responded successfully")
                
                return response
                
            except Exception as e:
                last_error = e
                logger.warning(
                    f"{self.agent_name}: {model.model_name} failed - {str(e)}"
                )
                
                # اگر مدل بعدی وجود دارد، به آن fallback کن
                continue
        
        # اگر همه مدل‌ها خطا دادند
        error_msg = f"All models failed. Last error: {str(last_error)}"
        logger.error(f"{self.agent_name}: {error_msg}")
        raise Exception(error_msg)
    
    @abstractmethod
    async def _call_llm_impl(
        self,
        model: ModelConfig,
        prompt: str,
        **kwargs
    ) -> str:
        """
        پیاده‌سازی واقعی فراخوانی LLM
        
        این متد باید توسط هر subclass پیاده‌سازی شود.
        
        Args:
            model: پیکربندی مدل
            prompt: prompt ورودی
            **kwargs: پارامترهای اضافی
        
        Returns:
            پاسخ مدل
        """
        pass
    
    # ==========================================================================
    # اجرای Task
    # ==========================================================================
    
    async def execute_task(
        self,
        task_id: str,
        task_data: Dict[str, Any],
        retry_on_failure: bool = True
    ) -> TaskResult:
        """
        اجرای یک task
        
        این متد:
        1. task را اجرا می‌کند
        2. در صورت خطا، retry می‌کند
        3. نتیجه را در تاریخچه ذخیره می‌کند
        4. آمار را به‌روزرسانی می‌کند
        5. event را منتشر می‌کند
        
        Args:
            task_id: شناسه task
            task_data: داده‌های task
            retry_on_failure: آیا در صورت خطا retry شود؟
        
        Returns:
            نتیجه task
        """
        start_time = time.time()
        self.current_task_id = task_id
        self.is_running = True
        
        # ایجاد TaskResult
        result = TaskResult(
            task_id=task_id,
            status=TaskStatus.RUNNING
        )
        
        # تعیین حداکثر تعداد retry
        max_retries = 3 if retry_on_failure else 0
        
        # تلاش برای اجرای task
        for attempt in range(max_retries + 1):
            try:
                logger.info(
                    f"{self.agent_name}: Executing task {task_id} "
                    f"(attempt {attempt + 1}/{max_retries + 1})"
                )
                
                # اجرای task (این متد باید توسط subclass پیاده‌سازی شود)
                task_result = await self._execute_task(task_data)
                
                # موفقیت
                result.status = TaskStatus.SUCCESS
                result.result = task_result
                result.execution_time = time.time() - start_time
                result.retries = attempt
                
                # به‌روزرسانی آمار
                self.stats['tasks_completed'] += 1
                self.stats['total_execution_time'] += result.execution_time
                
                logger.info(
                    f"{self.agent_name}: Task {task_id} completed successfully "
                    f"in {result.execution_time:.2f}s"
                )
                
                break
                
            except Exception as e:
                logger.error(
                    f"{self.agent_name}: Task {task_id} failed (attempt {attempt + 1}) - {str(e)}"
                )
                logger.debug(traceback.format_exc())
                
                # اگر آخرین تلاش بود
                if attempt == max_retries:
                    result.status = TaskStatus.FAILED
                    result.error = str(e)
                    result.execution_time = time.time() - start_time
                    result.retries = attempt
                    
                    # به‌روزرسانی آمار
                    self.stats['tasks_failed'] += 1
                    
                else:
                    # تلاش مجدد
                    result.status = TaskStatus.RETRYING
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
        
        # ذخیره در تاریخچه
        self.task_history.append(result)
        
        # انتشار event
        await self.bus.publish_event(
            f"task_{result.status.value}",
            {
                'agent_type': self.agent_type.value,
                'agent_name': self.agent_name,
                'task_id': task_id,
                'status': result.status.value,
                'execution_time': result.execution_time
            }
        )
        
        self.is_running = False
        self.current_task_id = None
        
        return result
    
    @abstractmethod
    async def _execute_task(self, task_data: Dict[str, Any]) -> Any:
        """
        پیاده‌سازی واقعی اجرای task
        
        این متد باید توسط هر subclass پیاده‌سازی شود.
        
        Args:
            task_data: داده‌های task
        
        Returns:
            نتیجه task
        """
        pass
    
    # ==========================================================================
    # ارتباط با Communication Bus
    # ==========================================================================
    
    async def send_message(
        self,
        to_agent: AgentType,
        message_type: str,
        content: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL
    ) -> str:
        """
        ارسال پیام به agent دیگر
        
        Args:
            to_agent: agent گیرنده
            message_type: نوع پیام
            content: محتوای پیام
            priority: اولویت پیام
        
        Returns:
            message_id
        """
        return await self.bus.send_message(
            from_agent=self.agent_type,
            to_agent=to_agent,
            message_type=message_type,
            content=content,
            priority=priority
        )
    
    async def receive_message(self, timeout: Optional[float] = None):
        """
        دریافت پیام
        
        Args:
            timeout: timeout برای دریافت پیام (ثانیه)
        
        Returns:
            پیام دریافت شده یا None
        """
        return await self.bus.receive_message(self.agent_type, timeout=timeout)
    
    async def broadcast_message(
        self,
        message_type: str,
        content: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL
    ) -> List[str]:
        """
        ارسال پیام به تمام agents
        
        Args:
            message_type: نوع پیام
            content: محتوای پیام
            priority: اولویت پیام
        
        Returns:
            لیست message_id ها
        """
        return await self.bus.broadcast_message(
            from_agent=self.agent_type,
            message_type=message_type,
            content=content,
            priority=priority
        )
    
    def update_context(self, key: str, value: Any):
        """به‌روزرسانی context مشترک"""
        self.bus.update_context(key, value)
    
    def get_context(self, key: str) -> Any:
        """دریافت context"""
        return self.bus.get_context(key)
    
    # ==========================================================================
    # آمار و Monitoring
    # ==========================================================================
    
    def get_stats(self) -> Dict:
        """
        دریافت آمار agent
        
        Returns:
            دیکشنری آمار
        """
        uptime = (datetime.now() - self.stats['start_time']).total_seconds()
        
        return {
            'agent_type': self.agent_type.value,
            'agent_name': self.agent_name,
            'is_running': self.is_running,
            'current_task_id': self.current_task_id,
            'tasks_completed': self.stats['tasks_completed'],
            'tasks_failed': self.stats['tasks_failed'],
            'total_execution_time': self.stats['total_execution_time'],
            'average_execution_time': (
                self.stats['total_execution_time'] / self.stats['tasks_completed']
                if self.stats['tasks_completed'] > 0 else 0
            ),
            'models_usage': self.stats['models_usage'],
            'uptime_seconds': uptime,
            'task_history_size': len(self.task_history)
        }
    
    def get_task_history(self, limit: Optional[int] = None) -> List[TaskResult]:
        """
        دریافت تاریخچه tasks
        
        Args:
            limit: تعداد tasks اخیر (None = همه)
        
        Returns:
            لیست TaskResult ها
        """
        if limit:
            return self.task_history[-limit:]
        else:
            return self.task_history
    
    def reset_stats(self):
        """ریست آمار"""
        self.stats = {
            'tasks_completed': 0,
            'tasks_failed': 0,
            'total_execution_time': 0.0,
            'models_usage': {},
            'start_time': datetime.now()
        }
        self.task_history.clear()
        logger.info(f"{self.agent_name}: Stats reset")


# ==============================================================================
# مثال استفاده
# ==============================================================================

class ExampleAgent(BaseAgent):
    """
    مثال پیاده‌سازی یک agent
    """
    
    def __init__(self):
        super().__init__(
            agent_type=AgentType.DECISION,
            agent_name="Example Decision Agent"
        )
        
        # اضافه کردن مدل‌ها
        self.add_model(ModelConfig(
            model_name="deepseek-r1",
            model_path="http://localhost:8000/v1",
            priority=ModelPriority.PRIMARY,
            max_tokens=4096,
            temperature=0.7
        ))
        
        self.add_model(ModelConfig(
            model_name="nemotron-cascade",
            model_path="http://localhost:8001/v1",
            priority=ModelPriority.SECONDARY,
            max_tokens=4096,
            temperature=0.7
        ))
    
    async def _call_llm_impl(self, model: ModelConfig, prompt: str, **kwargs) -> str:
        """پیاده‌سازی فراخوانی LLM"""
        # در اینجا باید کد واقعی فراخوانی API نوشته شود
        # برای مثال، از OpenAI client استفاده می‌کنیم
        
        # Simulate API call
        await asyncio.sleep(1)
        return f"Response from {model.model_name}: {prompt[:50]}..."
    
    async def _execute_task(self, task_data: Dict[str, Any]) -> Any:
        """پیاده‌سازی اجرای task"""
        # منطق اصلی agent
        prompt = task_data.get('prompt', '')
        response = await self.call_llm(prompt)
        
        return {
            'response': response,
            'task_data': task_data
        }


async def example_usage():
    """مثال استفاده از BaseAgent"""
    # ایجاد agent
    agent = ExampleAgent()
    
    # اجرای یک task
    result = await agent.execute_task(
        task_id="task_001",
        task_data={'prompt': 'Analyze this target: 192.168.1.100'}
    )
    
    print(f"Task Status: {result.status.value}")
    print(f"Result: {result.result}")
    print(f"Execution Time: {result.execution_time:.2f}s")
    
    # دریافت آمار
    stats = agent.get_stats()
    print(f"Stats: {json.dumps(stats, indent=2)}")


if __name__ == "__main__":
    # تنظیم logging
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # اجرای مثال
    asyncio.run(example_usage())
