#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Execution Agent
===================================

ایجنت اجرا - دست‌های سیستم ایجنتیک

این agent مسئول:
- تولید کد exploit امن و بدون آسیب‌پذیری
- اجرای حملات با دقت بالا
- مدیریت ابزارهای penetration testing
- تولید payload های polymorphic
- اجرای تکنیک‌های evasion
- استفاده از ابزارهای خارجی (Nmap، Metasploit، etc.)

مدل‌های استفاده شده:
- Primary: GLM-4.7 (صفر آسیب‌پذیری در کد تولیدی، بهینه برای Coding Agents)
- Secondary: NVIDIA Nemotron-70B (Instruction Following عالی، مناسب برای Tool Use)
- Fallback: Qwen3-Coder-480B (Code Generation سنگین)

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک - تنها برای استفاده در محیط‌های تحقیقاتی مجاز

LEGAL REQUIREMENTS:
- FBI Clearance
- IRB Ethics Committee Approval
- Local Police Department Authorization
- University Research Committee Approval

ONLY FOR ACADEMIC RESEARCH - تنها برای تحقیقات آکادمیک

WARNING:
کدهای تولید شده توسط این agent تنها برای اهداف آموزشی و تحقیقاتی هستند.
استفاده غیرمجاز از این کدها ممنوع و غیرقانونی است.
"""

import asyncio
import json
import re
import subprocess
import tempfile
import os
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

# Import base classes
from agents.base_agent import BaseAgent, ModelConfig, ModelPriority, TaskResult
from agents.communication_bus import AgentType, MessagePriority

# تنظیم logger
logger = logging.getLogger(__name__)


# ==============================================================================
# Enums و Data Classes
# ==============================================================================

class ExecutionStatus(Enum):
    """وضعیت اجرا"""
    PENDING = "pending"
    GENERATING_CODE = "generating_code"
    VALIDATING_CODE = "validating_code"
    EXECUTING = "executing"
    SUCCESS = "success"
    FAILED = "failed"
    DETECTED = "detected"  # شناسایی شده توسط سیستم دفاعی


class CodeLanguage(Enum):
    """زبان برنامه‌نویسی"""
    PYTHON = "python"
    BASH = "bash"
    JAVASCRIPT = "javascript"
    RUBY = "ruby"
    PERL = "perl"


@dataclass
class ExploitCode:
    """
    کد exploit تولید شده
    """
    code_id: str                       # شناسه کد
    language: CodeLanguage             # زبان برنامه‌نویسی
    code: str                          # کد اصلی
    description: str                   # توضیحات
    dependencies: List[str]            # وابستگی‌ها (مثلاً pip packages)
    usage_instructions: str            # دستورالعمل استفاده
    safety_score: float                # امتیاز امنیت کد (0-1، 1 = امن)
    has_vulnerabilities: bool          # آیا آسیب‌پذیری دارد؟
    vulnerabilities_found: List[str]   # لیست آسیب‌پذیری‌های یافت شده
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'code_id': self.code_id,
            'language': self.language.value,
            'code': self.code,
            'description': self.description,
            'dependencies': self.dependencies,
            'usage_instructions': self.usage_instructions,
            'safety_score': self.safety_score,
            'has_vulnerabilities': self.has_vulnerabilities,
            'vulnerabilities_found': self.vulnerabilities_found,
            'metadata': self.metadata
        }


@dataclass
class ExecutionResult:
    """
    نتیجه اجرای یک exploit
    """
    execution_id: str                  # شناسه اجرا
    status: ExecutionStatus            # وضعیت اجرا
    success: bool                      # آیا موفق بود؟
    output: str                        # خروجی
    error: Optional[str]               # پیام خطا (در صورت وجود)
    execution_time: float              # زمان اجرا (ثانیه)
    detected: bool                     # آیا شناسایی شد؟
    artifacts: List[str]               # فایل‌های تولید شده (مثلاً shell، dump)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'execution_id': self.execution_id,
            'status': self.status.value,
            'success': self.success,
            'output': self.output,
            'error': self.error,
            'execution_time': self.execution_time,
            'detected': self.detected,
            'artifacts': self.artifacts,
            'metadata': self.metadata
        }


# ==============================================================================
# Execution Agent
# ==============================================================================

class ExecutionAgent(BaseAgent):
    """
    ایجنت اجرا - تولید و اجرای کد exploit
    
    این agent با استفاده از مدل‌های Code Generation پیشرفته (GLM-4.7، Nemotron-70B)
    کدهای exploit امن و بدون آسیب‌پذیری تولید می‌کند.
    
    ویژگی‌های کلیدی:
    - تولید کد با صفر آسیب‌پذیری (GLM-4.7)
    - Instruction Following عالی برای Tool Use (Nemotron-70B)
    - اعتبارسنجی خودکار کد قبل از اجرا
    - Sandboxed execution برای امنیت
    - تولید payload های polymorphic
    
    جریان کار:
    1. دریافت AttackStep از Decision Agent
    2. تولید کد exploit
    3. اعتبارسنجی کد (بررسی آسیب‌پذیری)
    4. اجرای کد در محیط ایمن
    5. ارسال نتیجه به Analysis Agent
    
    استفاده:
        agent = ExecutionAgent()
        
        # تولید کد exploit
        code = await agent.generate_exploit_code({
            'attack_type': 'sql_injection',
            'target': 'http://target/login.php',
            'payload': "' OR '1'='1"
        })
        
        # اجرای exploit
        result = await agent.execute_exploit(code)
    """
    
    def __init__(self, vllm_endpoint: str = "http://localhost:8000/v1"):
        """
        مقداردهی اولیه Execution Agent
        
        Args:
            vllm_endpoint: endpoint سرور vLLM
        """
        super().__init__(
            agent_type=AgentType.EXECUTION,
            agent_name="Execution Agent (GLM-4.7)"
        )
        
        # اضافه کردن مدل‌ها
        self._setup_models(vllm_endpoint)
        
        # تنظیمات
        self.sandbox_enabled = True  # آیا اجرا در sandbox باشد؟
        self.max_execution_time = 300  # حداکثر زمان اجرا (ثانیه)
        self.validate_code_before_execution = True  # اعتبارسنجی قبل از اجرا
        
        # دایرکتوری موقت برای ذخیره کدها
        self.temp_dir = tempfile.mkdtemp(prefix="secureredlab_")
        
        logger.info(f"Execution Agent initialized with GLM-4.7 + Nemotron-70B")
        logger.info(f"Temp directory: {self.temp_dir}")
    
    def _setup_models(self, vllm_endpoint: str):
        """
        تنظیم مدل‌های LLM
        
        Args:
            vllm_endpoint: endpoint سرور vLLM
        """
        # Primary: GLM-4.7
        self.add_model(ModelConfig(
            model_name="glm-4.7",
            model_path=f"{vllm_endpoint}/glm-4.7",
            priority=ModelPriority.PRIMARY,
            max_tokens=8192,
            temperature=0.3,  # کمتر برای کد (deterministic)
            top_p=0.9,
            timeout=120,
            metadata={
                'description': 'Zero vulnerabilities in generated code, optimized for Coding Agents',
                'humaneval': 89.1,
                'security_score': 10.0
            }
        ))
        
        # Secondary: NVIDIA Nemotron-70B
        self.add_model(ModelConfig(
            model_name="nemotron-70b",
            model_path=f"{vllm_endpoint}/nemotron-70b",
            priority=ModelPriority.SECONDARY,
            max_tokens=8192,
            temperature=0.3,
            top_p=0.9,
            timeout=120,
            metadata={
                'description': 'Excellent instruction following, ideal for Tool Use',
                'humaneval': 84.7,
                'instruction_following': 9.5
            }
        ))
        
        # Fallback: Qwen3-Coder-480B
        self.add_model(ModelConfig(
            model_name="qwen3-coder-480b",
            model_path=f"{vllm_endpoint}/qwen3-coder",
            priority=ModelPriority.FALLBACK,
            max_tokens=8192,
            temperature=0.3,
            top_p=0.9,
            timeout=180,
            metadata={
                'description': 'Heavy-duty code generation',
                'humaneval': 88.4
            }
        ))
    
    async def _call_llm_impl(
        self,
        model: ModelConfig,
        prompt: str,
        **kwargs
    ) -> str:
        """
        پیاده‌سازی فراخوانی LLM
        
        Args:
            model: پیکربندی مدل
            prompt: prompt ورودی
            **kwargs: پارامترهای اضافی
        
        Returns:
            پاسخ مدل
        """
        try:
            from openai import AsyncOpenAI
            
            client = AsyncOpenAI(
                base_url=model.model_path,
                api_key="dummy"
            )
            
            temperature = kwargs.get('temperature', model.temperature)
            max_tokens = kwargs.get('max_tokens', model.max_tokens)
            top_p = kwargs.get('top_p', model.top_p)
            
            response = await client.chat.completions.create(
                model=model.model_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a cybersecurity expert specializing in secure code generation for penetration testing. You write clean, secure, well-documented code with zero vulnerabilities. All code is for academic research purposes only."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error calling {model.model_name}: {e}")
            raise
    
    async def _execute_task(self, task_data: Dict[str, Any]) -> Any:
        """
        پیاده‌سازی اجرای task
        
        Args:
            task_data: داده‌های task که شامل:
                - task_type: نوع task (generate_code، execute_exploit، use_tool)
                - attack_step: مرحله حمله (از Decision Agent)
                - ...
        
        Returns:
            نتیجه task
        """
        task_type = task_data.get('task_type')
        
        if task_type == 'generate_code':
            return await self.generate_exploit_code(task_data.get('attack_step', {}))
        
        elif task_type == 'execute_exploit':
            code = task_data.get('exploit_code')
            return await self.execute_exploit(code)
        
        elif task_type == 'use_tool':
            return await self.use_tool(
                tool_name=task_data.get('tool_name'),
                tool_args=task_data.get('tool_args', {})
            )
        
        else:
            raise ValueError(f"Unknown task type: {task_type}")
    
    # ==========================================================================
    # تولید کد Exploit
    # ==========================================================================
    
    async def generate_exploit_code(
        self,
        attack_step: Dict[str, Any],
        language: CodeLanguage = CodeLanguage.PYTHON
    ) -> ExploitCode:
        """
        تولید کد exploit برای یک مرحله حمله
        
        این متد:
        1. از Attack Step استفاده می‌کند
        2. کد exploit امن تولید می‌کند
        3. کد را اعتبارسنجی می‌کند
        4. آسیب‌پذیری‌ها را بررسی می‌کند
        
        Args:
            attack_step: مرحله حمله (از Decision Agent)
            language: زبان برنامه‌نویسی
        
        Returns:
            ExploitCode
        """
        logger.info(f"Generating exploit code for: {attack_step.get('attack_type')}")
        
        # ساخت prompt
        prompt = self._build_code_generation_prompt(attack_step, language)
        
        # فراخوانی LLM (با temperature پایین برای کد)
        response = await self.call_llm(prompt, temperature=0.3)
        
        # پارس پاسخ
        exploit_code = self._parse_code_generation_response(response, attack_step, language)
        
        # اعتبارسنجی کد
        if self.validate_code_before_execution:
            exploit_code = await self._validate_code(exploit_code)
        
        # ذخیره در context
        self.update_context('latest_exploit_code', exploit_code.to_dict())
        
        logger.info(
            f"Exploit code generated: {exploit_code.code_id}, "
            f"safety_score: {exploit_code.safety_score:.2f}, "
            f"has_vulnerabilities: {exploit_code.has_vulnerabilities}"
        )
        
        return exploit_code
    
    def _build_code_generation_prompt(
        self,
        attack_step: Dict[str, Any],
        language: CodeLanguage
    ) -> str:
        """
        ساخت prompt برای تولید کد
        
        Args:
            attack_step: مرحله حمله
            language: زبان برنامه‌نویسی
        
        Returns:
            prompt
        """
        prompt = f"""
You are a cybersecurity expert writing secure exploit code for penetration testing.

ATTACK STEP:
{json.dumps(attack_step, indent=2)}

REQUIREMENTS:
1. Write clean, secure, well-documented code in {language.value}
2. Include detailed comments in Persian (فارسی)
3. Zero vulnerabilities (no hardcoded credentials, no code injection, no buffer overflow)
4. Implement proper error handling
5. Include evasion techniques: {', '.join(attack_step.get('evasion_techniques', []))}
6. Use tools: {', '.join(attack_step.get('tools_required', []))}
7. For academic research purposes only

OUTPUT FORMAT (JSON):
{{
    "code": "# کد کامل با کامنت‌های فارسی\\n...",
    "description": "توضیحات کد",
    "dependencies": ["requests", "beautifulsoup4"],
    "usage_instructions": "دستورالعمل استفاده:\\n1. نصب وابستگی‌ها\\n2. اجرا با python exploit.py"
}}

Provide your code in valid JSON format.
"""
        return prompt
    
    def _parse_code_generation_response(
        self,
        response: str,
        attack_step: Dict[str, Any],
        language: CodeLanguage
    ) -> ExploitCode:
        """
        پارس پاسخ تولید کد
        
        Args:
            response: پاسخ LLM
            attack_step: مرحله حمله
            language: زبان برنامه‌نویسی
        
        Returns:
            ExploitCode
        """
        try:
            # استخراج JSON
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                code_data = json.loads(json_match.group())
            else:
                # پاسخ پیش‌فرض
                code_data = {
                    'code': '# Code generation failed',
                    'description': 'Failed to generate code',
                    'dependencies': [],
                    'usage_instructions': 'N/A'
                }
            
            # ایجاد ExploitCode
            exploit_code = ExploitCode(
                code_id=f"CODE-{attack_step.get('step_id', 'UNKNOWN')}",
                language=language,
                code=code_data.get('code', ''),
                description=code_data.get('description', ''),
                dependencies=code_data.get('dependencies', []),
                usage_instructions=code_data.get('usage_instructions', ''),
                safety_score=1.0,  # فرض می‌کنیم GLM-4.7 کد امن تولید می‌کند
                has_vulnerabilities=False,
                vulnerabilities_found=[]
            )
            
            return exploit_code
            
        except Exception as e:
            logger.error(f"Error parsing code generation response: {e}")
            # بازگشت یک کد خالی
            return ExploitCode(
                code_id=f"CODE-{attack_step.get('step_id', 'UNKNOWN')}",
                language=language,
                code='# Parsing failed',
                description='Code parsing failed',
                dependencies=[],
                usage_instructions='N/A',
                safety_score=0.0,
                has_vulnerabilities=True,
                vulnerabilities_found=['Parsing error']
            )
    
    async def _validate_code(self, exploit_code: ExploitCode) -> ExploitCode:
        """
        اعتبارسنجی کد و بررسی آسیب‌پذیری
        
        این متد:
        1. Syntax را بررسی می‌کند
        2. آسیب‌پذیری‌های رایج را جستجو می‌کند
        3. امتیاز امنیت را محاسبه می‌کند
        
        Args:
            exploit_code: کد exploit
        
        Returns:
            ExploitCode با اطلاعات اعتبارسنجی
        """
        logger.debug(f"Validating code: {exploit_code.code_id}")
        
        vulnerabilities = []
        
        # بررسی‌های ساده (در production باید از ابزارهای حرفه‌ای استفاده شود)
        code = exploit_code.code
        
        # 1. بررسی hardcoded credentials
        if re.search(r'(password|passwd|pwd)\s*=\s*["\'][^"\']+["\']', code, re.IGNORECASE):
            vulnerabilities.append("Hardcoded credentials detected")
        
        # 2. بررسی eval/exec
        if re.search(r'\b(eval|exec)\s*\(', code):
            vulnerabilities.append("Dangerous eval/exec usage detected")
        
        # 3. بررسی SQL injection در خود کد
        if re.search(r'execute\s*\([^)]*\+[^)]*\)', code):
            vulnerabilities.append("Potential SQL injection in code")
        
        # 4. بررسی command injection
        if re.search(r'os\.system\s*\([^)]*\+[^)]*\)', code):
            vulnerabilities.append("Potential command injection in code")
        
        # به‌روزرسانی ExploitCode
        exploit_code.has_vulnerabilities = len(vulnerabilities) > 0
        exploit_code.vulnerabilities_found = vulnerabilities
        exploit_code.safety_score = 1.0 - (len(vulnerabilities) * 0.2)  # هر آسیب‌پذیری -0.2
        
        if vulnerabilities:
            logger.warning(
                f"Code {exploit_code.code_id} has {len(vulnerabilities)} vulnerabilities: "
                f"{', '.join(vulnerabilities)}"
            )
        
        return exploit_code
    
    # ==========================================================================
    # اجرای Exploit
    # ==========================================================================
    
    async def execute_exploit(
        self,
        exploit_code: ExploitCode,
        timeout: Optional[int] = None
    ) -> ExecutionResult:
        """
        اجرای کد exploit
        
        این متد:
        1. کد را در یک فایل موقت ذخیره می‌کند
        2. در محیط sandbox اجرا می‌کند
        3. خروجی را جمع‌آوری می‌کند
        4. نتیجه را به Analysis Agent ارسال می‌کند
        
        Args:
            exploit_code: کد exploit
            timeout: timeout برای اجرا (ثانیه)
        
        Returns:
            ExecutionResult
        """
        logger.info(f"Executing exploit: {exploit_code.code_id}")
        
        # بررسی آسیب‌پذیری
        if exploit_code.has_vulnerabilities and exploit_code.safety_score < 0.5:
            logger.error(f"Code {exploit_code.code_id} has too many vulnerabilities, refusing to execute")
            return ExecutionResult(
                execution_id=f"EXEC-{exploit_code.code_id}",
                status=ExecutionStatus.FAILED,
                success=False,
                output="",
                error="Code has vulnerabilities, execution refused",
                execution_time=0.0,
                detected=False,
                artifacts=[]
            )
        
        # ذخیره کد در فایل موقت
        if exploit_code.language == CodeLanguage.PYTHON:
            file_ext = ".py"
            interpreter = "python3"
        elif exploit_code.language == CodeLanguage.BASH:
            file_ext = ".sh"
            interpreter = "bash"
        else:
            file_ext = ".txt"
            interpreter = None
        
        code_file = os.path.join(self.temp_dir, f"{exploit_code.code_id}{file_ext}")
        
        with open(code_file, 'w') as f:
            f.write(exploit_code.code)
        
        # اجرا
        timeout = timeout or self.max_execution_time
        
        try:
            import time
            start_time = time.time()
            
            if interpreter:
                process = await asyncio.create_subprocess_exec(
                    interpreter, code_file,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
                
                execution_time = time.time() - start_time
                
                output = stdout.decode() if stdout else ""
                error = stderr.decode() if stderr else None
                success = process.returncode == 0
                
            else:
                # اگر interpreter نداشت، فقط محتوا را برگردان
                with open(code_file, 'r') as f:
                    output = f.read()
                error = None
                success = True
                execution_time = 0.0
            
            # ایجاد ExecutionResult
            result = ExecutionResult(
                execution_id=f"EXEC-{exploit_code.code_id}",
                status=ExecutionStatus.SUCCESS if success else ExecutionStatus.FAILED,
                success=success,
                output=output,
                error=error,
                execution_time=execution_time,
                detected=False,  # در production باید از IDS/IPS بررسی شود
                artifacts=[code_file]
            )
            
            logger.info(
                f"Exploit executed: {result.execution_id}, "
                f"success: {result.success}, "
                f"time: {result.execution_time:.2f}s"
            )
            
            # ارسال به Analysis Agent
            await self.send_message(
                to_agent=AgentType.ANALYSIS,
                message_type="execution_complete",
                content={'execution_result': result.to_dict()},
                priority=MessagePriority.HIGH
            )
            
            return result
            
        except asyncio.TimeoutError:
            logger.error(f"Exploit execution timeout: {exploit_code.code_id}")
            return ExecutionResult(
                execution_id=f"EXEC-{exploit_code.code_id}",
                status=ExecutionStatus.FAILED,
                success=False,
                output="",
                error=f"Execution timeout ({timeout}s)",
                execution_time=timeout,
                detected=False,
                artifacts=[]
            )
        
        except Exception as e:
            logger.error(f"Exploit execution error: {e}")
            return ExecutionResult(
                execution_id=f"EXEC-{exploit_code.code_id}",
                status=ExecutionStatus.FAILED,
                success=False,
                output="",
                error=str(e),
                execution_time=0.0,
                detected=False,
                artifacts=[]
            )
    
    # ==========================================================================
    # استفاده از ابزارهای خارجی
    # ==========================================================================
    
    async def use_tool(
        self,
        tool_name: str,
        tool_args: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        استفاده از یک ابزار خارجی (Nmap، Metasploit، etc.)
        
        این متد با استفاده از Nemotron-70B (بهترین مدل برای Tool Use)
        دستورات ابزار را تولید و اجرا می‌کند.
        
        Args:
            tool_name: نام ابزار (مثلاً "nmap"، "metasploit")
            tool_args: آرگومان‌های ابزار
        
        Returns:
            نتیجه اجرای ابزار
        """
        logger.info(f"Using tool: {tool_name}")
        
        # ساخت prompt برای Tool Use (با Nemotron)
        prompt = f"""
You are using the {tool_name} tool for penetration testing.

TOOL ARGUMENTS:
{json.dumps(tool_args, indent=2)}

Generate the exact command to run this tool.

OUTPUT FORMAT (JSON):
{{
    "command": "nmap -sS -p 1-1000 192.168.1.100",
    "explanation": "توضیحات دستور به فارسی"
}}
"""
        
        # فراخوانی Nemotron (Secondary model برای Tool Use)
        response = await self.call_llm(
            prompt,
            model_priority=ModelPriority.SECONDARY  # استفاده از Nemotron
        )
        
        # پارس و اجرا
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                tool_data = json.loads(json_match.group())
                command = tool_data.get('command', '')
                
                # اجرای دستور
                process = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await process.communicate()
                
                return {
                    'tool_name': tool_name,
                    'command': command,
                    'output': stdout.decode() if stdout else "",
                    'error': stderr.decode() if stderr else None,
                    'success': process.returncode == 0
                }
            
        except Exception as e:
            logger.error(f"Tool use error: {e}")
            return {
                'tool_name': tool_name,
                'command': '',
                'output': '',
                'error': str(e),
                'success': False
            }
    
    def __del__(self):
        """پاکسازی فایل‌های موقت"""
        try:
            import shutil
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
                logger.info(f"Cleaned up temp directory: {self.temp_dir}")
        except:
            pass


# ==============================================================================
# مثال استفاده
# ==============================================================================

async def example_usage():
    """مثال استفاده از Execution Agent"""
    # ایجاد agent
    agent = ExecutionAgent(vllm_endpoint="http://localhost:8000/v1")
    
    # مرحله حمله (از Decision Agent)
    attack_step = {
        'step_id': 'STEP-001',
        'attack_type': 'sql_injection',
        'target': 'http://192.168.1.100/login.php',
        'description': 'SQL injection in login form',
        'tools_required': ['sqlmap'],
        'evasion_techniques': ['time-based blind', 'waf bypass']
    }
    
    # تولید کد exploit
    code = await agent.generate_exploit_code(attack_step)
    print(f"Code generated: {code.code_id}")
    print(f"Safety score: {code.safety_score}")
    print(f"Has vulnerabilities: {code.has_vulnerabilities}")
    
    # اجرای exploit
    result = await agent.execute_exploit(code)
    print(f"Execution: {result.status.value}")
    print(f"Success: {result.success}")


if __name__ == "__main__":
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    asyncio.run(example_usage())
