#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Analysis Agent & Vision Agent
=================================================

ایجنت‌های تحلیل و بینایی - چشم و مغز تحلیلی سیستم

این ماژول شامل دو agent است:

1. Analysis Agent:
   - تحلیل عمیق نتایج حملات
   - استخراج Indicators of Compromise (IoC)
   - شناسایی الگوها و anomalies
   - ارزیابی موفقیت/شکست
   - تولید گزارش‌های تحلیلی

2. Vision Agent:
   - تحلیل screenshot های برنامه‌ها و وب‌سایت‌ها
   - OCR برای استخراج متن از تصاویر
   - شناسایی آسیب‌پذیری‌های UI/UX
   - تحلیل CAPTCHA و anti-bot mechanisms
   - شناسایی عناصر قابل کلیک و فرم‌ها

مدل‌های استفاده شده:
- Analysis Agent:
  - Primary: Qwen3-235B-A22B (تحلیل عمیق)
  - Secondary: NVIDIA Nemotron-70B (بهترین در IoC Extraction)
  
- Vision Agent:
  - Primary: Qwen2.5-VL-72B-AWQ (قدرتمندترین VLM)
  - Secondary: InternVL2-8B (سریع و کارآمد)

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک

LEGAL REQUIREMENTS:
- FBI Clearance
- IRB Ethics Committee Approval
- Local Police Department Authorization
- University Research Committee Approval

ONLY FOR ACADEMIC RESEARCH - تنها برای تحقیقات آکادمیک
"""

import asyncio
import json
import re
import base64
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

# Import base classes
from agents.base_agent import BaseAgent, ModelConfig, ModelPriority, TaskResult
from agents.communication_bus import AgentType, MessagePriority

# تنظیم logger
logger = logging.getLogger(__name__)


# ==============================================================================
# Enums و Data Classes برای Analysis Agent
# ==============================================================================

class AnalysisType(Enum):
    """نوع تحلیل"""
    EXECUTION_RESULT = "execution_result"
    VULNERABILITY = "vulnerability"
    NETWORK_TRAFFIC = "network_traffic"
    SYSTEM_LOGS = "system_logs"
    IOC_EXTRACTION = "ioc_extraction"


@dataclass
class IndicatorOfCompromise:
    """
    شاخص سازش (IoC)
    """
    ioc_id: str                        # شناسه IoC
    ioc_type: str                      # نوع (IP، Domain، Hash، etc.)
    value: str                         # مقدار
    confidence: float                  # اطمینان (0-1)
    severity: str                      # شدت (low، medium، high، critical)
    description: str                   # توضیحات
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'ioc_id': self.ioc_id,
            'ioc_type': self.ioc_type,
            'value': self.value,
            'confidence': self.confidence,
            'severity': self.severity,
            'description': self.description,
            'metadata': self.metadata
        }


@dataclass
class AnalysisReport:
    """
    گزارش تحلیل
    """
    report_id: str                     # شناسه گزارش
    analysis_type: AnalysisType        # نوع تحلیل
    summary: str                       # خلاصه
    findings: List[str]                # یافته‌ها
    iocs: List[IndicatorOfCompromise]  # IoC ها
    recommendations: List[str]         # توصیه‌ها
    success_assessment: bool           # آیا حمله موفق بود؟
    confidence_score: float            # امتیاز اطمینان (0-1)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'report_id': self.report_id,
            'analysis_type': self.analysis_type.value,
            'summary': self.summary,
            'findings': self.findings,
            'iocs': [ioc.to_dict() for ioc in self.iocs],
            'recommendations': self.recommendations,
            'success_assessment': self.success_assessment,
            'confidence_score': self.confidence_score,
            'metadata': self.metadata
        }


# ==============================================================================
# Enums و Data Classes برای Vision Agent
# ==============================================================================

@dataclass
class VisualElement:
    """
    عنصر بصری شناسایی شده
    """
    element_id: str                    # شناسه عنصر
    element_type: str                  # نوع (button، input، link، etc.)
    text: str                          # متن (از OCR)
    position: Dict[str, int]           # موقعیت (x، y، width، height)
    confidence: float                  # اطمینان (0-1)
    is_clickable: bool                 # آیا قابل کلیک است؟
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'element_id': self.element_id,
            'element_type': self.element_type,
            'text': self.text,
            'position': self.position,
            'confidence': self.confidence,
            'is_clickable': self.is_clickable,
            'metadata': self.metadata
        }


@dataclass
class VisionAnalysisResult:
    """
    نتیجه تحلیل بصری
    """
    analysis_id: str                   # شناسه تحلیل
    image_path: str                    # مسیر تصویر
    description: str                   # توضیحات کلی
    extracted_text: str                # متن استخراج شده (OCR)
    elements: List[VisualElement]      # عناصر شناسایی شده
    vulnerabilities: List[str]         # آسیب‌پذیری‌های UI/UX
    recommendations: List[str]         # توصیه‌ها
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'analysis_id': self.analysis_id,
            'image_path': self.image_path,
            'description': self.description,
            'extracted_text': self.extracted_text,
            'elements': [e.to_dict() for e in self.elements],
            'vulnerabilities': self.vulnerabilities,
            'recommendations': self.recommendations,
            'metadata': self.metadata
        }


# ==============================================================================
# Analysis Agent
# ==============================================================================

class AnalysisAgent(BaseAgent):
    """
    ایجنت تحلیل - مغز تحلیلی سیستم
    
    این agent با استفاده از مدل‌های تحلیلی پیشرفته (Qwen3-235B، Nemotron-70B)
    نتایج حملات را تحلیل می‌کند و گزارش‌های جامع تولید می‌کند.
    
    ویژگی‌های کلیدی:
    - تحلیل عمیق با Qwen3-235B (MMLU: 88.6)
    - استخراج IoC با Nemotron-70B (بهترین مدل برای IoC Extraction)
    - شناسایی الگوها و anomalies
    - ارزیابی موفقیت/شکست حملات
    
    جریان کار:
    1. دریافت نتایج اجرا از Execution Agent
    2. تحلیل عمیق نتایج
    3. استخراج IoC ها
    4. تولید گزارش تحلیلی
    5. ارسال به Decision Agent برای تصمیم‌گیری بعدی
    
    استفاده:
        agent = AnalysisAgent()
        
        # تحلیل نتیجه اجرا
        report = await agent.analyze_execution_result({
            'execution_id': 'EXEC-001',
            'success': True,
            'output': '...'
        })
    """
    
    def __init__(self, vllm_endpoint: str = "http://localhost:8000/v1"):
        """
        مقداردهی اولیه Analysis Agent
        
        Args:
            vllm_endpoint: endpoint سرور vLLM
        """
        super().__init__(
            agent_type=AgentType.ANALYSIS,
            agent_name="Analysis Agent (Qwen3-235B)"
        )
        
        # اضافه کردن مدل‌ها
        self._setup_models(vllm_endpoint)
        
        logger.info("Analysis Agent initialized with Qwen3-235B + Nemotron-70B")
    
    def _setup_models(self, vllm_endpoint: str):
        """تنظیم مدل‌های LLM"""
        # Primary: Qwen3-235B-A22B
        self.add_model(ModelConfig(
            model_name="qwen3-235b-a22b",
            model_path=f"{vllm_endpoint}/qwen3-235b",
            priority=ModelPriority.PRIMARY,
            max_tokens=8192,
            temperature=0.5,
            metadata={
                'description': 'Deep analysis and research',
                'mmlu': 88.6
            }
        ))
        
        # Secondary: NVIDIA Nemotron-70B (بهترین برای IoC Extraction)
        self.add_model(ModelConfig(
            model_name="nemotron-70b",
            model_path=f"{vllm_endpoint}/nemotron-70b",
            priority=ModelPriority.SECONDARY,
            max_tokens=8192,
            temperature=0.5,
            metadata={
                'description': 'Best for IoC extraction from threat reports',
                'ioc_extraction': 9.5
            }
        ))
    
    async def _call_llm_impl(self, model: ModelConfig, prompt: str, **kwargs) -> str:
        """پیاده‌سازی فراخوانی LLM"""
        try:
            from openai import AsyncOpenAI
            
            client = AsyncOpenAI(base_url=model.model_path, api_key="dummy")
            
            response = await client.chat.completions.create(
                model=model.model_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a cybersecurity analyst specializing in threat analysis and IoC extraction. You provide detailed, accurate analysis for academic research."
                    },
                    {"role": "user", "content": prompt}
                ],
                temperature=kwargs.get('temperature', model.temperature),
                max_tokens=kwargs.get('max_tokens', model.max_tokens)
            )
            
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error calling {model.model_name}: {e}")
            raise
    
    async def _execute_task(self, task_data: Dict[str, Any]) -> Any:
        """پیاده‌سازی اجرای task"""
        task_type = task_data.get('task_type')
        
        if task_type == 'analyze_execution':
            return await self.analyze_execution_result(task_data.get('execution_result', {}))
        elif task_type == 'extract_ioc':
            return await self.extract_iocs(task_data.get('data', ''))
        else:
            raise ValueError(f"Unknown task type: {task_type}")
    
    async def analyze_execution_result(
        self,
        execution_result: Dict[str, Any]
    ) -> AnalysisReport:
        """
        تحلیل نتیجه اجرای یک exploit
        
        Args:
            execution_result: نتیجه اجرا از Execution Agent
        
        Returns:
            AnalysisReport
        """
        logger.info(f"Analyzing execution result: {execution_result.get('execution_id')}")
        
        # ساخت prompt
        prompt = f"""
Analyze this penetration testing execution result:

EXECUTION RESULT:
{json.dumps(execution_result, indent=2)}

Provide detailed analysis including:
1. Success assessment
2. Key findings
3. Indicators of Compromise (IoCs)
4. Recommendations for next steps

OUTPUT FORMAT (JSON):
{{
    "summary": "خلاصه تحلیل به فارسی",
    "findings": ["یافته 1", "یافته 2"],
    "iocs": [
        {{
            "ioc_type": "ip",
            "value": "192.168.1.100",
            "confidence": 0.9,
            "severity": "high",
            "description": "توضیحات"
        }}
    ],
    "recommendations": ["توصیه 1", "توصیه 2"],
    "success_assessment": true,
    "confidence_score": 0.85
}}
"""
        
        # فراخوانی LLM
        response = await self.call_llm(prompt)
        
        # پارس پاسخ
        report = self._parse_analysis_response(response, AnalysisType.EXECUTION_RESULT)
        
        # ذخیره در context
        self.update_context('latest_analysis_report', report.to_dict())
        
        logger.info(f"Analysis complete: {report.report_id}, success: {report.success_assessment}")
        
        return report
    
    async def extract_iocs(self, data: str) -> List[IndicatorOfCompromise]:
        """
        استخراج IoC ها از داده
        
        این متد از Nemotron-70B استفاده می‌کند (بهترین مدل برای IoC Extraction)
        
        Args:
            data: داده ورودی (لاگ، گزارش، etc.)
        
        Returns:
            لیست IoC ها
        """
        logger.info("Extracting IoCs")
        
        prompt = f"""
Extract Indicators of Compromise (IoCs) from this data:

DATA:
{data}

Find:
- IP addresses
- Domain names
- File hashes (MD5، SHA1، SHA256)
- URLs
- Email addresses

OUTPUT FORMAT (JSON):
{{
    "iocs": [
        {{
            "ioc_type": "ip",
            "value": "192.168.1.100",
            "confidence": 0.9,
            "severity": "high",
            "description": "Malicious IP"
        }}
    ]
}}
"""
        
        # استفاده از Nemotron (Secondary) برای IoC Extraction
        response = await self.call_llm(prompt, model_priority=ModelPriority.SECONDARY)
        
        # پارس
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
                iocs = []
                for ioc_data in data.get('iocs', []):
                    ioc = IndicatorOfCompromise(
                        ioc_id=f"IOC-{len(iocs)+1}",
                        ioc_type=ioc_data.get('ioc_type', 'unknown'),
                        value=ioc_data.get('value', ''),
                        confidence=ioc_data.get('confidence', 0.5),
                        severity=ioc_data.get('severity', 'medium'),
                        description=ioc_data.get('description', '')
                    )
                    iocs.append(ioc)
                return iocs
        except:
            pass
        
        return []
    
    def _parse_analysis_response(
        self,
        response: str,
        analysis_type: AnalysisType
    ) -> AnalysisReport:
        """پارس پاسخ تحلیل"""
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
            else:
                data = {}
            
            # تبدیل IoCs
            iocs = []
            for ioc_data in data.get('iocs', []):
                ioc = IndicatorOfCompromise(
                    ioc_id=f"IOC-{len(iocs)+1}",
                    ioc_type=ioc_data.get('ioc_type', 'unknown'),
                    value=ioc_data.get('value', ''),
                    confidence=ioc_data.get('confidence', 0.5),
                    severity=ioc_data.get('severity', 'medium'),
                    description=ioc_data.get('description', '')
                )
                iocs.append(ioc)
            
            return AnalysisReport(
                report_id=f"REPORT-{int(time.time())}",
                analysis_type=analysis_type,
                summary=data.get('summary', ''),
                findings=data.get('findings', []),
                iocs=iocs,
                recommendations=data.get('recommendations', []),
                success_assessment=data.get('success_assessment', False),
                confidence_score=data.get('confidence_score', 0.5)
            )
        except Exception as e:
            logger.error(f"Error parsing analysis response: {e}")
            return AnalysisReport(
                report_id=f"REPORT-{int(time.time())}",
                analysis_type=analysis_type,
                summary='Parsing failed',
                findings=[],
                iocs=[],
                recommendations=[],
                success_assessment=False,
                confidence_score=0.0
            )


# ==============================================================================
# Vision Agent
# ==============================================================================

class VisionAgent(BaseAgent):
    """
    ایجنت بینایی - چشم سیستم
    
    این agent با استفاده از Vision-Language Models (VLM) تصاویر را تحلیل می‌کند.
    
    ویژگی‌های کلیدی:
    - تحلیل screenshot با Qwen2.5-VL-72B (قدرتمندترین VLM)
    - OCR برای استخراج متن
    - شناسایی عناصر UI/UX
    - تشخیص آسیب‌پذیری‌های بصری
    
    استفاده:
        agent = VisionAgent()
        
        # تحلیل تصویر
        result = await agent.analyze_image('/path/to/screenshot.png')
    """
    
    def __init__(self, vllm_endpoint: str = "http://localhost:8000/v1"):
        """مقداردهی اولیه Vision Agent"""
        super().__init__(
            agent_type=AgentType.VISION,
            agent_name="Vision Agent (Qwen2.5-VL-72B)"
        )
        
        self._setup_models(vllm_endpoint)
        logger.info("Vision Agent initialized with Qwen2.5-VL-72B")
    
    def _setup_models(self, vllm_endpoint: str):
        """تنظیم مدل‌های VLM"""
        # Primary: Qwen2.5-VL-72B-AWQ
        self.add_model(ModelConfig(
            model_name="qwen2.5-vl-72b-awq",
            model_path=f"{vllm_endpoint}/qwen2.5-vl",
            priority=ModelPriority.PRIMARY,
            max_tokens=4096,
            temperature=0.5,
            metadata={'description': 'Most powerful VLM'}
        ))
    
    async def _call_llm_impl(self, model: ModelConfig, prompt: str, **kwargs) -> str:
        """پیاده‌سازی فراخوانی VLM"""
        # در production باید از API واقعی VLM استفاده شود
        # برای مثال، از vLLM با پشتیبانی Vision
        return "Vision analysis result (placeholder)"
    
    async def _execute_task(self, task_data: Dict[str, Any]) -> Any:
        """پیاده‌سازی اجرای task"""
        task_type = task_data.get('task_type')
        
        if task_type == 'analyze_image':
            return await self.analyze_image(task_data.get('image_path', ''))
        else:
            raise ValueError(f"Unknown task type: {task_type}")
    
    async def analyze_image(self, image_path: str) -> VisionAnalysisResult:
        """
        تحلیل یک تصویر
        
        Args:
            image_path: مسیر تصویر
        
        Returns:
            VisionAnalysisResult
        """
        logger.info(f"Analyzing image: {image_path}")
        
        # در production باید تصویر را به base64 تبدیل و به VLM ارسال کرد
        # اینجا یک placeholder است
        
        result = VisionAnalysisResult(
            analysis_id=f"VISION-{int(time.time())}",
            image_path=image_path,
            description="تحلیل تصویر (placeholder)",
            extracted_text="متن استخراج شده از OCR",
            elements=[],
            vulnerabilities=[],
            recommendations=[]
        )
        
        return result


# ==============================================================================
# مثال استفاده
# ==============================================================================

async def example_usage():
    """مثال استفاده"""
    # Analysis Agent
    analysis_agent = AnalysisAgent()
    
    execution_result = {
        'execution_id': 'EXEC-001',
        'success': True,
        'output': 'SQL injection successful, extracted 100 records'
    }
    
    report = await analysis_agent.analyze_execution_result(execution_result)
    print(f"Analysis: {report.summary}")
    print(f"Success: {report.success_assessment}")
    
    # Vision Agent
    vision_agent = VisionAgent()
    
    vision_result = await vision_agent.analyze_image('/path/to/screenshot.png')
    print(f"Vision: {vision_result.description}")


if __name__ == "__main__":
    import time
    import logging
    logging.basicConfig(level=logging.INFO)
    
    asyncio.run(example_usage())
