#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Agent Communication Bus
===========================================

باس ارتباطی بین agents برای همکاری و هماهنگی

این ماژول مسئول:
- انتقال پیام بین agents
- نگهداری context مشترک
- مدیریت حافظه کوتاه‌مدت و بلندمدت
- سیستم event notification

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک
"""

import asyncio
import json
import time
from datetime import datetime
from typing import Dict, Any, List, Optional, Callable
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum
import logging

# تنظیم logger
logger = logging.getLogger(__name__)


# ==============================================================================
# Enums و Data Classes
# ==============================================================================

class AgentType(Enum):
    """انواع Agent ها"""
    DECISION = "decision"          # ایجنت تصمیم‌گیری (DeepSeek-R1)
    EXECUTION = "execution"        # ایجنت اجرا (GLM-4.7)
    ANALYSIS = "analysis"          # ایجنت تحلیل (Qwen3-235B)
    VISION = "vision"              # ایجنت بینایی (Qwen2.5-VL)


class MessagePriority(Enum):
    """اولویت پیام"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class AgentMessage:
    """
    پیام بین agents
    
    هر پیام شامل:
    - فرستنده و گیرنده
    - محتوای پیام
    - اولویت
    - timestamp
    - metadata اضافی
    """
    from_agent: AgentType
    to_agent: AgentType
    message_type: str
    content: Dict[str, Any]
    priority: MessagePriority = MessagePriority.NORMAL
    message_id: str = field(default_factory=lambda: f"msg_{int(time.time()*1000)}")
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'message_id': self.message_id,
            'from_agent': self.from_agent.value,
            'to_agent': self.to_agent.value,
            'message_type': self.message_type,
            'content': self.content,
            'priority': self.priority.value,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata
        }


@dataclass
class SharedContext:
    """
    Context مشترک بین تمام agents
    
    این context شامل اطلاعاتی است که همه agents باید به آن دسترسی داشته باشند
    """
    target_info: Dict[str, Any] = field(default_factory=dict)
    current_goal: Optional[str] = None
    attack_chain: List[Dict] = field(default_factory=list)
    current_step: int = 0
    vulnerabilities: List[Dict] = field(default_factory=list)
    execution_results: List[Dict] = field(default_factory=list)
    analysis_reports: List[Dict] = field(default_factory=list)
    visual_data: List[Dict] = field(default_factory=list)
    session_id: str = field(default_factory=lambda: f"session_{int(time.time())}")
    start_time: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        """تبدیل به دیکشنری"""
        return {
            'target_info': self.target_info,
            'current_goal': self.current_goal,
            'attack_chain': self.attack_chain,
            'current_step': self.current_step,
            'vulnerabilities': self.vulnerabilities,
            'execution_results': self.execution_results,
            'analysis_reports': self.analysis_reports,
            'visual_data': self.visual_data,
            'session_id': self.session_id,
            'start_time': self.start_time.isoformat()
        }


# ==============================================================================
# Agent Communication Bus
# ==============================================================================

class AgentCommunicationBus:
    """
    باس ارتباطی بین agents
    
    این کلاس مسئول:
    1. مدیریت ارتباط بین agents
    2. نگهداری context مشترک
    3. مدیریت حافظه (کوتاه‌مدت و بلندمدت)
    4. سیستم event notification
    5. صف پیام‌ها با اولویت‌بندی
    
    استفاده:
        bus = AgentCommunicationBus()
        
        # ارسال پیام
        await bus.send_message(
            from_agent=AgentType.DECISION,
            to_agent=AgentType.EXECUTION,
            message_type="execute_attack",
            content={"attack_type": "sql_injection", "target": "192.168.1.100"}
        )
        
        # دریافت پیام
        message = await bus.receive_message(AgentType.EXECUTION)
        
        # به‌روزرسانی context
        bus.update_context("target_info", {"ip": "192.168.1.100"})
        
        # دریافت context
        target_info = bus.get_context("target_info")
    """
    
    def __init__(self, max_short_term_memory: int = 100):
        """
        مقداردهی اولیه باس ارتباطی
        
        Args:
            max_short_term_memory: حداکثر تعداد پیام‌ها در حافظه کوتاه‌مدت
        """
        # صف پیام‌ها برای هر agent
        self.message_queues: Dict[AgentType, asyncio.PriorityQueue] = {
            agent_type: asyncio.PriorityQueue()
            for agent_type in AgentType
        }
        
        # Context مشترک
        self.shared_context = SharedContext()
        
        # حافظه کوتاه‌مدت (deque برای محدود کردن حجم)
        self.short_term_memory: deque = deque(maxlen=max_short_term_memory)
        
        # حافظه بلندمدت (دیکشنری برای دسترسی سریع)
        self.long_term_memory: Dict[str, Any] = {}
        
        # Event subscribers
        self.event_subscribers: Dict[str, List[Callable]] = defaultdict(list)
        
        # آمار
        self.stats = {
            'messages_sent': 0,
            'messages_received': 0,
            'events_published': 0,
            'start_time': datetime.now()
        }
        
        logger.info("Agent Communication Bus initialized")
    
    async def send_message(
        self,
        from_agent: AgentType,
        to_agent: AgentType,
        message_type: str,
        content: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict] = None
    ) -> str:
        """
        ارسال پیام از یک agent به agent دیگر
        
        Args:
            from_agent: agent فرستنده
            to_agent: agent گیرنده
            message_type: نوع پیام (مثلاً "execute_attack", "analysis_complete")
            content: محتوای پیام
            priority: اولویت پیام
            metadata: metadata اضافی
        
        Returns:
            message_id: شناسه پیام
        """
        # ایجاد پیام
        message = AgentMessage(
            from_agent=from_agent,
            to_agent=to_agent,
            message_type=message_type,
            content=content,
            priority=priority,
            metadata=metadata or {}
        )
        
        # اضافه کردن به صف (با اولویت معکوس چون PriorityQueue کوچکترین را اول برمی‌گرداند)
        priority_value = -priority.value  # معکوس برای اولویت بالاتر
        await self.message_queues[to_agent].put((priority_value, message))
        
        # ذخیره در حافظه کوتاه‌مدت
        self.short_term_memory.append(message)
        
        # به‌روزرسانی آمار
        self.stats['messages_sent'] += 1
        
        logger.debug(
            f"Message sent: {from_agent.value} -> {to_agent.value} "
            f"(type: {message_type}, priority: {priority.value})"
        )
        
        # انتشار event
        await self.publish_event("message_sent", message.to_dict())
        
        return message.message_id
    
    async def receive_message(
        self,
        agent: AgentType,
        timeout: Optional[float] = None
    ) -> Optional[AgentMessage]:
        """
        دریافت پیام برای یک agent
        
        Args:
            agent: agent گیرنده
            timeout: timeout برای دریافت پیام (ثانیه)
        
        Returns:
            پیام دریافت شده یا None در صورت timeout
        """
        try:
            # دریافت از صف با timeout
            if timeout:
                priority_value, message = await asyncio.wait_for(
                    self.message_queues[agent].get(),
                    timeout=timeout
                )
            else:
                priority_value, message = await self.message_queues[agent].get()
            
            # به‌روزرسانی آمار
            self.stats['messages_received'] += 1
            
            logger.debug(
                f"Message received: {agent.value} <- {message.from_agent.value} "
                f"(type: {message.message_type})"
            )
            
            # انتشار event
            await self.publish_event("message_received", message.to_dict())
            
            return message
            
        except asyncio.TimeoutError:
            logger.debug(f"No message for {agent.value} (timeout: {timeout}s)")
            return None
    
    async def broadcast_message(
        self,
        from_agent: AgentType,
        message_type: str,
        content: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL
    ) -> List[str]:
        """
        ارسال پیام به تمام agents (به جز فرستنده)
        
        Args:
            from_agent: agent فرستنده
            message_type: نوع پیام
            content: محتوای پیام
            priority: اولویت پیام
        
        Returns:
            لیست message_id های ارسال شده
        """
        message_ids = []
        
        for agent_type in AgentType:
            if agent_type != from_agent:
                message_id = await self.send_message(
                    from_agent=from_agent,
                    to_agent=agent_type,
                    message_type=message_type,
                    content=content,
                    priority=priority
                )
                message_ids.append(message_id)
        
        logger.info(f"Broadcast message from {from_agent.value} to all agents")
        
        return message_ids
    
    def update_context(self, key: str, value: Any):
        """
        به‌روزرسانی context مشترک
        
        Args:
            key: کلید (مثلاً "target_info", "current_goal")
            value: مقدار
        """
        if hasattr(self.shared_context, key):
            setattr(self.shared_context, key, value)
        else:
            # اگر کلید در SharedContext نبود، در long_term_memory ذخیره کن
            self.long_term_memory[key] = value
        
        logger.debug(f"Context updated: {key}")
    
    def get_context(self, key: str) -> Any:
        """
        دریافت context
        
        Args:
            key: کلید
        
        Returns:
            مقدار context یا None
        """
        if hasattr(self.shared_context, key):
            return getattr(self.shared_context, key)
        else:
            return self.long_term_memory.get(key)
    
    def get_full_context(self) -> Dict:
        """
        دریافت تمام context
        
        Returns:
            دیکشنری کامل context
        """
        context = self.shared_context.to_dict()
        context.update(self.long_term_memory)
        return context
    
    def subscribe_event(self, event_name: str, callback: Callable):
        """
        اشتراک در یک event
        
        Args:
            event_name: نام event (مثلاً "message_sent", "attack_complete")
            callback: تابع callback که هنگام رخ دادن event فراخوانی می‌شود
        """
        self.event_subscribers[event_name].append(callback)
        logger.debug(f"Subscribed to event: {event_name}")
    
    async def publish_event(self, event_name: str, data: Dict):
        """
        انتشار یک event
        
        Args:
            event_name: نام event
            data: داده‌های event
        """
        # فراخوانی تمام callback ها
        for callback in self.event_subscribers[event_name]:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(data)
                else:
                    callback(data)
            except Exception as e:
                logger.error(f"Error in event callback for {event_name}: {e}")
        
        # به‌روزرسانی آمار
        self.stats['events_published'] += 1
    
    def get_short_term_memory(self, limit: Optional[int] = None) -> List[AgentMessage]:
        """
        دریافت حافظه کوتاه‌مدت
        
        Args:
            limit: تعداد پیام‌های اخیر (None = همه)
        
        Returns:
            لیست پیام‌ها
        """
        if limit:
            return list(self.short_term_memory)[-limit:]
        else:
            return list(self.short_term_memory)
    
    def clear_short_term_memory(self):
        """پاک کردن حافظه کوتاه‌مدت"""
        self.short_term_memory.clear()
        logger.info("Short-term memory cleared")
    
    def get_stats(self) -> Dict:
        """
        دریافت آمار باس ارتباطی
        
        Returns:
            دیکشنری آمار
        """
        uptime = (datetime.now() - self.stats['start_time']).total_seconds()
        
        return {
            'messages_sent': self.stats['messages_sent'],
            'messages_received': self.stats['messages_received'],
            'events_published': self.stats['events_published'],
            'uptime_seconds': uptime,
            'short_term_memory_size': len(self.short_term_memory),
            'long_term_memory_size': len(self.long_term_memory),
            'event_subscribers_count': sum(len(v) for v in self.event_subscribers.values())
        }
    
    def reset(self):
        """ریست کامل باس (برای تست یا شروع session جدید)"""
        # پاک کردن صف‌ها
        for queue in self.message_queues.values():
            while not queue.empty():
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
        
        # ریست context و حافظه
        self.shared_context = SharedContext()
        self.short_term_memory.clear()
        self.long_term_memory.clear()
        self.event_subscribers.clear()
        
        # ریست آمار
        self.stats = {
            'messages_sent': 0,
            'messages_received': 0,
            'events_published': 0,
            'start_time': datetime.now()
        }
        
        logger.info("Agent Communication Bus reset")


# ==============================================================================
# Singleton Instance
# ==============================================================================

_bus_instance: Optional[AgentCommunicationBus] = None


def get_communication_bus() -> AgentCommunicationBus:
    """
    دریافت instance singleton از باس ارتباطی
    
    Returns:
        AgentCommunicationBus instance
    """
    global _bus_instance
    
    if _bus_instance is None:
        _bus_instance = AgentCommunicationBus()
    
    return _bus_instance


# ==============================================================================
# مثال استفاده
# ==============================================================================

async def example_usage():
    """
    مثال استفاده از Agent Communication Bus
    """
    # دریافت instance
    bus = get_communication_bus()
    
    # تعریف callback برای event
    async def on_message_sent(data):
        print(f"Event: Message sent - {data['message_type']}")
    
    bus.subscribe_event("message_sent", on_message_sent)
    
    # ارسال پیام از Decision Agent به Execution Agent
    message_id = await bus.send_message(
        from_agent=AgentType.DECISION,
        to_agent=AgentType.EXECUTION,
        message_type="execute_attack",
        content={
            "attack_type": "sql_injection",
            "target": "192.168.1.100",
            "payload": "' OR '1'='1"
        },
        priority=MessagePriority.HIGH
    )
    
    print(f"Message sent with ID: {message_id}")
    
    # به‌روزرسانی context
    bus.update_context("target_info", {
        "ip": "192.168.1.100",
        "ports": [80, 443, 22],
        "os": "Ubuntu 22.04"
    })
    
    # دریافت پیام توسط Execution Agent
    message = await bus.receive_message(AgentType.EXECUTION, timeout=5.0)
    
    if message:
        print(f"Message received: {message.message_type}")
        print(f"Content: {message.content}")
    
    # دریافت context
    target_info = bus.get_context("target_info")
    print(f"Target Info: {target_info}")
    
    # دریافت آمار
    stats = bus.get_stats()
    print(f"Stats: {stats}")


if __name__ == "__main__":
    # تنظیم logging
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # اجرای مثال
    asyncio.run(example_usage())
