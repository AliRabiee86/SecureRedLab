#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SecureRedLab v2.0 - Legacy Integration Layer
============================================

لایه یکپارچه‌سازی با کدهای قدیمی

این ماژول پلی بین معماری جدید (Multi-Agent System) و کدهای قدیمی است.

وظایف:
- اتصال Multi-Agent System به RL Engine قدیمی
- استفاده از AI modules موجود (vLLM، VLM، Anti-Hallucination)
- یکپارچه‌سازی با API endpoints موجود
- حفظ backward compatibility
- Migration تدریجی از معماری قدیم به جدید

معماری قدیم:
- backend/app/ai/offline_core.py - هسته AI قدیمی
- backend/app/core/rl_engine.py - RL Engine
- backend/app/ai/vllm_client.py - vLLM Client
- backend/app/ai/vlm_client.py - VLM Client
- backend/app/ai/anti_hallucination.py - Anti-Hallucination

معماری جدید:
- agents/ - Multi-Agent System
- planning/ - Planning Layer

نویسنده: SecureRedLab Team
تاریخ: 2026-02-04
نسخه: 2.0.0
مجوز: تحقیقاتی آکادمیک
"""

import asyncio
import sys
import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import logging

# اضافه کردن مسیر کدهای قدیمی به sys.path
LEGACY_CODE_PATH = "/home/ubuntu/webapp/SecureRedLab/backend"
if LEGACY_CODE_PATH not in sys.path:
    sys.path.insert(0, LEGACY_CODE_PATH)

# Import کدهای قدیمی (با error handling)
try:
    from app.ai.vllm_client import VLLMClient
    from app.ai.vlm_client import VLMClient
    from app.ai.anti_hallucination import AntiHallucinationGuard
    LEGACY_IMPORTS_AVAILABLE = True
except ImportError as e:
    logger = logging.getLogger(__name__)
    logger.warning(f"Legacy imports not available: {e}")
    LEGACY_IMPORTS_AVAILABLE = False
    # ایجاد placeholder classes
    class VLLMClient:
        pass
    class VLMClient:
        pass
    class AntiHallucinationGuard:
        pass

# Import معماری جدید
sys.path.insert(0, "/home/ubuntu/SecureRedLab_v2")
from agents.decision_agent import DecisionAgent
from agents.execution_agent import ExecutionAgent
from agents.analysis_vision_agents import AnalysisAgent, VisionAgent
from planning.planning_layer import GoalDecomposer, StrategyGenerator, AttackChainPlanner

logger = logging.getLogger(__name__)


# ==============================================================================
# Legacy Wrapper Classes
# ==============================================================================

class LegacyVLLMWrapper:
    """
    Wrapper برای vLLM Client قدیمی
    
    این کلاس vLLM Client قدیمی را wrap می‌کند و interface سازگار با
    معماری جدید ارائه می‌دهد.
    """
    
    def __init__(self, endpoint: str = "http://localhost:8000/v1"):
        """
        مقداردهی اولیه
        
        Args:
            endpoint: endpoint سرور vLLM
        """
        self.endpoint = endpoint
        
        if LEGACY_IMPORTS_AVAILABLE:
            try:
                self.client = VLLMClient(base_url=endpoint)
                logger.info("Legacy vLLM Client initialized")
            except Exception as e:
                logger.error(f"Failed to initialize legacy vLLM Client: {e}")
                self.client = None
        else:
            self.client = None
            logger.warning("Legacy vLLM Client not available")
    
    async def call(
        self,
        model: str,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 4096
    ) -> str:
        """
        فراخوانی مدل LLM
        
        Args:
            model: نام مدل
            prompt: prompt ورودی
            temperature: temperature
            max_tokens: حداکثر توکن‌های خروجی
        
        Returns:
            پاسخ مدل
        """
        if self.client:
            try:
                # استفاده از client قدیمی
                response = await self.client.generate(
                    model=model,
                    prompt=prompt,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                return response
            except Exception as e:
                logger.error(f"Legacy vLLM call failed: {e}")
                raise
        else:
            # Fallback به OpenAI client
            from openai import AsyncOpenAI
            client = AsyncOpenAI(base_url=self.endpoint, api_key="dummy")
            
            response = await client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            return response.choices[0].message.content


class LegacyAntiHallucinationWrapper:
    """
    Wrapper برای Anti-Hallucination Guard قدیمی
    
    این کلاس از Anti-Hallucination Guard موجود استفاده می‌کند.
    """
    
    def __init__(self):
        """مقداردهی اولیه"""
        if LEGACY_IMPORTS_AVAILABLE:
            try:
                self.guard = AntiHallucinationGuard()
                logger.info("Legacy Anti-Hallucination Guard initialized")
            except Exception as e:
                logger.error(f"Failed to initialize Anti-Hallucination Guard: {e}")
                self.guard = None
        else:
            self.guard = None
            logger.warning("Legacy Anti-Hallucination Guard not available")
    
    def validate(self, text: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """
        اعتبارسنجی متن برای شناسایی hallucination
        
        Args:
            text: متن ورودی
            context: context اضافی
        
        Returns:
            نتیجه اعتبارسنجی
        """
        if self.guard:
            try:
                result = self.guard.validate(text, context)
                return result
            except Exception as e:
                logger.error(f"Anti-Hallucination validation failed: {e}")
                return {'is_valid': True, 'confidence': 0.5}
        else:
            # Fallback ساده
            return {'is_valid': True, 'confidence': 0.8}


# ==============================================================================
# Integrated Agent System
# ==============================================================================

class IntegratedAgentSystem:
    """
    سیستم یکپارچه Agents
    
    این کلاس معماری جدید (Multi-Agent) را با کدهای قدیمی یکپارچه می‌کند.
    
    معماری:
    - از agents جدید برای تصمیم‌گیری و اجرا استفاده می‌کند
    - از vLLM/VLM Client های قدیمی برای فراخوانی مدل‌ها استفاده می‌کند
    - از Anti-Hallucination Guard قدیمی برای اعتبارسنجی استفاده می‌کند
    - با RL Engine قدیمی ارتباط برقرار می‌کند
    
    استفاده:
        system = IntegratedAgentSystem()
        
        # اجرای یک حمله
        result = await system.execute_attack(
            target_info={'ip': '192.168.1.100'},
            goal='data_exfiltration'
        )
    """
    
    def __init__(self, vllm_endpoint: str = "http://localhost:8000/v1"):
        """
        مقداردهی اولیه
        
        Args:
            vllm_endpoint: endpoint سرور vLLM
        """
        logger.info("Initializing Integrated Agent System...")
        
        # Legacy wrappers
        self.vllm_wrapper = LegacyVLLMWrapper(vllm_endpoint)
        self.anti_hallucination = LegacyAntiHallucinationWrapper()
        
        # New agents
        self.decision_agent = DecisionAgent(vllm_endpoint)
        self.execution_agent = ExecutionAgent(vllm_endpoint)
        self.analysis_agent = AnalysisAgent(vllm_endpoint)
        self.vision_agent = VisionAgent(vllm_endpoint)
        
        # Planning layer
        self.goal_decomposer = GoalDecomposer()
        self.strategy_generator = StrategyGenerator()
        self.attack_chain_planner = AttackChainPlanner()
        
        logger.info("Integrated Agent System initialized successfully")
    
    async def execute_attack(
        self,
        target_info: Dict[str, Any],
        goal: str,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        اجرای یک حمله کامل
        
        این متد تمام مراحل حمله را اجرا می‌کند:
        1. تجزیه هدف (Goal Decomposer)
        2. تولید استراتژی (Strategy Generator)
        3. تحلیل هدف (Decision Agent)
        4. طراحی برنامه حمله (Decision Agent + Attack Chain Planner)
        5. اجرای مراحل (Execution Agent)
        6. تحلیل نتایج (Analysis Agent)
        
        Args:
            target_info: اطلاعات هدف
            goal: هدف نهایی
            constraints: محدودیت‌ها
        
        Returns:
            نتیجه کامل حمله
        """
        logger.info(f"Starting attack execution: goal={goal}, target={target_info.get('ip')}")
        
        try:
            # 1. تجزیه هدف
            logger.info("Step 1: Decomposing goal...")
            root_goal = self.goal_decomposer.decompose_goal(goal, target_info)
            
            # 2. تولید استراتژی
            logger.info("Step 2: Generating strategy...")
            strategy = self.strategy_generator.generate_strategy(
                goal=goal,
                target_info=target_info,
                constraints=constraints
            )
            
            # 3. تحلیل هدف
            logger.info("Step 3: Analyzing target...")
            target_analysis = await self.decision_agent.analyze_target(target_info)
            
            # 4. طراحی برنامه حمله
            logger.info("Step 4: Planning attack...")
            attack_plan = await self.decision_agent.plan_attack(
                target_info=target_info,
                goal=goal,
                constraints=constraints
            )
            
            # 5. اجرای مراحل
            logger.info("Step 5: Executing attack steps...")
            execution_results = []
            
            for step in attack_plan.attack_chain:
                logger.info(f"Executing step: {step.step_id} - {step.description}")
                
                # تولید کد exploit
                exploit_code = await self.execution_agent.generate_exploit_code(
                    attack_step=step.to_dict()
                )
                
                # اعتبارسنجی با Anti-Hallucination
                validation = self.anti_hallucination.validate(
                    exploit_code.code,
                    context={'attack_type': step.attack_type.value}
                )
                
                if not validation.get('is_valid', True):
                    logger.warning(f"Code validation failed for {step.step_id}")
                    continue
                
                # اجرای exploit
                exec_result = await self.execution_agent.execute_exploit(exploit_code)
                execution_results.append(exec_result)
                
                # اگر ناموفق بود، متوقف شو
                if not exec_result.success:
                    logger.warning(f"Step {step.step_id} failed, stopping execution")
                    break
            
            # 6. تحلیل نتایج
            logger.info("Step 6: Analyzing results...")
            analysis_reports = []
            
            for exec_result in execution_results:
                report = await self.analysis_agent.analyze_execution_result(
                    exec_result.to_dict()
                )
                analysis_reports.append(report)
            
            # جمع‌بندی
            overall_success = all(r.success for r in execution_results)
            
            result = {
                'success': overall_success,
                'goal': goal,
                'target_info': target_info,
                'attack_plan': attack_plan.to_dict(),
                'execution_results': [r.to_dict() for r in execution_results],
                'analysis_reports': [r.to_dict() for r in analysis_reports],
                'summary': f"حمله {'موفق' if overall_success else 'ناموفق'} بود. "
                          f"{len(execution_results)} مرحله اجرا شد."
            }
            
            logger.info(f"Attack execution completed: success={overall_success}")
            
            return result
            
        except Exception as e:
            logger.error(f"Attack execution failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            
            return {
                'success': False,
                'error': str(e),
                'goal': goal,
                'target_info': target_info
            }
    
    async def execute_single_step(
        self,
        attack_step: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        اجرای یک مرحله تکی
        
        این متد برای تست و debugging مفید است.
        
        Args:
            attack_step: مرحله حمله
        
        Returns:
            نتیجه اجرا
        """
        logger.info(f"Executing single step: {attack_step.get('step_id')}")
        
        # تولید کد
        exploit_code = await self.execution_agent.generate_exploit_code(attack_step)
        
        # اجرا
        exec_result = await self.execution_agent.execute_exploit(exploit_code)
        
        # تحلیل
        analysis = await self.analysis_agent.analyze_execution_result(
            exec_result.to_dict()
        )
        
        return {
            'exploit_code': exploit_code.to_dict(),
            'execution_result': exec_result.to_dict(),
            'analysis': analysis.to_dict()
        }


# ==============================================================================
# FastAPI Integration
# ==============================================================================

class FastAPIIntegration:
    """
    یکپارچه‌سازی با FastAPI
    
    این کلاس endpoint های API برای استفاده از سیستم جدید ارائه می‌دهد.
    """
    
    def __init__(self, agent_system: IntegratedAgentSystem):
        """
        مقداردهی اولیه
        
        Args:
            agent_system: سیستم یکپارچه agents
        """
        self.agent_system = agent_system
        logger.info("FastAPI Integration initialized")
    
    def register_routes(self, app):
        """
        ثبت route های API
        
        Args:
            app: FastAPI app instance
        """
        from fastapi import APIRouter
        
        router = APIRouter(prefix="/api/v2", tags=["agent-system"])
        
        @router.post("/attack/execute")
        async def execute_attack(
            target_info: Dict[str, Any],
            goal: str,
            constraints: Optional[Dict[str, Any]] = None
        ):
            """اجرای حمله کامل"""
            result = await self.agent_system.execute_attack(
                target_info=target_info,
                goal=goal,
                constraints=constraints
            )
            return result
        
        @router.post("/attack/step")
        async def execute_step(attack_step: Dict[str, Any]):
            """اجرای یک مرحله تکی"""
            result = await self.agent_system.execute_single_step(attack_step)
            return result
        
        @router.get("/agents/status")
        async def get_agents_status():
            """دریافت وضعیت agents"""
            return {
                'decision_agent': self.agent_system.decision_agent.get_stats(),
                'execution_agent': self.agent_system.execution_agent.get_stats(),
                'analysis_agent': self.agent_system.analysis_agent.get_stats(),
                'vision_agent': self.agent_system.vision_agent.get_stats()
            }
        
        app.include_router(router)
        logger.info("API routes registered")


# ==============================================================================
# مثال استفاده
# ==============================================================================

async def example_usage():
    """مثال استفاده از سیستم یکپارچه"""
    # ایجاد سیستم
    system = IntegratedAgentSystem(vllm_endpoint="http://localhost:8000/v1")
    
    # اجرای حمله
    result = await system.execute_attack(
        target_info={
            'ip': '192.168.1.100',
            'ports': [80, 443, 3306],
            'os': 'Ubuntu 22.04'
        },
        goal='data_exfiltration',
        constraints={'stealth_level': 'high', 'max_time': 60}
    )
    
    print(f"Attack success: {result['success']}")
    print(f"Summary: {result['summary']}")


if __name__ == "__main__":
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    asyncio.run(example_usage())
