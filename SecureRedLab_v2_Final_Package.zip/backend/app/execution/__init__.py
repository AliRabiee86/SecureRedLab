"""
SecureRedLab Backend - Execution Module
Phase 7: Security Tools Executors with AI Orchestration

This module contains all security tool executors that run in Docker containers.
All executors inherit from BaseExecutor and provide standardized interfaces.

Architecture:
- BaseExecutor: Abstract base class for all tool executors
- Individual Executors: Nmap, Metasploit, SQLMap, Nuclei
- AI Orchestrator: AI-driven tool selection and execution planning
"""

from app.execution.base_executor import (
    BaseExecutor,
    ContainerTimeoutError,
    ContainerExecutionError
)
from app.execution.nmap_executor import NmapExecutor
from app.execution.metasploit_executor import MetasploitExecutor  # Real Metasploit (Phase 7.3)
from app.execution.sqlmap_executor import SQLMapExecutor  # Real SQLMap (Phase 7.4)
from app.execution.nuclei_executor import NucleiExecutor  # Real Nuclei (Phase 7.5)
from app.execution.ai_orchestrator import (
    AIOrchestrator,
    get_ai_orchestrator,
    ToolType
)

# Export all executors and orchestrator
__all__ = [
    # Base classes
    "BaseExecutor",
    "ContainerTimeoutError",
    "ContainerExecutionError",
    
    # Real executors (ALL COMPLETE!)
    "NmapExecutor",         # Phase 7.2 COMPLETE ✅
    "MetasploitExecutor",   # Phase 7.3 COMPLETE ✅
    "SQLMapExecutor",       # Phase 7.4 COMPLETE ✅
    "NucleiExecutor",       # Phase 7.5 COMPLETE ✅
    
    # AI Orchestration
    "AIOrchestrator",
    "get_ai_orchestrator",
    "ToolType",
]
