"""
SecureRedLab Backend - SQLMap Executor
Phase 7.4: Real SQLMap integration via Docker

Features:
- Docker-based SQLMap execution
- SQL injection detection and exploitation
- Multiple injection techniques (Boolean, Error, Union, Time-based, Stacked)
- Database enumeration (MySQL, PostgreSQL, MSSQL, Oracle, SQLite)
- WAF bypass with tamper scripts
- JSON output parsing
- Real-time progress reporting
- Input validation & security controls

Author: SecureRedLab Team
Date: 2026-01-02
"""

import asyncio
import json
import time
import os
import tempfile
from typing import Dict, Any, Optional, List, Callable
from enum import Enum
import logging
import re

from .base_executor import BaseExecutor, ContainerTimeoutError, ContainerExecutionError


# Configure logging
logger = logging.getLogger(__name__)


class InjectionTechnique(str, Enum):
    """SQL injection techniques"""
    BOOLEAN_BLIND = "B"  # Boolean-based blind
    ERROR_BASED = "E"    # Error-based
    UNION_QUERY = "U"    # Union query-based
    STACKED_QUERIES = "S"  # Stacked queries
    TIME_BLIND = "T"     # Time-based blind
    INLINE_QUERY = "Q"   # Inline queries
    ALL = "BEUSTQ"       # All techniques


class DatabaseType(str, Enum):
    """Supported database types"""
    MYSQL = "MySQL"
    POSTGRESQL = "PostgreSQL"
    MSSQL = "Microsoft SQL Server"
    ORACLE = "Oracle"
    SQLITE = "SQLite"
    ACCESS = "Microsoft Access"


class TamperScript(str, Enum):
    """WAF bypass tamper scripts"""
    SPACE2COMMENT = "space2comment"      # Replace space with /**/
    BETWEEN = "between"                  # Replace > with NOT BETWEEN
    RANDOMCASE = "randomcase"            # Random upper/lower case
    CHARENCODE = "charencode"            # URL encode all characters
    APOSTROPHEMASK = "apostrophemask"    # Replace ' with UTF-8
    BASE64ENCODE = "base64encode"        # Base64 encode payload
    EQUALTOLIKE = "equaltolike"          # Replace = with LIKE


class SQLMapExecutor(BaseExecutor):
    """
    SQLMap executor with Docker-based SQL injection testing.
    
    Capabilities:
    - Automatic SQL injection detection
    - Multiple injection techniques (Boolean, Error, Union, Time-based, Stacked)
    - Database enumeration (tables, columns, data)
    - WAF bypass with tamper scripts
    - Support for 6+ DBMS types
    - JSON output parsing
    - Real-time progress reporting
    
    Security Controls:
    - Target validation (no localhost/127.0.0.1)
    - Dangerous operation blocking (--os-shell, --file-write, etc.)
    - Resource limits (512MB RAM, 1.0 CPU)
    - Timeout enforcement (600s default)
    - Network isolation
    """
    
    # Docker configuration
    DOCKER_IMAGE = "pberba/sqlmap"
    TIMEOUT_SECONDS = 600  # 10 minutes
    
    # Security settings
    BLOCKED_TARGETS = ["localhost", "127.0.0.1", "::1", "0.0.0.0"]
    DANGEROUS_OPTIONS = [
        "--os-shell",      # OS command execution
        "--os-pwn",        # OS takeover
        "--os-cmd",        # Execute OS command
        "--os-bof",        # Buffer overflow
        "--file-read",     # Read server files
        "--file-write",    # Write server files
        "--file-dest",     # File destination
        "--sql-shell",     # Interactive SQL shell
        "--priv-esc",      # Privilege escalation
    ]
    
    def __init__(self, progress_callback: Optional[Callable[[int, str], None]] = None):
        """
        Initialize SQLMapExecutor.
        
        Args:
            progress_callback: Optional callback for progress updates (progress: int, message: str)
        """
        super().__init__(progress_callback=progress_callback)
        logger.info("SQLMapExecutor initialized successfully")
    
    async def execute(
        self,
        target: str,
        parameters: Optional[List[str]] = None,
        technique: InjectionTechnique = InjectionTechnique.ALL,
        level: int = 1,
        risk: int = 1,
        tamper: Optional[List[TamperScript]] = None,
        threads: int = 3,
        timeout: int = TIMEOUT_SECONDS,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute SQLMap SQL injection test against target.
        
        Args:
            target: Target URL (e.g., 'http://example.com/page?id=1')
            parameters: Parameters to test (e.g., ['id', 'page'])
            technique: Injection technique(s) to use
            level: Test level (1-5, higher = more tests)
            risk: Risk level (1-3, higher = more aggressive)
            tamper: Tamper scripts for WAF bypass
            threads: Number of threads (1-10)
            timeout: Execution timeout in seconds
            **kwargs: Additional arguments
        
        Returns:
            Dict with:
                - attack_id: Unique attack identifier
                - target: Target URL
                - injectable: Whether SQL injection was found
                - technique: Injection technique used
                - dbms: Database type (if detected)
                - vulnerabilities: List of found vulnerabilities
                - databases: Enumerated databases (if requested)
                - status: Execution status
                - error: Error message (if failed)
        
        Raises:
            ContainerExecutionError: If execution fails
            ContainerTimeoutError: If execution times out
        """
        attack_id = kwargs.get('attack_id', f"sqlmap_{int(time.time())}")
        
        try:
            # Phase 1: Validate inputs (10%)
            await self._update_progress(10, f"Validating target {target}")
            self._validate_target(target)
            self._validate_level_risk(level, risk)
            
            # Phase 2: Build SQLMap command (20%)
            await self._update_progress(20, "Building SQLMap command")
            command = self._build_sqlmap_command(
                target=target,
                parameters=parameters,
                technique=technique,
                level=level,
                risk=risk,
                tamper=tamper,
                threads=threads
            )
            
            # Phase 3: Execute SQLMap in Docker (60%)
            await self._update_progress(30, f"Executing SQLMap against {target}")
            result = await self._run_container(
                image=self.DOCKER_IMAGE,
                command=command,
                timeout=timeout,
                network="isolated_pentest",
                memory_limit="512m",
                cpu_quota=100000  # 1.0 CPU
            )
            
            # Phase 4: Parse output (80%)
            await self._update_progress(80, "Parsing SQLMap results")
            parsed_result = self._parse_sqlmap_output(result['stdout'])
            
            # Phase 5: Complete (100%)
            await self._update_progress(100, "SQL injection test completed")
            
            return {
                "attack_id": attack_id,
                "target": target,
                "injectable": parsed_result.get('injectable', False),
                "technique": parsed_result.get('technique', ''),
                "dbms": parsed_result.get('dbms', 'Unknown'),
                "version": parsed_result.get('version', ''),
                "vulnerabilities": parsed_result.get('vulnerabilities', []),
                "databases": parsed_result.get('databases', []),
                "tables": parsed_result.get('tables', []),
                "status": "completed",
                "metadata": {
                    "level": level,
                    "risk": risk,
                    "tamper": [t.value for t in tamper] if tamper else [],
                    "threads": threads,
                    "timestamp": time.time()
                }
            }
            
        except ContainerTimeoutError as e:
            logger.error(f"SQLMap execution timeout: {e}")
            return {
                "attack_id": attack_id,
                "target": target,
                "injectable": False,
                "status": "timeout",
                "error": str(e)
            }
            
        except Exception as e:
            logger.error(f"SQLMap execution error: {e}")
            return {
                "attack_id": attack_id,
                "target": target,
                "injectable": False,
                "status": "failed",
                "error": str(e)
            }
    
    def _build_sqlmap_command(
        self,
        target: str,
        parameters: Optional[List[str]],
        technique: InjectionTechnique,
        level: int,
        risk: int,
        tamper: Optional[List[TamperScript]],
        threads: int
    ) -> List[str]:
        """Build SQLMap command with all options."""
        command = [
            "sqlmap",
            "-u", target,
            "--batch",           # Never ask for user input
            "--flush-session",   # Clear session cache
            "--fresh-queries",   # Ignore cached results
            f"--technique={technique.value}",
            f"--level={level}",
            f"--risk={risk}",
            f"--threads={threads}",
            "--timeout=30",      # Connection timeout
            "--retries=2",       # Retry on timeout
        ]
        
        # Add parameter testing
        if parameters:
            command.extend(["-p", ",".join(parameters)])
        
        # Add tamper scripts for WAF bypass
        if tamper:
            tamper_str = ",".join([t.value for t in tamper])
            command.extend(["--tamper", tamper_str])
        
        # Add enumeration options (basic)
        command.append("--dbs")  # Enumerate databases
        
        logger.info(f"SQLMap command: {' '.join(command)}")
        return command
    
    def _parse_sqlmap_output(self, output: str) -> Dict[str, Any]:
        """
        Parse SQLMap output to extract results.
        
        Args:
            output: Raw SQLMap output
            
        Returns:
            Dict with parsed results
        """
        result = {
            'injectable': False,
            'technique': '',
            'dbms': 'Unknown',
            'version': '',
            'vulnerabilities': [],
            'databases': [],
            'tables': []
        }
        
        # Check if injection was found
        if 'is vulnerable' in output.lower() or 'injectable' in output.lower():
            result['injectable'] = True
        
        # Extract injection technique
        technique_patterns = {
            'boolean-based blind': 'Boolean-based blind',
            'error-based': 'Error-based',
            'union query': 'Union query',
            'stacked queries': 'Stacked queries',
            'time-based blind': 'Time-based blind',
        }
        
        for pattern, name in technique_patterns.items():
            if pattern in output.lower():
                result['technique'] = name
                break
        
        # Extract DBMS type
        dbms_patterns = {
            'mysql': DatabaseType.MYSQL.value,
            'postgresql': DatabaseType.POSTGRESQL.value,
            'microsoft sql server': DatabaseType.MSSQL.value,
            'oracle': DatabaseType.ORACLE.value,
            'sqlite': DatabaseType.SQLITE.value,
        }
        
        for pattern, dbms in dbms_patterns.items():
            if pattern in output.lower():
                result['dbms'] = dbms
                break
        
        # Extract database version
        version_match = re.search(r'back-end DBMS.*?(\d+\.\d+\.\d+)', output, re.IGNORECASE)
        if version_match:
            result['version'] = version_match.group(1)
        
        # Extract databases
        db_section = re.search(r'available databases.*?:\s*\[(.*?)\]', output, re.IGNORECASE | re.DOTALL)
        if db_section:
            databases = [db.strip().strip("'\"") for db in db_section.group(1).split(',')]
            result['databases'] = databases
        
        # Create vulnerability entry if injectable
        if result['injectable']:
            vuln = {
                'type': 'SQL_INJECTION',
                'severity': 'CRITICAL',
                'technique': result['technique'],
                'dbms': result['dbms'],
                'version': result['version'],
                'description': f"SQL injection vulnerability found using {result['technique']} technique"
            }
            result['vulnerabilities'].append(vuln)
        
        return result
    
    def _validate_target(self, target: str) -> None:
        """Validate target URL."""
        if not target:
            raise ValueError("Target URL is required")
        
        # Block localhost/127.0.0.1
        target_lower = target.lower()
        if any(blocked in target_lower for blocked in self.BLOCKED_TARGETS):
            raise ValueError(f"Target {target} is blocked for security reasons")
        
        # Basic URL validation
        if not target.startswith(('http://', 'https://')):
            raise ValueError(f"Target must start with http:// or https://")
        
        # Check for dangerous options in URL
        for dangerous in self.DANGEROUS_OPTIONS:
            if dangerous in target:
                raise ValueError(f"Dangerous option {dangerous} is not allowed")
    
    def _validate_level_risk(self, level: int, risk: int) -> None:
        """Validate level and risk parameters."""
        if not 1 <= level <= 5:
            raise ValueError(f"Level must be between 1 and 5, got {level}")
        
        if not 1 <= risk <= 3:
            raise ValueError(f"Risk must be between 1 and 3, got {risk}")
    
    def parse_output(self, raw_output: str) -> Dict[str, Any]:
        """
        Parse raw SQLMap output (required by BaseExecutor).
        
        Args:
            raw_output: Raw string output from SQLMap
            
        Returns:
            Dict with parsed fields
        """
        return self._parse_sqlmap_output(raw_output)
