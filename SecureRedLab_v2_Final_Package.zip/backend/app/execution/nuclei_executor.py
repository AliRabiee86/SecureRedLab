"""
SecureRedLab Backend - Nuclei Executor
Phase 7.5: Real Nuclei integration via Docker

Features:
- Docker-based Nuclei execution
- YAML template-based vulnerability scanning
- CVE detection with 1000+ templates
- Severity filtering (critical, high, medium, low, info)
- Tag-based template selection
- Multi-protocol support (HTTP, DNS, TCP, SSL)
- JSON output parsing (JSONL format)
- Real-time progress reporting
- Input validation & security controls

Author: SecureRedLab Team
Date: 2026-01-03
"""

import asyncio
import json
import time
from typing import Dict, Any, Optional, List, Callable
from enum import Enum
import logging
import re

from .base_executor import BaseExecutor, ContainerTimeoutError, ContainerExecutionError


# Configure logging
logger = logging.getLogger(__name__)


class SeverityLevel(str, Enum):
    """Nuclei severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class TemplateTag(str, Enum):
    """Common Nuclei template tags"""
    CVE = "cve"
    XSS = "xss"
    SQLI = "sqli"
    RCE = "rce"
    LFI = "lfi"
    SSRF = "ssrf"
    XXE = "xxe"
    EXPOSURE = "exposure"
    CONFIG = "config"
    PANEL = "panel"
    DEFAULT_LOGIN = "default-login"
    TECH = "tech"


class NucleiExecutor(BaseExecutor):
    """
    Nuclei executor with Docker-based template scanning.
    
    Capabilities:
    - YAML template-based vulnerability scanning
    - 5000+ community-driven templates
    - CVE detection (1000+ CVE templates)
    - Severity filtering (critical → info)
    - Tag-based template selection
    - Multi-protocol support (HTTP, DNS, TCP, SSL, File)
    - JSON Lines output parsing
    - Real-time progress reporting
    
    Security Controls:
    - Target validation (no localhost/127.0.0.1)
    - Internal IP blocking (10.0.0.0/8, 192.168.0.0/16, 172.16.0.0/12)
    - Resource limits (512MB RAM, 1.0 CPU)
    - Timeout enforcement (300s default)
    - Rate limiting (50 req/s max)
    - Network isolation
    """
    
    # Docker configuration
    DOCKER_IMAGE = "projectdiscovery/nuclei:latest"
    TIMEOUT_SECONDS = 300  # 5 minutes
    
    # Security settings
    BLOCKED_TARGETS = ["localhost", "127.0.0.1", "::1", "0.0.0.0"]
    INTERNAL_IP_PATTERNS = [
        r'^10\.',                    # 10.0.0.0/8
        r'^192\.168\.',              # 192.168.0.0/16
        r'^172\.(1[6-9]|2[0-9]|3[01])\.',  # 172.16.0.0/12
    ]
    
    def __init__(self, progress_callback: Optional[Callable[[int, str], None]] = None):
        """
        Initialize NucleiExecutor.
        
        Args:
            progress_callback: Optional callback for progress updates (progress: int, message: str)
        """
        super().__init__(progress_callback=progress_callback)
        logger.info("NucleiExecutor initialized successfully")
    
    async def execute(
        self,
        target: str,
        templates: Optional[List[str]] = None,
        tags: Optional[List[TemplateTag]] = None,
        severity: Optional[List[SeverityLevel]] = None,
        concurrency: int = 25,
        rate_limit: int = 50,
        timeout: int = TIMEOUT_SECONDS,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute Nuclei vulnerability scan against target.
        
        Args:
            target: Target URL (e.g., 'https://example.com')
            templates: Specific template files/directories to use
            tags: Template tags to filter (e.g., ['cve', 'xss'])
            severity: Severity levels to scan (e.g., ['critical', 'high'])
            concurrency: Concurrent requests (default: 25)
            rate_limit: Rate limit per second (default: 50)
            timeout: Execution timeout in seconds
            **kwargs: Additional arguments
        
        Returns:
            Dict with:
                - scan_id: Unique scan identifier
                - target: Target URL
                - vulnerabilities: List of found vulnerabilities
                - templates_matched: Number of matched templates
                - severity_counts: Counts by severity
                - status: Execution status
                - error: Error message (if failed)
        
        Raises:
            ContainerExecutionError: If execution fails
            ContainerTimeoutError: If execution times out
        """
        scan_id = kwargs.get('scan_id', f"nuclei_{int(time.time())}")
        
        try:
            # Phase 1: Validate inputs (10%)
            await self._update_progress(10, f"Validating target {target}")
            self._validate_target(target)
            
            # Phase 2: Build Nuclei command (20%)
            await self._update_progress(20, "Building Nuclei command")
            command = self._build_nuclei_command(
                target=target,
                templates=templates,
                tags=tags,
                severity=severity,
                concurrency=concurrency,
                rate_limit=rate_limit
            )
            
            # Phase 3: Execute Nuclei in Docker (70%)
            await self._update_progress(30, f"Executing Nuclei scan against {target}")
            result = await self._run_container(
                image=self.DOCKER_IMAGE,
                command=command,
                timeout=timeout,
                network="isolated_pentest",
                memory_limit="512m",
                cpu_quota=100000  # 1.0 CPU
            )
            
            # Phase 4: Parse output (90%)
            await self._update_progress(90, "Parsing Nuclei results")
            parsed_result = self._parse_nuclei_output(result['stdout'])
            
            # Phase 5: Complete (100%)
            await self._update_progress(100, "Vulnerability scan completed")
            
            return {
                "scan_id": scan_id,
                "target": target,
                "vulnerabilities": parsed_result.get('vulnerabilities', []),
                "templates_matched": parsed_result.get('templates_matched', 0),
                "severity_counts": parsed_result.get('severity_counts', {}),
                "status": "completed",
                "metadata": {
                    "templates": templates or [],
                    "tags": [t.value for t in tags] if tags else [],
                    "severity_filter": [s.value for s in severity] if severity else [],
                    "concurrency": concurrency,
                    "rate_limit": rate_limit,
                    "timestamp": time.time()
                }
            }
            
        except ContainerTimeoutError as e:
            logger.error(f"Nuclei execution timeout: {e}")
            return {
                "scan_id": scan_id,
                "target": target,
                "vulnerabilities": [],
                "status": "timeout",
                "error": str(e)
            }
            
        except Exception as e:
            logger.error(f"Nuclei execution error: {e}")
            return {
                "scan_id": scan_id,
                "target": target,
                "vulnerabilities": [],
                "status": "failed",
                "error": str(e)
            }
    
    def _build_nuclei_command(
        self,
        target: str,
        templates: Optional[List[str]],
        tags: Optional[List[TemplateTag]],
        severity: Optional[List[SeverityLevel]],
        concurrency: int,
        rate_limit: int
    ) -> List[str]:
        """Build Nuclei command with all options."""
        command = [
            "nuclei",
            "-u", target,
            "-json",          # JSON Lines output
            "-silent",        # Only show results
            "-no-color",      # No color codes
        ]
        
        # Add template selection
        if templates:
            for template in templates:
                command.extend(["-t", template])
        
        # Add tag filtering
        if tags:
            tag_str = ",".join([t.value for t in tags])
            command.extend(["-tags", tag_str])
        
        # Add severity filtering
        if severity:
            severity_str = ",".join([s.value for s in severity])
            command.extend(["-severity", severity_str])
        
        # Add performance options
        command.extend([
            "-c", str(concurrency),
            "-rate-limit", str(rate_limit),
            "-timeout", "5",  # 5 second timeout per request
            "-retries", "1",  # 1 retry on failure
        ])
        
        logger.info(f"Nuclei command: {' '.join(command)}")
        return command
    
    def _parse_nuclei_output(self, output: str) -> Dict[str, Any]:
        """
        Parse Nuclei JSON Lines output to extract vulnerabilities.
        
        Args:
            output: Raw Nuclei output (JSON Lines format)
            
        Returns:
            Dict with parsed results
        """
        vulnerabilities = []
        severity_counts = {
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'info': 0
        }
        
        # Parse each line as separate JSON
        lines = output.strip().split('\n')
        for line in lines:
            if not line.strip():
                continue
            
            try:
                data = json.loads(line)
                
                # Extract vulnerability information
                vuln = {
                    'template_id': data.get('template-id', 'unknown'),
                    'name': data.get('info', {}).get('name', 'Unknown'),
                    'severity': data.get('info', {}).get('severity', 'info'),
                    'type': data.get('type', 'unknown'),
                    'matched_at': data.get('matched-at', ''),
                    'description': data.get('info', {}).get('description', ''),
                    'tags': data.get('info', {}).get('tags', []),
                    'author': data.get('info', {}).get('author', 'unknown'),
                    'curl_command': data.get('curl-command', ''),
                    'timestamp': data.get('timestamp', '')
                }
                
                vulnerabilities.append(vuln)
                
                # Count by severity
                severity_level = vuln['severity'].lower()
                if severity_level in severity_counts:
                    severity_counts[severity_level] += 1
                
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse JSON line: {e}")
                continue
        
        return {
            'vulnerabilities': vulnerabilities,
            'templates_matched': len(vulnerabilities),
            'severity_counts': severity_counts
        }
    
    def _validate_target(self, target: str) -> None:
        """Validate target URL."""
        if not target:
            raise ValueError("Target URL is required")
        
        # Block localhost/127.0.0.1
        target_lower = target.lower()
        if any(blocked in target_lower for blocked in self.BLOCKED_TARGETS):
            raise ValueError(f"Target {target} is blocked for security reasons")
        
        # Block internal IPs
        for pattern in self.INTERNAL_IP_PATTERNS:
            if re.search(pattern, target):
                raise ValueError(f"Internal IP addresses are not allowed: {target}")
        
        # Basic URL validation
        if not target.startswith(('http://', 'https://')):
            raise ValueError(f"Target must start with http:// or https://")
    
    def parse_output(self, raw_output: str) -> Dict[str, Any]:
        """
        Parse raw Nuclei output (required by BaseExecutor).
        
        Args:
            raw_output: Raw string output from Nuclei
            
        Returns:
            Dict with parsed fields
        """
        return self._parse_nuclei_output(raw_output)
