"""
SecureRedLab Backend - Nmap Executor
Phase 7.2: Real Nmap implementation with Docker and XML parsing

Features:
- Multiple scan types (SYN, TCP, UDP, etc.)
- Service version detection
- OS fingerprinting
- NSE scripts support
- XML output parsing with python-nmap
- Real-time progress updates
"""

from app.execution.base_executor import BaseExecutor, ContainerTimeoutError
from typing import Dict, Any, Optional, List, Callable
import nmap
import re
import logging
import xml.etree.ElementTree as ET

logger = logging.getLogger(__name__)


class NmapExecutor(BaseExecutor):
    """
    Nmap scanner executor with Docker isolation
    
    Supports multiple scan types, service detection, OS fingerprinting,
    and NSE script execution with real-time progress updates.
    """
    
    # Docker configuration
    DOCKER_IMAGE = "instrumentisto/nmap:latest"
    DEFAULT_TIMEOUT = 300  # 5 minutes
    
    # Scan type mappings
    SCAN_TYPES = {
        "syn": "-sS",           # SYN (Stealth) scan - requires privileged
        "tcp": "-sT",           # TCP Connect scan
        "udp": "-sU",           # UDP scan - requires privileged
        "fin": "-sF",           # FIN scan - requires privileged
        "null": "-sN",          # Null scan - requires privileged
        "xmas": "-sX",          # Xmas scan - requires privileged
        "ack": "-sA",           # ACK scan - requires privileged
        "window": "-sW",        # Window scan - requires privileged
        "ping": "-sn",          # Ping scan (no port scan)
        "version": "-sV",       # Service version detection
    }
    
    # Scan types that require --privileged
    PRIVILEGED_SCANS = {"syn", "udp", "fin", "null", "xmas", "ack", "window"}
    
    def __init__(self, progress_callback: Optional[Callable] = None):
        super().__init__(progress_callback=progress_callback)
        self.tool_name = "Nmap"
        
        # Initialize nmap scanner (may fail if nmap not installed locally)
        try:
            self.nm = nmap.PortScanner()
        except Exception as e:
            self.logger.warning(f"Nmap not found locally (will use Docker): {e}")
            self.nm = None  # Will rely on Docker container
    
    async def execute(
        self,
        target: str,
        ports: str = "1-1000",
        scan_type: str = "syn",
        service_detection: bool = False,
        os_detection: bool = False,
        nse_scripts: Optional[List[str]] = None,
        timing: int = 4,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute Nmap scan in Docker container
        
        Args:
            target: Target IP, domain, or CIDR range
            ports: Port specification (e.g., "1-1000", "22,80,443", "-")
            scan_type: Type of scan (syn, tcp, udp, etc.)
            service_detection: Enable service version detection (-sV)
            os_detection: Enable OS fingerprinting (-O)
            nse_scripts: List of NSE scripts to run (e.g., ["vuln", "default"])
            timing: Timing template 0-5 (default: 4)
            **kwargs: Additional arguments (scan_id, etc.)
        
        Returns:
            dict: Scan results with hosts, ports, services, OS info
        """
        scan_id = kwargs.get("scan_id", "unknown")
        
        try:
            await self._update_progress(5, f"Initializing Nmap scan for {target}")
            
            # Validate inputs
            self._validate_target(target)
            self._validate_ports(ports)
            self._validate_scan_type(scan_type)
            
            await self._update_progress(10, "Building Nmap command")
            
            # Build Nmap command
            command = self._build_nmap_command(
                target=target,
                ports=ports,
                scan_type=scan_type,
                service_detection=service_detection,
                os_detection=os_detection,
                nse_scripts=nse_scripts,
                timing=timing
            )
            
            self.logger.info(f"[NMAP] Command: {command}")
            
            await self._update_progress(15, f"Starting {scan_type.upper()} scan on {target}")
            
            # Determine if we need privileged mode
            needs_privileged = (
                scan_type in self.PRIVILEGED_SCANS or 
                os_detection
            )
            
            # Execute in Docker container
            result = await self._run_container(
                image=self.DOCKER_IMAGE,
                command=command,
                timeout=kwargs.get("timeout", self.DEFAULT_TIMEOUT),
                network=kwargs.get("network", "isolated_pentest"),
                stream_logs=True,
                # Override security settings for privileged scans
                read_only=False if needs_privileged else True,
                # Add privileged flag if needed
                # Note: This is handled in BaseExecutor's container create
            )
            
            await self._update_progress(95, "Parsing scan results")
            
            # Parse XML output
            parsed_results = self.parse_output(result["stdout"])
            
            # Add metadata
            parsed_results.update({
                "scan_id": scan_id,
                "target": target,
                "ports_scanned": ports,
                "scan_type": scan_type,
                "scan_time": result.get("duration", 0),
                "exit_code": result["exit_code"],
                "container_id": result.get("container_id", ""),
                "status": "completed" if result["exit_code"] == 0 else "failed"
            })
            
            await self._update_progress(100, "Scan completed")
            
            return parsed_results
        
        except ContainerTimeoutError as e:
            self.logger.error(f"[NMAP] Scan {scan_id} timed out: {e}")
            return {
                "scan_id": scan_id,
                "target": target,
                "status": "timeout",
                "error": str(e)
            }
        
        except Exception as e:
            self.logger.error(f"[NMAP] Scan {scan_id} failed: {e}")
            return {
                "scan_id": scan_id,
                "target": target,
                "status": "error",
                "error": str(e)
            }
    
    def _build_nmap_command(
        self,
        target: str,
        ports: str,
        scan_type: str,
        service_detection: bool,
        os_detection: bool,
        nse_scripts: Optional[List[str]],
        timing: int
    ) -> str:
        """
        Build Nmap command with all options
        
        Args:
            target: Target specification
            ports: Port specification
            scan_type: Scan type
            service_detection: Enable -sV
            os_detection: Enable -O
            nse_scripts: NSE scripts to run
            timing: Timing template
        
        Returns:
            str: Complete Nmap command
        """
        # Start with base command
        cmd_parts = ["nmap"]
        
        # Add scan type
        if scan_type in self.SCAN_TYPES:
            cmd_parts.append(self.SCAN_TYPES[scan_type])
        
        # Add port specification (unless ping scan)
        if scan_type != "ping" and ports != "-":
            cmd_parts.append(f"-p {ports}")
        
        # Add service detection
        if service_detection:
            cmd_parts.append("-sV")
        
        # Add OS detection
        if os_detection:
            cmd_parts.append("-O")
        
        # Add NSE scripts
        if nse_scripts:
            scripts_str = ",".join(nse_scripts)
            cmd_parts.append(f"--script {scripts_str}")
        
        # Add timing template
        cmd_parts.append(f"-T{timing}")
        
        # Add other useful flags
        cmd_parts.extend([
            "-Pn",              # Skip ping (assume host is up)
            "--stats-every 5s", # Progress stats every 5 seconds
            "-oX -",            # XML output to stdout
            "-v",               # Verbose output
        ])
        
        # Add target
        cmd_parts.append(target)
        
        return " ".join(cmd_parts)
    
    def parse_output(self, raw_output: str) -> Dict[str, Any]:
        """
        Parse Nmap XML output into structured format
        
        Args:
            raw_output: Raw XML output from Nmap
            
        Returns:
            dict: Parsed scan results
        """
        try:
            # Check if nmap scanner available
            if not self.nm:
                self.logger.warning("Nmap parser not available, returning raw output")
                return {
                    "hosts": [],
                    "hosts_up": 0,
                    "raw_output": raw_output[:500],
                    "note": "Nmap parser not available - install nmap locally for full parsing"
                }
            
            # Check if output contains XML
            if "<?xml" not in raw_output:
                self.logger.warning("[NMAP] No XML found in output, extracting from text")
                # Extract XML from mixed output
                xml_match = re.search(r'(<\?xml.*?</nmaprun>)', raw_output, re.DOTALL)
                if xml_match:
                    raw_output = xml_match.group(1)
                else:
                    return {
                        "hosts": [],
                        "hosts_up": 0,
                        "error": "No XML output found",
                        "raw_output": raw_output[:500]  # First 500 chars
                    }
            
            # Parse XML with python-nmap
            self.nm.analyse_nmap_xml_scan(raw_output)
            
            # Extract results
            results = {
                "hosts": [],
                "hosts_up": 0,
                "hosts_down": 0,
                "total_hosts": len(self.nm.all_hosts()),
                "statistics": {}
            }
            
            # Process each host
            for host in self.nm.all_hosts():
                host_data = self._parse_host(host)
                results["hosts"].append(host_data)
                
                if host_data["state"] == "up":
                    results["hosts_up"] += 1
                else:
                    results["hosts_down"] += 1
            
            # Add scan statistics
            if hasattr(self.nm, 'scanstats'):
                results["statistics"] = self.nm.scanstats()
            
            return results
        
        except Exception as e:
            self.logger.error(f"[NMAP] XML parsing failed: {e}")
            return {
                "hosts": [],
                "hosts_up": 0,
                "error": f"XML parsing failed: {str(e)}",
                "raw_output": raw_output[:500]
            }
    
    def _parse_host(self, host: str) -> Dict[str, Any]:
        """
        Parse individual host data from Nmap results
        
        Args:
            host: Host IP address
            
        Returns:
            dict: Host information with ports, services, OS
        """
        host_data = {
            "ip": host,
            "hostname": self.nm[host].hostname() if self.nm[host].hostname() else "",
            "state": self.nm[host].state(),
            "open_ports": [],
            "closed_ports": 0,
            "filtered_ports": 0,
            "os_detection": None,
            "mac_address": None,
            "vendor": None
        }
        
        # Parse ports
        for proto in self.nm[host].all_protocols():
            ports = self.nm[host][proto].keys()
            
            for port in ports:
                port_info = self.nm[host][proto][port]
                port_state = port_info["state"]
                
                if port_state == "open":
                    port_data = {
                        "port": port,
                        "protocol": proto,
                        "state": port_state,
                        "service": {
                            "name": port_info.get("name", "unknown"),
                            "product": port_info.get("product", ""),
                            "version": port_info.get("version", ""),
                            "extrainfo": port_info.get("extrainfo", ""),
                            "cpe": port_info.get("cpe", "")
                        },
                        "script_results": port_info.get("script", {})
                    }
                    host_data["open_ports"].append(port_data)
                
                elif port_state == "closed":
                    host_data["closed_ports"] += 1
                
                elif port_state == "filtered":
                    host_data["filtered_ports"] += 1
        
        # Parse OS detection
        if "osmatch" in self.nm[host]:
            os_matches = self.nm[host]["osmatch"]
            if os_matches:
                best_match = os_matches[0]
                host_data["os_detection"] = {
                    "name": best_match.get("name", ""),
                    "accuracy": int(best_match.get("accuracy", 0)),
                    "cpe": best_match.get("cpe", [])
                }
        
        # Parse MAC address
        if "mac" in self.nm[host]["addresses"]:
            host_data["mac_address"] = self.nm[host]["addresses"]["mac"]
        
        if "vendor" in self.nm[host]:
            host_data["vendor"] = self.nm[host]["vendor"]
        
        return host_data
    
    def _validate_target(self, target: str):
        """
        Validate target format
        
        Args:
            target: Target IP or domain
            
        Raises:
            ValueError: If target is invalid
        """
        if not target or not isinstance(target, str):
            raise ValueError("Target must be a non-empty string")
        
        # Block localhost/loopback
        blocked_targets = ["localhost", "127.0.0.1", "::1", "0.0.0.0"]
        if target.lower() in blocked_targets:
            raise ValueError(f"Target {target} is not allowed")
        
        # Basic validation (IPv4, IPv6, domain, CIDR)
        # This is a simple check, Nmap will do more thorough validation
        valid_patterns = [
            r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$',  # IPv4
            r'^[\da-fA-F:]+$',                          # IPv6
            r'^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',        # Domain
            r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}$',  # CIDR
        ]
        
        if not any(re.match(pattern, target) for pattern in valid_patterns):
            raise ValueError(f"Invalid target format: {target}")
    
    def _validate_ports(self, ports: str):
        """
        Validate port specification
        
        Args:
            ports: Port specification
            
        Raises:
            ValueError: If ports are invalid
        """
        if not ports or not isinstance(ports, str):
            raise ValueError("Ports must be a non-empty string")
        
        # Allow "-" for all ports
        if ports == "-":
            return
        
        # Validate port ranges and lists
        # Examples: "80", "80,443", "1-1000", "20-25,80,443,8000-9000"
        valid_pattern = r'^(\d+(-\d+)?)(,\d+(-\d+)?)*$'
        if not re.match(valid_pattern, ports):
            raise ValueError(f"Invalid port specification: {ports}")
        
        # Check port numbers are in valid range (1-65535)
        for part in ports.split(','):
            if '-' in part:
                start, end = part.split('-')
                if not (1 <= int(start) <= 65535 and 1 <= int(end) <= 65535):
                    raise ValueError(f"Port numbers must be between 1 and 65535")
            else:
                if not (1 <= int(part) <= 65535):
                    raise ValueError(f"Port numbers must be between 1 and 65535")
    
    def _validate_scan_type(self, scan_type: str):
        """
        Validate scan type
        
        Args:
            scan_type: Scan type
            
        Raises:
            ValueError: If scan type is invalid
        """
        if scan_type not in self.SCAN_TYPES:
            valid_types = ", ".join(self.SCAN_TYPES.keys())
            raise ValueError(f"Invalid scan type: {scan_type}. Valid types: {valid_types}")
