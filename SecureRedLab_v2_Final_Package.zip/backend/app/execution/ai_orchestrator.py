"""
SecureRedLab Backend - AI-Controlled Tools Orchestrator
Phase 7.x: Integration with AI cores for intelligent tool execution

This module provides AI-driven orchestration of security tools.
The AI decides which tools to run, with what parameters, and interprets results.
"""

import asyncio
from typing import Dict, Any, Optional, List, Callable
from enum import Enum
import json
import logging

from app.execution import (
    BaseExecutor,
    NmapExecutor,
    MetasploitExecutor,
    SQLMapExecutor,
    NucleiExecutor
)

logger = logging.getLogger(__name__)


class ToolType(Enum):
    """Available security tools"""
    NMAP = "nmap"
    METASPLOIT = "metasploit"
    SQLMAP = "sqlmap"
    NUCLEI = "nuclei"


class AIOrchestrator:
    """
    AI-Controlled Security Tools Orchestrator
    
    This class integrates security tool executors with AI cores to provide:
    - Intelligent tool selection based on target analysis
    - Parameter optimization using AI
    - Result interpretation and next-step recommendations
    - Adaptive attack strategies
    
    Architecture:
    User Input → AI Analysis → Tool Selection → Execution → AI Interpretation → Results
    """
    
    def __init__(self, progress_callback: Optional[Callable] = None):
        """
        Initialize AI Orchestrator
        
        Args:
            progress_callback: Optional callback for progress updates
        """
        self.progress_callback = progress_callback
        self.logger = logger
        
        # Initialize tool executors
        self.executors: Dict[ToolType, BaseExecutor] = {
            ToolType.NMAP: NmapExecutor(progress_callback=progress_callback),
            ToolType.METASPLOIT: MetasploitExecutor(progress_callback=progress_callback),
            ToolType.SQLMAP: SQLMapExecutor(progress_callback=progress_callback),
            ToolType.NUCLEI: NucleiExecutor(progress_callback=progress_callback)
        }
        
        # AI integration will be added here
        self.ai_engine = None  # TODO: Integrate with scanner_ai_adapter
        
        # Execution history for learning
        self.execution_history: List[Dict[str, Any]] = []
        
        self.logger.info("AI Orchestrator initialized with 4 tools")
    
    async def analyze_target(self, target: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """
        AI-driven target analysis to determine reconnaissance strategy
        
        Args:
            target: Target IP, domain, or URL
            context: Optional context (previous scan results, known info)
        
        Returns:
            dict: Analysis results with recommended tools and parameters
        """
        self.logger.info(f"AI analyzing target: {target}")
        
        # TODO: Use AI to analyze target
        # For now, return a basic strategy
        
        analysis = {
            "target": target,
            "target_type": self._detect_target_type(target),
            "recommended_tools": [],
            "execution_plan": []
        }
        
        # Determine target type
        target_type = analysis["target_type"]
        
        # Build execution plan based on target type
        if target_type == "ip" or target_type == "domain":
            # Network target - start with Nmap
            analysis["recommended_tools"].append("nmap")
            analysis["execution_plan"].append({
                "tool": "nmap",
                "phase": "reconnaissance",
                "parameters": {
                    "target": target,
                    "ports": "1-1000",
                    "scan_type": "syn",
                    "service_detection": True
                }
            })
        
        elif target_type == "url":
            # Web target - start with Nuclei
            analysis["recommended_tools"].append("nuclei")
            analysis["execution_plan"].append({
                "tool": "nuclei",
                "phase": "vulnerability_scan",
                "parameters": {
                    "target": target,
                    "templates": ["default"],
                    "severity": "high"
                }
            })
        
        return analysis
    
    async def execute_reconnaissance(
        self,
        target: str,
        scan_id: str,
        deep_scan: bool = False
    ) -> Dict[str, Any]:
        """
        Execute AI-guided reconnaissance phase
        
        Args:
            target: Target specification
            scan_id: Unique scan identifier
            deep_scan: Enable deep scanning (more aggressive)
        
        Returns:
            dict: Reconnaissance results
        """
        self.logger.info(f"Starting AI-guided reconnaissance: {target}")
        
        try:
            # Phase 1: Analyze target
            analysis = await self.analyze_target(target)
            
            # Phase 2: Execute Nmap scan
            nmap_executor = self.executors[ToolType.NMAP]
            
            scan_params = {
                "target": target,
                "ports": "1-65535" if deep_scan else "1-1000",
                "scan_type": "syn",
                "service_detection": True,
                "os_detection": deep_scan,
                "scan_id": scan_id
            }
            
            nmap_results = await nmap_executor.execute(**scan_params)
            
            # Phase 3: AI interprets results
            interpretation = await self._interpret_nmap_results(nmap_results)
            
            # Phase 4: Determine next steps
            next_steps = await self._determine_next_steps(nmap_results, interpretation)
            
            results = {
                "scan_id": scan_id,
                "target": target,
                "phase": "reconnaissance",
                "nmap_results": nmap_results,
                "ai_interpretation": interpretation,
                "next_steps": next_steps,
                "status": "completed"
            }
            
            # Save to history
            self.execution_history.append(results)
            
            return results
        
        except Exception as e:
            self.logger.error(f"Reconnaissance failed: {e}")
            return {
                "scan_id": scan_id,
                "target": target,
                "phase": "reconnaissance",
                "status": "error",
                "error": str(e)
            }
    
    async def execute_vulnerability_scan(
        self,
        target: str,
        scan_id: str,
        reconnaissance_data: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Execute AI-guided vulnerability scanning
        
        Args:
            target: Target specification
            scan_id: Unique scan identifier
            reconnaissance_data: Optional data from previous recon
        
        Returns:
            dict: Vulnerability scan results
        """
        self.logger.info(f"Starting AI-guided vulnerability scan: {target}")
        
        try:
            # Use Nuclei for vulnerability scanning
            nuclei_executor = self.executors[ToolType.NUCLEI]
            
            # AI determines which templates to use
            templates = await self._select_nuclei_templates(target, reconnaissance_data)
            
            nuclei_results = await nuclei_executor.execute(
                target=target,
                templates=templates,
                severity="critical,high",
                scan_id=scan_id
            )
            
            # AI interprets vulnerabilities
            interpretation = await self._interpret_vulnerabilities(nuclei_results)
            
            results = {
                "scan_id": scan_id,
                "target": target,
                "phase": "vulnerability_scan",
                "nuclei_results": nuclei_results,
                "ai_interpretation": interpretation,
                "status": "completed"
            }
            
            self.execution_history.append(results)
            return results
        
        except Exception as e:
            self.logger.error(f"Vulnerability scan failed: {e}")
            return {
                "scan_id": scan_id,
                "target": target,
                "phase": "vulnerability_scan",
                "status": "error",
                "error": str(e)
            }
    
    async def execute_exploitation(
        self,
        target: str,
        attack_id: str,
        vulnerability_data: Dict[str, Any],
        safe_mode: bool = True
    ) -> Dict[str, Any]:
        """
        Execute AI-guided exploitation phase
        
        Args:
            target: Target specification
            attack_id: Unique attack identifier
            vulnerability_data: Vulnerability information from scan
            safe_mode: Enable safe mode (no actual exploitation)
        
        Returns:
            dict: Exploitation results
        """
        self.logger.info(f"Starting AI-guided exploitation: {target}")
        
        if safe_mode:
            self.logger.warning("Safe mode enabled - simulation only")
        
        try:
            # AI selects exploit based on vulnerability
            exploit_plan = await self._select_exploit(vulnerability_data)
            
            # Execute with Metasploit (or simulate if safe_mode)
            metasploit_executor = self.executors[ToolType.METASPLOIT]
            
            exploit_results = await metasploit_executor.execute(
                target=target,
                module=exploit_plan["module"],
                payload=exploit_plan.get("payload"),
                options=exploit_plan.get("options", {}),
                attack_id=attack_id
            )
            
            results = {
                "attack_id": attack_id,
                "target": target,
                "phase": "exploitation",
                "exploit_plan": exploit_plan,
                "exploit_results": exploit_results,
                "safe_mode": safe_mode,
                "status": "completed"
            }
            
            self.execution_history.append(results)
            return results
        
        except Exception as e:
            self.logger.error(f"Exploitation failed: {e}")
            return {
                "attack_id": attack_id,
                "target": target,
                "phase": "exploitation",
                "status": "error",
                "error": str(e)
            }
    
    # ==================== Private Helper Methods ====================
    
    def _detect_target_type(self, target: str) -> str:
        """Detect target type (IP, domain, URL)"""
        import re
        
        # IPv4
        if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target):
            return "ip"
        
        # URL
        if target.startswith("http://") or target.startswith("https://"):
            return "url"
        
        # Domain
        if "." in target and not target.startswith("http"):
            return "domain"
        
        return "unknown"
    
    async def _interpret_nmap_results(self, nmap_results: Dict) -> Dict[str, Any]:
        """
        AI interprets Nmap scan results
        
        TODO: Use AI engine for intelligent interpretation
        """
        interpretation = {
            "summary": "",
            "open_services": [],
            "security_concerns": [],
            "recommendations": []
        }
        
        # Basic interpretation (will be replaced with AI)
        if "hosts" in nmap_results and nmap_results["hosts"]:
            host = nmap_results["hosts"][0]
            
            open_ports_count = len(host.get("open_ports", []))
            interpretation["summary"] = f"Found {open_ports_count} open ports"
            
            # Extract services
            for port_info in host.get("open_ports", []):
                service = port_info.get("service", {})
                interpretation["open_services"].append({
                    "port": port_info["port"],
                    "service": service.get("name", "unknown"),
                    "version": service.get("version", "")
                })
            
            # Security concerns (basic rules, AI will improve this)
            if any(p["port"] == 22 for p in host.get("open_ports", [])):
                interpretation["security_concerns"].append("SSH exposed")
            
            if any(p["port"] in [80, 8080] for p in host.get("open_ports", [])):
                interpretation["recommendations"].append("Run web vulnerability scan")
        
        return interpretation
    
    async def _determine_next_steps(
        self,
        scan_results: Dict,
        interpretation: Dict
    ) -> List[Dict]:
        """
        AI determines next steps based on scan results
        
        TODO: Use AI engine for intelligent planning
        """
        next_steps = []
        
        # Check if web services found
        if "run web vulnerability scan" in interpretation.get("recommendations", []):
            next_steps.append({
                "tool": "nuclei",
                "reason": "Web services detected",
                "parameters": {
                    "templates": ["web", "cves"],
                    "severity": "high"
                }
            })
        
        return next_steps
    
    async def _select_nuclei_templates(
        self,
        target: str,
        reconnaissance_data: Optional[Dict]
    ) -> List[str]:
        """
        AI selects appropriate Nuclei templates
        
        TODO: Use AI engine for intelligent template selection
        """
        # Default templates
        templates = ["default"]
        
        # Add specific templates based on reconnaissance
        if reconnaissance_data:
            # TODO: Analyze reconnaissance data and select targeted templates
            pass
        
        return templates
    
    async def _interpret_vulnerabilities(self, scan_results: Dict) -> Dict[str, Any]:
        """
        AI interprets vulnerability scan results
        
        TODO: Use AI engine for intelligent interpretation
        """
        interpretation = {
            "critical_count": 0,
            "high_count": 0,
            "exploitable": [],
            "recommendations": []
        }
        
        # Basic interpretation (will be replaced with AI)
        vulnerabilities = scan_results.get("vulnerabilities", [])
        
        for vuln in vulnerabilities:
            severity = vuln.get("severity", "").lower()
            if severity == "critical":
                interpretation["critical_count"] += 1
                interpretation["exploitable"].append(vuln)
            elif severity == "high":
                interpretation["high_count"] += 1
        
        return interpretation
    
    async def _select_exploit(self, vulnerability_data: Dict) -> Dict[str, Any]:
        """
        AI selects appropriate exploit
        
        TODO: Use AI engine for intelligent exploit selection
        """
        # Default safe exploit plan
        return {
            "module": "auxiliary/scanner/http/http_version",
            "payload": None,
            "options": {},
            "safe": True,
            "reason": "Safe reconnaissance module"
        }
    
    def get_execution_history(self) -> List[Dict[str, Any]]:
        """Get execution history for analysis"""
        return self.execution_history
    
    def clear_history(self):
        """Clear execution history"""
        self.execution_history.clear()


# Singleton instance
_orchestrator_instance: Optional[AIOrchestrator] = None


def get_ai_orchestrator(progress_callback: Optional[Callable] = None) -> AIOrchestrator:
    """
    Get singleton AI Orchestrator instance
    
    Args:
        progress_callback: Optional progress callback
    
    Returns:
        AIOrchestrator instance
    """
    global _orchestrator_instance
    
    if _orchestrator_instance is None:
        _orchestrator_instance = AIOrchestrator(progress_callback=progress_callback)
    
    return _orchestrator_instance
