"""
SecureRedLab Backend - Enhanced Base Executor
Abstract base class for all security tool executors with full lifecycle management

Features:
- Async Docker container execution with real-time streaming
- Resource limits (CPU, memory)
- Timeout handling with graceful shutdown
- Real-time log streaming
- Automatic cleanup on errors
- Kill switch for emergency stops
- Retry logic with exponential backoff
"""

from abc import ABC, abstractmethod
import docker
import logging
import asyncio
from typing import Dict, Any, Optional, AsyncGenerator, Callable
from datetime import datetime
import json
import os

logger = logging.getLogger(__name__)


class ContainerTimeoutError(Exception):
    """Raised when container execution exceeds timeout"""
    pass


class ContainerExecutionError(Exception):
    """Raised when container execution fails"""
    pass


class BaseExecutor(ABC):
    """
    Abstract base class for security tool executors
    
    All executors run tools in isolated Docker containers for security.
    Provides real-time streaming, resource limits, and timeout handling.
    """
    
    # Default resource limits
    DEFAULT_MEM_LIMIT = "512m"  # 512MB RAM
    DEFAULT_CPU_QUOTA = 100000  # 1.0 CPU (100000 = 100%)
    DEFAULT_CPU_PERIOD = 100000
    DEFAULT_NETWORK = "isolated_pentest"
    DEFAULT_TIMEOUT = 300  # 5 minutes
    
    def __init__(self, progress_callback: Optional[Callable] = None):
        """
        Initialize executor with Docker client
        
        Args:
            progress_callback: Optional callback function for progress updates
                               Signature: callback(progress: int, message: str)
        """
        # Initialize logger first
        self.logger = logger
        self.progress_callback = progress_callback
        self._running_containers = set()
        
        # Try to initialize Docker client
        try:
            self.docker_client = docker.from_env()
            self.logger.info(f"Initialized {self.__class__.__name__}")
        except Exception as e:
            self.logger.error(f"Failed to initialize Docker client: {e}")
            self.docker_client = None
    
    @abstractmethod
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the security tool
        
        Returns:
            dict: Execution results
        """
        pass
    
    @abstractmethod
    def parse_output(self, raw_output: str) -> Dict[str, Any]:
        """
        Parse tool output into structured format
        
        Args:
            raw_output: Raw tool output string
            
        Returns:
            dict: Parsed results
        """
        pass
    
    async def _update_progress(self, progress: int, message: str):
        """
        Update progress via callback
        
        Args:
            progress: Progress percentage (0-100)
            message: Status message
        """
        if self.progress_callback:
            try:
                if asyncio.iscoroutinefunction(self.progress_callback):
                    await self.progress_callback(progress, message)
                else:
                    self.progress_callback(progress, message)
            except Exception as e:
                self.logger.error(f"Progress callback failed: {e}")
    
    async def _run_container(
        self,
        image: str,
        command: str,
        timeout: int = DEFAULT_TIMEOUT,
        network: str = DEFAULT_NETWORK,
        volumes: Optional[Dict[str, Dict[str, str]]] = None,
        environment: Optional[Dict[str, str]] = None,
        mem_limit: str = DEFAULT_MEM_LIMIT,
        cpu_quota: int = DEFAULT_CPU_QUOTA,
        stream_logs: bool = True,
        auto_remove: bool = True,
        read_only: bool = True,
        user: str = "nobody"
    ) -> Dict[str, Any]:
        """
        Run command in isolated Docker container with full lifecycle management
        
        Args:
            image: Docker image name
            command: Command to execute
            timeout: Execution timeout in seconds
            network: Docker network name
            volumes: Volume mounts
            environment: Environment variables
            mem_limit: Memory limit (e.g., "512m", "1g")
            cpu_quota: CPU quota (100000 = 1.0 CPU)
            stream_logs: Whether to stream logs in real-time
            auto_remove: Remove container after execution
            read_only: Mount root filesystem as read-only
            user: User to run as (default: nobody for security)
            
        Returns:
            dict: Execution results with stdout, stderr, exit_code, duration
            
        Raises:
            ContainerTimeoutError: If execution exceeds timeout
            ContainerExecutionError: If execution fails
        """
        if not self.docker_client:
            raise RuntimeError("Docker client not initialized")
        
        container = None
        container_id = None
        start_time = datetime.now()
        
        try:
            await self._update_progress(5, f"Pulling image {image}...")
            
            # Pull image if not exists
            try:
                self.docker_client.images.get(image)
                self.logger.info(f"Image {image} already exists")
            except docker.errors.ImageNotFound:
                self.logger.info(f"Pulling image {image}...")
                self.docker_client.images.pull(image)
            
            await self._update_progress(10, "Creating container...")
            
            # Create container with resource limits
            container = self.docker_client.containers.create(
                image=image,
                command=command,
                network=network,
                volumes=volumes,
                environment=environment,
                mem_limit=mem_limit,
                cpu_quota=cpu_quota,
                cpu_period=self.DEFAULT_CPU_PERIOD,
                detach=True,
                auto_remove=auto_remove,
                read_only=read_only,
                user=user,
                # Security options
                cap_drop=["ALL"],  # Drop all capabilities
                security_opt=["no-new-privileges"],  # Prevent privilege escalation
                network_mode=network if network else "none"  # Isolated network
            )
            
            container_id = container.id
            self._running_containers.add(container_id)
            
            self.logger.info(f"Created container {container_id[:12]} with limits: "
                           f"mem={mem_limit}, cpu={cpu_quota/100000:.2f}, "
                           f"network={network}, user={user}")
            
            await self._update_progress(15, f"Starting container {container_id[:12]}...")
            
            # Start container
            container.start()
            
            # Stream logs or wait with timeout
            if stream_logs:
                result = await self._stream_container_logs(container, timeout)
            else:
                result = await self._wait_container(container, timeout)
            
            # Calculate duration
            duration = (datetime.now() - start_time).total_seconds()
            result["duration"] = duration
            result["container_id"] = container_id
            
            await self._update_progress(100, "Container execution completed")
            
            self.logger.info(f"Container {container_id[:12]} completed in {duration:.2f}s, "
                           f"exit_code={result['exit_code']}")
            
            return result
        
        except asyncio.TimeoutError:
            self.logger.error(f"Container {container_id[:12] if container_id else 'unknown'} "
                            f"timed out after {timeout}s")
            if container_id:
                await self._kill_container_async(container_id)
            raise ContainerTimeoutError(f"Container execution exceeded {timeout}s timeout")
        
        except Exception as e:
            self.logger.error(f"Container execution failed: {e}")
            if container_id:
                await self._kill_container_async(container_id)
            raise ContainerExecutionError(f"Container execution failed: {e}")
        
        finally:
            # Cleanup
            if container_id:
                self._running_containers.discard(container_id)
                if not auto_remove:
                    await self._cleanup_container(container_id)
    
    async def _stream_container_logs(
        self, 
        container, 
        timeout: int
    ) -> Dict[str, Any]:
        """
        Stream container logs in real-time with timeout
        
        Args:
            container: Docker container object
            timeout: Timeout in seconds
            
        Returns:
            dict: Results with stdout, stderr, exit_code
        """
        stdout_lines = []
        stderr_lines = []
        
        async def stream_logs():
            # Attach to container to stream logs
            log_generator = container.attach(
                stdout=True, 
                stderr=True, 
                stream=True, 
                logs=True,
                demux=True  # Separate stdout and stderr
            )
            
            progress = 20
            for stdout_chunk, stderr_chunk in log_generator:
                if stdout_chunk:
                    line = stdout_chunk.decode('utf-8', errors='replace')
                    stdout_lines.append(line)
                    self.logger.debug(f"[stdout] {line.strip()}")
                
                if stderr_chunk:
                    line = stderr_chunk.decode('utf-8', errors='replace')
                    stderr_lines.append(line)
                    self.logger.debug(f"[stderr] {line.strip()}")
                
                # Update progress (20% to 90%)
                progress = min(90, progress + 1)
                await self._update_progress(progress, "Processing...")
            
            # Wait for container to finish
            result = container.wait()
            return result
        
        # Run with timeout
        try:
            result = await asyncio.wait_for(stream_logs(), timeout=timeout)
            
            return {
                "stdout": "".join(stdout_lines),
                "stderr": "".join(stderr_lines),
                "exit_code": result.get("StatusCode", 0)
            }
        except asyncio.TimeoutError:
            raise
    
    async def _wait_container(
        self, 
        container, 
        timeout: int
    ) -> Dict[str, Any]:
        """
        Wait for container to finish without streaming logs
        
        Args:
            container: Docker container object
            timeout: Timeout in seconds
            
        Returns:
            dict: Results with stdout, stderr, exit_code
        """
        async def wait():
            result = container.wait(timeout=timeout)
            logs = container.logs(stdout=True, stderr=False).decode('utf-8', errors='replace')
            errors = container.logs(stdout=False, stderr=True).decode('utf-8', errors='replace')
            
            return {
                "stdout": logs,
                "stderr": errors,
                "exit_code": result.get("StatusCode", 0)
            }
        
        try:
            return await asyncio.wait_for(wait(), timeout=timeout + 5)
        except asyncio.TimeoutError:
            raise
    
    async def _kill_container_async(self, container_id: str, timeout: int = 10):
        """
        Gracefully stop container, force kill if needed
        
        Args:
            container_id: Container ID
            timeout: Timeout for graceful stop
        """
        try:
            if not self.docker_client:
                return
            
            container = self.docker_client.containers.get(container_id)
            
            self.logger.warning(f"Stopping container {container_id[:12]}...")
            
            # Try graceful stop first
            try:
                container.stop(timeout=timeout)
                self.logger.info(f"Container {container_id[:12]} stopped gracefully")
            except Exception:
                # Force kill if stop fails
                self.logger.warning(f"Force killing container {container_id[:12]}...")
                container.kill()
                self.logger.info(f"Container {container_id[:12]} killed")
            
            # Remove container
            try:
                container.remove(force=True)
                self.logger.info(f"Container {container_id[:12]} removed")
            except Exception as e:
                self.logger.error(f"Failed to remove container {container_id[:12]}: {e}")
        
        except docker.errors.NotFound:
            self.logger.warning(f"Container {container_id[:12]} not found")
        except Exception as e:
            self.logger.error(f"Failed to kill container {container_id[:12]}: {e}")
    
    async def _cleanup_container(self, container_id: str):
        """
        Clean up container resources
        
        Args:
            container_id: Container ID
        """
        try:
            container = self.docker_client.containers.get(container_id)
            
            # Remove container if still exists
            try:
                container.remove(force=True)
                self.logger.info(f"Cleaned up container {container_id[:12]}")
            except Exception as e:
                self.logger.error(f"Failed to cleanup container {container_id[:12]}: {e}")
        
        except docker.errors.NotFound:
            pass  # Already removed
        except Exception as e:
            self.logger.error(f"Cleanup failed for {container_id[:12]}: {e}")
    
    async def emergency_stop(self):
        """
        Emergency stop all running containers (Kill Switch)
        """
        self.logger.warning(f"EMERGENCY STOP: Killing {len(self._running_containers)} containers")
        
        tasks = []
        for container_id in list(self._running_containers):
            task = asyncio.create_task(self._kill_container_async(container_id, timeout=2))
            tasks.append(task)
        
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        
        self._running_containers.clear()
        self.logger.info("Emergency stop completed")
    
    def __del__(self):
        """Cleanup on deletion"""
        if hasattr(self, '_running_containers') and self._running_containers:
            self.logger.warning(f"Executor deleted with {len(self._running_containers)} "
                              f"running containers")
