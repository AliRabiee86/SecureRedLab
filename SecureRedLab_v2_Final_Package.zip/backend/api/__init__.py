"""
SecureRedLab API Package
مجموعه API های SecureRedLab

این پکیج شامل تمام endpoints و routers می‌باشد.
"""

__version__ = "2.0.0"
__all__ = []
