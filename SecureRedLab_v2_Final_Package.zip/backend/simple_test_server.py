from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import time

app = FastAPI()

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"status": "online", "message": "SecureRedLab Mock API is running"}

@app.get("/api/v1/dashboard/stats")
async def get_stats():
    return {
        "total_scans": 156,
        "active_attacks": 3,
        "vulnerabilities_found": 42,
        "system_health": 98.5
    }

@app.get("/api/v1/scans")
async def get_scans():
    return [
        {"id": "1", "target": "192.168.1.1", "status": "completed", "time": "2025-01-20 10:00"},
        {"id": "2", "target": "10.0.0.5", "status": "running", "time": "2025-01-20 11:30"}
    ]

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = {"type": "metrics", "cpu": 45, "memory": 62, "timestamp": time.time()}
        await websocket.send_json(data)
        await asyncio.sleep(2)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
