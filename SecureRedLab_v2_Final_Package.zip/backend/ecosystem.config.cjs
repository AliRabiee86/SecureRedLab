// SecureRedLab Backend - PM2 Ecosystem Configuration
// Simple API for Development

module.exports = {
  apps: [
    {
      name: 'secureredlab-backend',
      script: 'venv/bin/python',
      args: 'simple_api.py',
      cwd: __dirname,
      interpreter: 'none',
      env: {
        PYTHONUNBUFFERED: '1',
        PORT: 8000
      },
      watch: ['simple_api.py'],
      watch_delay: 1000,
      ignore_watch: ['node_modules', 'logs', '*.log', '.git'],
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '300M',
      error_file: './logs/backend-error.log',
      out_file: './logs/backend-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
    }
  ]
};
