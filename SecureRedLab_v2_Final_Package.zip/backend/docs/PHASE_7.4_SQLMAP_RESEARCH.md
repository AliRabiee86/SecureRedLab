# 🔬 Phase 7.4: SQLMap Research - Comprehensive Analysis

**Date:** 2026-01-02  
**Status:** Research Phase  
**Target:** SQLMap Docker Integration

---

## 📋 **1. SQLMap Overview**

### **What is SQLMap?**
- **Open-source** penetration testing tool
- **Automatic** SQL injection detection and exploitation
- **Database takeover** capabilities
- **Supports 6+ DBMS**: MySQL, PostgreSQL, MSSQL, Oracle, SQLite, Access
- **Active development** since 2006

### **Key Features**
- **Detection**: Automatic SQL injection vulnerability detection
- **Exploitation**: Full database enumeration and data extraction
- **Techniques**: Boolean, Time-based, Error-based, Union, Stacked queries
- **WAF Bypass**: Tamper scripts for firewall evasion
- **OS Takeover**: Command execution on DB server (advanced)
- **Database Fingerprinting**: Identify DBMS type and version

---

## 🐳 **2. Docker Integration**

### **Official Docker Image**
```bash
docker pull pberba/sqlmap

# Alternative official image
docker run --rm sqlmapproject/sqlmap --help
```

### **Docker Command Structure**
```bash
docker run -it --rm \
  --network isolated_pentest \
  -v /tmp/sqlmap:/root/.sqlmap \
  pberba/sqlmap \
  -u "http://target.com/page?id=1" \
  --batch \
  --output-dir=/root/.sqlmap/output
```

---

## 🎯 **3. SQLMap Command Line Arguments**

### **A. Target Specification**
```bash
-u URL             # Target URL
-r REQUEST_FILE    # Load HTTP request from file
--data="POST_DATA" # POST data
--cookie="COOKIE"  # HTTP Cookie header
--headers="HEADERS" # Extra headers
```

### **B. Detection Techniques**
```bash
--technique=BEUSTQ  # Techniques to use
  # B = Boolean-based blind
  # E = Error-based
  # U = Union query-based
  # S = Stacked queries
  # T = Time-based blind
  # Q = Inline queries
```

### **C. Level & Risk**
```bash
--level=LEVEL  # Level of tests (1-5, default: 1)
  # 1 = Basic tests
  # 2 = Cookie testing
  # 3 = User-Agent/Referer testing
  # 4 = Advanced parameter testing
  # 5 = Aggressive testing (all payloads)

--risk=RISK    # Risk of tests (1-3, default: 1)
  # 1 = Safe (harmless)
  # 2 = Medium (data modification possible)
  # 3 = High (heavy queries, possible DoS)
```

### **D. Database Enumeration**
```bash
--dbs              # Enumerate databases
--tables           # Enumerate tables
--columns          # Enumerate columns
-D DB_NAME         # Specify database
-T TABLE_NAME      # Specify table
-C COLUMN_NAME     # Specify column
--dump             # Dump table data
--dump-all         # Dump entire database
```

### **E. Output & Automation**
```bash
--batch            # Never ask for user input (automation)
--output-dir=PATH  # Output directory
--flush-session    # Clear session cache
--fresh-queries    # Ignore cached results
--answers="quit=Y" # Predefined answers
```

### **F. WAF Bypass**
```bash
--tamper=SCRIPT    # Tamper script(s) for WAF bypass
  # space2comment   # Replace space with /**/
  # between         # Replace '=' with BETWEEN
  # randomcase      # Random case characters
  # charencode      # URL encode characters
  # apostrophemask  # Replace ' with UTF-8
  # base64encode    # Base64 encode payload
```

### **G. Performance**
```bash
--threads=N        # Number of threads (default: 1, max: 10)
--time-sec=N       # Time delay for time-based tests (default: 5)
--timeout=N        # Connection timeout (default: 30)
--retries=N        # Retries on connection timeout (default: 3)
```

---

## 🔐 **4. Injection Techniques Explained**

### **A. Boolean-based Blind (B)**
- Tests with TRUE/FALSE conditions
- Observes response differences
- Example: `?id=1 AND 1=1` vs `?id=1 AND 1=2`
- **Pros:** Works when no error messages
- **Cons:** Slow (one bit per request)

### **B. Error-based (E)**
- Forces database errors
- Extracts data from error messages
- Example: `?id=1' AND (SELECT ... FROM ...)`
- **Pros:** Fast data extraction
- **Cons:** Requires error disclosure

### **C. Union Query-based (U)**
- Uses UNION SQL operator
- Combines results from multiple queries
- Example: `?id=1 UNION SELECT username,password FROM users`
- **Pros:** Very fast
- **Cons:** Requires same column count

### **D. Stacked Queries (S)**
- Executes multiple statements
- Uses `;` to separate queries
- Example: `?id=1; DROP TABLE users--`
- **Pros:** Full SQL control
- **Cons:** Not always supported

### **E. Time-based Blind (T)**
- Uses time delays to infer data
- Example: `?id=1 AND IF(1=1,SLEEP(5),0)`
- **Pros:** Works when no visible output
- **Cons:** Very slow

### **F. Inline Queries (Q)**
- Nested queries in SELECT
- Example: `?id=(SELECT COUNT(*) FROM users)`
- **Pros:** Advanced exploitation
- **Cons:** Limited support

---

## 🛡️ **5. WAF Bypass Techniques**

### **Popular Tamper Scripts**
1. **space2comment.py** - Replace space with `/**/`
2. **between.py** - Replace `>` with `NOT BETWEEN 0 AND #`
3. **randomcase.py** - Random upper/lower case
4. **charencode.py** - URL encode all characters
5. **apostrophemask.py** - Replace `'` with UTF-8 equivalent
6. **base64encode.py** - Base64 encode entire payload
7. **charunicodeencode.py** - Unicode encode characters
8. **equaltolike.py** - Replace `=` with `LIKE`

### **Combining Tamper Scripts**
```bash
--tamper=space2comment,between,randomcase
```

### **Custom Tamper Scripts**
```python
# custom_tamper.py
def tamper(payload):
    # Modify payload here
    return payload.replace(' ', '/**/')
```

---

## 📊 **6. Output Formats**

### **A. JSON Output**
```bash
--output-dir=/output --batch --flush-session
# Creates: /output/target.com/log (JSON structured)
```

### **B. Result Structure**
```json
{
  "target": {
    "url": "http://target.com/page?id=1",
    "injectable": true,
    "parameter": "id",
    "technique": "B",
    "dbms": "MySQL",
    "version": "5.7.30"
  },
  "data": {
    "databases": ["app_db", "test_db"],
    "tables": ["users", "posts"],
    "columns": ["id", "username", "password"],
    "entries": [...]
  }
}
```

---

## 🏗️ **7. Docker Integration Architecture**

```
User Request
    ↓
Celery Task (run_sqlmap_injection)
    ↓
SQLMapExecutor.execute()
    ↓
Phase 1: Validate Target & Parameters (10%)
    ↓
Phase 2: Build SQLMap Command (20%)
    ↓
Phase 3: Start Docker Container (30%)
    ↓
Phase 4: Execute SQLMap Scan (60%)
    ↓
Phase 5: Parse Output (80%)
    ↓
Phase 6: Extract Vulnerabilities (90%)
    ↓
Phase 7: Cleanup (100%)
    ↓
Return Results
```

---

## 🔒 **8. Security Considerations**

### **Blocked Operations**
- ❌ **localhost/127.0.0.1** as target
- ❌ **--os-shell** (OS command execution)
- ❌ **--sql-shell** (interactive SQL shell)
- ❌ **--file-write** (write files to server)
- ❌ **--file-read** (read files from server)

### **Resource Limits**
- **Memory:** 512MB
- **CPU:** 1.0 core
- **Timeout:** 600 seconds (10 minutes)
- **Network:** `isolated_pentest`

### **Container Security**
- **Read-only filesystem:** Yes
- **User:** `nobody` (non-root)
- **Capabilities:** Dropped ALL
- **Security options:** `no-new-privileges`

---

## 📈 **9. Performance Metrics**

### **Typical Scan Times**
- **Boolean-based:** 30-120 seconds
- **Error-based:** 10-30 seconds
- **Union-based:** 5-15 seconds
- **Time-based:** 120-300 seconds (very slow)
- **Full enumeration:** 2-10 minutes

### **Optimization Tips**
- Use `--threads=5` for faster scanning
- Use `--technique=UE` for fastest results
- Use `--level=1 --risk=1` for quick checks
- Use `--batch` for automation (no prompts)

---

## 🎯 **10. Implementation Checklist**

### **Phase 7.4 Requirements**
- [x] Research SQLMap features
- [x] Research Docker integration
- [x] Research command-line arguments
- [x] Research injection techniques
- [x] Research WAF bypass
- [x] Research output parsing
- [ ] Implement SQLMapExecutor class
- [ ] Implement command builder
- [ ] Implement output parser
- [ ] Implement security controls
- [ ] Write 25+ test cases
- [ ] Create documentation
- [ ] Integration with Celery tasks

---

## 📚 **11. Key Findings**

### **Strengths**
✅ Fully automated SQL injection testing  
✅ Supports 6+ database types  
✅ Multiple injection techniques  
✅ WAF bypass capabilities  
✅ JSON output for easy parsing  
✅ Docker support for isolation  

### **Challenges**
⚠️ Can be slow (especially time-based)  
⚠️ May generate large logs  
⚠️ Requires careful parameter tuning  
⚠️ WAF bypass needs testing  
⚠️ Output parsing complexity  

### **Best Practices**
1. Always use `--batch` for automation
2. Start with `--level=1 --risk=1` (safe)
3. Use `--technique=UEB` for speed
4. Set `--timeout=30` to prevent hangs
5. Use `--threads=3` for performance
6. Parse JSON output from logs
7. Implement timeout enforcement (600s max)
8. Block dangerous operations (--os-shell, etc.)

---

## 🚀 **12. Next Steps**

1. **Implement SQLMapExecutor** (~4 hours)
   - Docker container management
   - Command builder
   - Output parser (JSON)
   - Security controls

2. **Testing** (~1 hour)
   - 25+ test cases
   - Command building tests
   - Output parsing tests
   - Security validation tests

3. **Documentation** (~1 hour)
   - PHASE_7.4_COMPLETE.md
   - Usage examples
   - Architecture diagrams

**Total Estimated Time:** ~6 hours

---

**Research Complete!** ✅  
**Ready for Implementation** 🚀

---

**Author:** SecureRedLab Team  
**Date:** 2026-01-02  
**Phase:** 7.4 Research  
**Status:** ✅ COMPLETE
