# 🔬 BaseExecutor Deep Research - Phase 7.1

**تاریخ:** 2025-12-29  
**وضعیت:** Research Complete - Ready for Implementation

---

## 📚 **خلاصه تحقیقات**

### **1. Docker SDK Lifecycle Management**

#### **Key Findings:**
- ✅ **Container Creation:** `client.containers.create()` برای control کامل
- ✅ **Container Start:** `container.start()` برای جداسازی create و start
- ✅ **Container Wait:** `container.wait()` برای blocking wait یا `container.reload()` برای polling
- ✅ **Async Wait:** استفاده از `asyncio.sleep()` + `container.reload()` برای non-blocking
- ✅ **Cleanup:** `container.remove(force=True)` برای cleanup کامل

#### **Best Practices:**
```python
# Method 1: Create + Start (Recommended)
container = client.containers.create(image="...", command="...", detach=True)
container.start()
# ... wait and monitor ...
container.remove(force=True)

# Method 2: Run (Simple but less control)
container = client.containers.run(image="...", command="...", detach=True)
```

---

### **2. Timeout & Kill Switch**

#### **Key Findings:**
- ✅ **Graceful Stop:** `container.stop(timeout=10)` → SIGTERM wait 10s → SIGKILL
- ✅ **Force Kill:** `container.kill()` → SIGKILL مستقیم
- ✅ **asyncio Timeout:** `asyncio.wait_for(coro, timeout=300)` → TimeoutError → kill

#### **Shutdown Flow:**
```
1. SIGTERM (graceful) → wait 10s
2. SIGKILL (force) → terminate immediately
```

#### **Implementation Pattern:**
```python
try:
    await asyncio.wait_for(
        self._wait_for_container(container),
        timeout=300
    )
except asyncio.TimeoutError:
    self.logger.warning("Timeout reached, killing container")
    container.kill()  # SIGKILL
    raise TimeoutError("Container execution timeout")
```

---

### **3. Real-time Log Streaming**

#### **Key Findings:**
- ✅ **Stream Mode:** `container.logs(stream=True, follow=True)`
- ✅ **Demux:** `demux=True` برای جداسازی stdout/stderr
- ✅ **Generator:** Returns generator برای streaming
- ✅ **Attach:** `container.attach(stream=True, logs=True)` برای real-time

#### **Streaming Patterns:**

**Pattern 1: Simple Logs (After completion)**
```python
stdout = container.logs(stdout=True, stderr=False).decode('utf-8')
stderr = container.logs(stdout=False, stderr=True).decode('utf-8')
```

**Pattern 2: Streaming Logs (Real-time)**
```python
for line in container.logs(stream=True, follow=True):
    print(line.decode('utf-8'), end='')
```

**Pattern 3: Demuxed Streaming (stdout + stderr separated)**
```python
for stdout, stderr in container.logs(stream=True, demux=True):
    if stdout:
        print(f"STDOUT: {stdout.decode()}")
    if stderr:
        print(f"STDERR: {stderr.decode()}")
```

---

### **4. Resource Limits**

#### **Key Findings:**
- ✅ **Memory Limit:** `mem_limit="512m"` یا `mem_limit=536870912` (bytes)
- ✅ **CPU Limit:** `cpu_quota=100000` (1 core) + `cpu_period=100000`
- ✅ **CPU Shares:** `cpu_shares=1024` برای relative weight
- ✅ **PID Limit:** `pids_limit=100` برای محدودیت تعداد processes

#### **Cgroups Configuration:**
```python
container = client.containers.create(
    image="...",
    command="...",
    # Memory limits
    mem_limit="512m",           # 512MB RAM
    mem_reservation="256m",     # Soft limit
    memswap_limit="512m",       # RAM + Swap limit
    
    # CPU limits
    cpu_quota=100000,           # 1 CPU core
    cpu_period=100000,          # 100ms period
    cpu_shares=1024,            # Relative weight
    
    # Process limits
    pids_limit=100,             # Max 100 processes
    
    # Disk I/O
    device_read_bps=[{"Path": "/dev/sda", "Rate": 10485760}],  # 10MB/s
)
```

---

### **5. Error Handling & Retry**

#### **Key Findings:**
- ✅ **Docker Exceptions:** `docker.errors.APIError`, `docker.errors.ContainerError`, `docker.errors.ImageNotFound`
- ✅ **Retry Strategy:** Exponential backoff با max retries
- ✅ **Cleanup on Error:** همیشه `container.remove(force=True)` در finally block

#### **Exception Hierarchy:**
```
docker.errors.DockerException
├── docker.errors.APIError           # API call failed
├── docker.errors.ContainerError     # Container exited with non-zero
├── docker.errors.ImageNotFound      # Image not found
├── docker.errors.NotFound           # Container/image not found
└── docker.errors.BuildError         # Build failed
```

#### **Retry Pattern:**
```python
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10)
)
async def _run_with_retry(self, ...):
    # Container execution logic
    pass
```

---

### **6. Health Check & Monitoring**

#### **Key Findings:**
- ✅ **Container Status:** `container.status` → `created`, `running`, `exited`, `dead`
- ✅ **Health Status:** `container.attrs['State']['Health']['Status']` → `starting`, `healthy`, `unhealthy`
- ✅ **Reload:** `container.reload()` برای refresh container state
- ✅ **Stats:** `container.stats(stream=False)` برای resource usage

#### **Status Monitoring:**
```python
async def _monitor_container(self, container):
    """Monitor container status and health"""
    while True:
        container.reload()
        
        status = container.status
        if status == 'exited':
            break
        
        # Check health (if healthcheck defined)
        health = container.attrs.get('State', {}).get('Health', {})
        if health and health.get('Status') == 'unhealthy':
            self.logger.warning("Container unhealthy")
        
        await asyncio.sleep(1)
```

---

### **7. Network Isolation**

#### **Key Findings:**
- ✅ **Bridge Network:** Default bridge network
- ✅ **Custom Network:** `client.networks.create(name="isolated_pentest", driver="bridge")`
- ✅ **Internal Network:** `internal=True` برای no external access
- ✅ **Network Attach:** `network="isolated_pentest"` در container.create()

#### **Network Configuration:**
```python
# Create isolated network
network = client.networks.create(
    name="isolated_pentest",
    driver="bridge",
    internal=True,  # No external access
    ipam=docker.types.IPAMConfig(
        pool_configs=[
            docker.types.IPAMPool(
                subnet="172.25.0.0/16",
                gateway="172.25.0.1"
            )
        ]
    )
)

# Use network
container = client.containers.create(
    image="...",
    network="isolated_pentest"
)
```

---

### **8. Security Best Practices**

#### **Key Findings:**
- ✅ **Read-only FS:** `read_only=True`
- ✅ **No Privileged:** `privileged=False` (default)
- ✅ **Drop Capabilities:** `cap_drop=["ALL"]`
- ✅ **Security Options:** `security_opt=["no-new-privileges"]`
- ✅ **User:** `user="nobody"` برای non-root

#### **Security Configuration:**
```python
container = client.containers.create(
    image="...",
    command="...",
    
    # File system
    read_only=True,                          # Read-only root FS
    tmpfs={'/tmp': 'size=100m'},            # Writable /tmp
    
    # Privileges
    privileged=False,                        # No privileged mode
    cap_drop=["ALL"],                        # Drop all capabilities
    cap_add=["NET_BIND_SERVICE"],          # Add only needed caps
    
    # Security options
    security_opt=[
        "no-new-privileges",                 # Prevent privilege escalation
        "apparmor=docker-default"            # AppArmor profile
    ],
    
    # User
    user="nobody",                           # Run as non-root
)
```

---

## 🎯 **Architecture Design**

### **Enhanced BaseExecutor Features:**

```
BaseExecutor (Abstract)
├── __init__()                           # Docker client init
├── execute(**kwargs) [ABSTRACT]         # Tool-specific execution
├── parse_output(raw) [ABSTRACT]        # Tool-specific parsing
├── _run_container()                     # Core container execution
│   ├── _create_container()             # Container creation
│   ├── _start_container()              # Container start
│   ├── _wait_for_container()           # Async wait
│   ├── _stream_logs()                  # Real-time log streaming
│   └── _cleanup_container()            # Graceful cleanup
├── _run_with_timeout()                 # Timeout wrapper
├── _monitor_container()                # Health monitoring
├── _kill_container()                   # Force kill
├── _get_container_stats()              # Resource usage
└── cleanup_all()                       # Cleanup all containers
```

---

## 💎 **Implementation Checklist**

### **Phase 7.1: BaseExecutor Enhancement**

- [ ] **Container Lifecycle**
  - [ ] `_create_container()` - Create with full config
  - [ ] `_start_container()` - Start and attach
  - [ ] `_wait_for_container()` - Async wait
  - [ ] `_cleanup_container()` - Graceful cleanup

- [ ] **Timeout & Kill**
  - [ ] `_run_with_timeout()` - asyncio.wait_for wrapper
  - [ ] `_kill_container()` - SIGKILL implementation
  - [ ] `_stop_container()` - SIGTERM → SIGKILL

- [ ] **Log Streaming**
  - [ ] `_stream_logs()` - Generator for real-time logs
  - [ ] `_get_logs()` - Get all logs after completion
  - [ ] `_publish_log_update()` - Send to Redis Pub/Sub

- [ ] **Resource Management**
  - [ ] Memory limits (512MB)
  - [ ] CPU limits (1 core)
  - [ ] PID limits (100)
  - [ ] Disk I/O limits

- [ ] **Error Handling**
  - [ ] Try/except for all Docker operations
  - [ ] Retry logic with tenacity
  - [ ] Cleanup on all error paths
  - [ ] Detailed error logging

- [ ] **Security**
  - [ ] Read-only file system
  - [ ] Drop all capabilities
  - [ ] Non-root user
  - [ ] Network isolation
  - [ ] No privileged mode

- [ ] **Monitoring**
  - [ ] Container status tracking
  - [ ] Health check monitoring
  - [ ] Resource usage stats
  - [ ] Real-time progress updates

---

## 📊 **Dependencies**

```python
# requirements.txt additions
docker==7.0.0              # Docker SDK
tenacity==8.2.3            # Retry logic
```

---

## 🚀 **Next Steps**

1. ✅ Research Complete
2. ⏳ Implement enhanced BaseExecutor
3. ⏳ Write unit tests
4. ⏳ Integration with Redis Pub/Sub
5. ⏳ Documentation

---

**Research Status:** ✅ COMPLETE  
**Ready for Implementation:** ✅ YES  
**Estimated Time:** 4-6 hours
