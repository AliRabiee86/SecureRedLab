# Phase 7.2: NmapExecutor Implementation 🚀

**Status**: In Progress  
**Priority**: HIGH 🔴  
**Duration**: ~6 hours (estimated)  
**Date**: December 30, 2025

---

## 📋 Overview

Phase 7.2 پیاده‌سازی کامل **NmapExecutor** برای اجرای Nmap scans در Docker container با XML parsing و real-time progress updates.

---

## 🎯 Objectives

1. ✅ **Docker Integration**: اجرای Nmap در container ایزوله
2. ✅ **XML Output Parsing**: تجزیه خروجی XML با `python-nmap`
3. ✅ **Multiple Scan Types**: پشتیبانی از انواع scan (SYN, TCP, UDP, etc.)
4. ✅ **Service Detection**: شناسایی services و versions
5. ✅ **OS Fingerprinting**: تشخیص سیستم‌عامل
6. ✅ **NSE Scripts**: اجرای scriptهای vulnerability
7. ✅ **Real-time Progress**: گزارش progress به Frontend
8. ✅ **Error Handling**: مدیریت خطاها و timeout

---

## 🏗️ Architecture

### **NmapExecutor Class**

```python
class NmapExecutor(BaseExecutor):
    """
    Nmap scanner executor with Docker isolation
    
    Features:
    - Multiple scan types (SYN, TCP, UDP, etc.)
    - Service version detection (-sV)
    - OS fingerprinting (-O)
    - NSE scripts (--script)
    - XML output parsing
    - Real-time progress updates
    """
    
    DOCKER_IMAGE = "instrumentisto/nmap:latest"
    DEFAULT_PORTS = "1-1000"
    DEFAULT_SCAN_TYPE = "syn"
```

### **Scan Types Support**

| Scan Type | Nmap Flag | Description |
|-----------|-----------|-------------|
| **syn** | `-sS` | SYN (Stealth) scan - Most popular |
| **tcp** | `-sT` | TCP Connect scan |
| **udp** | `-sU` | UDP scan |
| **fin** | `-sF` | FIN scan |
| **null** | `-sN` | Null scan |
| **xmas** | `-sX` | Xmas scan |
| **ack** | `-sA` | ACK scan |
| **window** | `-sW` | Window scan |
| **version** | `-sV` | Service version detection |
| **os** | `-O` | OS fingerprinting |

---

## 🔍 Implementation Details

### **1. XML Output Format**

```xml
<?xml version="1.0"?>
<nmaprun scanner="nmap" args="nmap -sS -p 1-1000 192.168.1.1 -oX -">
  <host>
    <status state="up"/>
    <address addr="192.168.1.1" addrtype="ipv4"/>
    <ports>
      <port protocol="tcp" portid="22">
        <state state="open"/>
        <service name="ssh" product="OpenSSH" version="8.2p1"/>
      </port>
      <port protocol="tcp" portid="80">
        <state state="open"/>
        <service name="http" product="nginx" version="1.18.0"/>
      </port>
    </ports>
    <os>
      <osmatch name="Linux 5.4" accuracy="95"/>
    </os>
  </host>
</nmaprun>
```

### **2. Python-nmap Integration**

```python
import nmap

# Initialize scanner
nm = nmap.PortScanner()

# Parse XML output
nm.analyse_nmap_xml_scan(xml_string)

# Access results
for host in nm.all_hosts():
    print(f"Host: {host}")
    for proto in nm[host].all_protocols():
        ports = nm[host][proto].keys()
        for port in ports:
            service = nm[host][proto][port]
            print(f"  Port {port}: {service['name']} {service.get('version', '')}")
```

---

## 📦 Docker Command Examples

### **Basic Port Scan**
```bash
docker run --rm --network isolated_pentest \
  instrumentisto/nmap:latest \
  nmap -sS -p 1-1000 192.168.1.1 -oX - --stats-every 5s
```

### **Service Version Detection**
```bash
docker run --rm --network isolated_pentest \
  instrumentisto/nmap:latest \
  nmap -sV -p 22,80,443 192.168.1.1 -oX -
```

### **OS Fingerprinting**
```bash
docker run --rm --network isolated_pentest --privileged \
  instrumentisto/nmap:latest \
  nmap -O 192.168.1.1 -oX -
```

### **NSE Scripts**
```bash
docker run --rm --network isolated_pentest \
  instrumentisto/nmap:latest \
  nmap --script vuln -p 80,443 192.168.1.1 -oX -
```

---

## 🔒 Security Considerations

### **1. Network Isolation**
- ✅ Run in `isolated_pentest` network
- ✅ No access to host network
- ✅ No internet access (unless target is external)

### **2. Resource Limits**
- ✅ Memory: 512MB
- ✅ CPU: 1.0 core
- ✅ Timeout: 300s default (configurable)

### **3. Privilege Requirements**
- ✅ SYN scan requires `--privileged` flag
- ✅ OS detection requires `--privileged` flag
- ⚠️ TCP Connect scan doesn't require privileges

### **4. Target Validation**
- ✅ Validate IP/domain format
- ✅ Block RFC1918 private ranges (optional)
- ✅ Block localhost/loopback
- ✅ Rate limiting

---

## 📊 Progress Tracking

### **Progress Stages:**

```python
PROGRESS_STAGES = {
    "initializing": 5,      # Pulling image, validating target
    "preparing": 10,        # Building command
    "scanning": 15-90,      # Active scanning (varies)
    "parsing": 95,          # XML parsing
    "completed": 100        # Done
}
```

### **Real-time Updates:**

```python
# Nmap --stats-every flag
# Output: ~1.2% done; ETC: 14:15 (0:04:32 remaining)
# Parse and update progress:
await self._update_progress(progress_percent, f"Scanning port {current_port}...")
```

---

## 🧪 Testing Strategy

### **Test Cases:**

1. ✅ **Basic SYN Scan**: Simple port scan on DVWA
2. ✅ **Service Version Detection**: Identify service versions
3. ✅ **OS Fingerprinting**: Detect OS (with --privileged)
4. ✅ **Multiple Targets**: Scan multiple IPs
5. ✅ **Timeout Handling**: Scan with timeout
6. ✅ **Invalid Target**: Error handling for invalid IPs
7. ✅ **Port Range Validation**: Valid/invalid port ranges
8. ✅ **NSE Scripts**: Run vulnerability scripts
9. ✅ **UDP Scan**: UDP port scanning
10. ✅ **XML Parsing**: Parse various XML outputs

---

## 📈 Expected Results Format

```python
{
    "scan_id": "uuid-here",
    "target": "192.168.1.1",
    "scan_type": "syn",
    "ports_scanned": "1-1000",
    "scan_time": 45.2,
    "hosts_up": 1,
    "hosts": [
        {
            "ip": "192.168.1.1",
            "hostname": "target.local",
            "state": "up",
            "open_ports": [
                {
                    "port": 22,
                    "protocol": "tcp",
                    "state": "open",
                    "service": {
                        "name": "ssh",
                        "product": "OpenSSH",
                        "version": "8.2p1",
                        "cpe": "cpe:/a:openbsd:openssh:8.2p1"
                    }
                },
                {
                    "port": 80,
                    "protocol": "tcp",
                    "state": "open",
                    "service": {
                        "name": "http",
                        "product": "nginx",
                        "version": "1.18.0"
                    }
                }
            ],
            "os_detection": {
                "name": "Linux 5.4",
                "accuracy": 95,
                "cpe": "cpe:/o:linux:linux_kernel:5.4"
            },
            "vulnerabilities": []  # From NSE scripts
        }
    ],
    "statistics": {
        "total_ports_scanned": 1000,
        "open_ports": 2,
        "closed_ports": 998,
        "filtered_ports": 0
    },
    "status": "completed"
}
```

---

## 🚀 Implementation Plan

### **Step 1: Install Dependencies** (~15 min)

```bash
# Add to requirements.txt
python-nmap==0.7.1
```

### **Step 2: Create NmapExecutor** (~2 hours)

- Implement `execute()` method
- Build Nmap command from parameters
- Run Docker container
- Stream output and parse progress

### **Step 3: XML Parsing** (~1.5 hours)

- Parse XML output with python-nmap
- Extract hosts, ports, services
- Extract OS detection results
- Extract NSE script results

### **Step 4: Progress Updates** (~1 hour)

- Parse Nmap stats output
- Calculate progress percentage
- Update via callback

### **Step 5: Error Handling** (~1 hour)

- Validate inputs
- Handle Docker errors
- Handle XML parsing errors
- Timeout handling

### **Step 6: Testing** (~30 min)

- Write unit tests
- Integration tests with DVWA
- Performance benchmarks

---

## 📝 Next Steps

1. ✅ Install python-nmap library
2. ✅ Create NmapExecutor class
3. ✅ Implement execute() method
4. ✅ Implement parse_output() method
5. ✅ Add progress tracking
6. ✅ Write tests
7. ✅ Update Celery tasks
8. ✅ Documentation

---

**Ready to start implementation!** 🎯
