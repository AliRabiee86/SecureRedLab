# 🔬 Phase 7.5: Nuclei Research - Comprehensive Analysis

**Date:** 2026-01-03  
**Status:** Research Phase  
**Target:** Nuclei Docker Integration

---

## 📋 **1. Nuclei Overview**

### **What is Nuclei?**
- **Open-source** vulnerability scanner by ProjectDiscovery
- **Template-based** scanning using YAML templates
- **Fast & configurable** with massive extensibility
- **Community-driven** with 5000+ templates
- **Multi-protocol** support: HTTP, DNS, TCP, SSL, File

### **Key Features**
- **YAML Templates**: Simple, customizable vulnerability detection
- **Zero False Positives**: Precise template-based scanning
- **Multi-Protocol**: HTTP, DNS, TCP, SSL, File protocols
- **Fast Scanning**: Concurrent execution with rate limiting
- **CVE Coverage**: 1000+ CVE templates (updated monthly)
- **Workflow Support**: Chain multiple templates
- **JSON Output**: Structured results for automation

---

## 🐳 **2. Docker Integration**

### **Official Docker Image**
```bash
docker pull projectdiscovery/nuclei:latest

# Run Nuclei
docker run projectdiscovery/nuclei:latest -u https://example.com
```

### **Docker Command Structure**
```bash
docker run --rm \
  --network isolated_pentest \
  -v /tmp/nuclei:/root/.nuclei \
  projectdiscovery/nuclei:latest \
  -u https://target.com \
  -severity critical,high \
  -json \
  -o /root/.nuclei/output.json
```

### **Template Updates**
```bash
# Update templates before scanning
docker run projectdiscovery/nuclei:latest -update-templates

# Templates stored in: /root/nuclei-templates/
```

---

## 🎯 **3. Nuclei Command Line Arguments**

### **A. Target Specification**
```bash
-u URL                 # Single target URL
-l FILE                # List of targets from file
-target URL            # Alternative to -u
```

### **B. Template Selection**
```bash
-t TEMPLATE            # Specific template or directory
-tags TAG              # Filter by tags (e.g., cve,xss,sqli)
-severity LEVEL        # Filter by severity (critical,high,medium,low,info)
-author AUTHOR         # Filter by template author
-include-tags TAG      # Include specific tags
-exclude-tags TAG      # Exclude specific tags
```

### **C. Filtering & Output**
```bash
-json                  # JSON output format
-jsonl                 # JSON Lines format
-o FILE                # Output file path
-silent                # Display only results
-verbose               # Verbose output
-debug                 # Debug mode
```

### **D. Performance & Rate Limiting**
```bash
-c NUM                 # Concurrent requests (default: 25)
-rate-limit NUM        # Rate limit per second
-timeout NUM           # Request timeout (default: 5s)
-retries NUM           # Retry failed requests
-bulk-size NUM         # Bulk size for parallel processing
```

### **E. Advanced Options**
```bash
-update-templates      # Update template database
-update                # Update Nuclei binary
-validate              # Validate templates
-list-templates        # List all templates
-stats                 # Display scan statistics
```

---

## 📊 **4. Template System**

### **Template Structure (YAML)**
```yaml
id: cve-2021-12345

info:
  name: Example CVE Vulnerability
  author: researcher
  severity: critical
  description: Description of vulnerability
  tags: cve,rce
  
requests:
  - method: GET
    path:
      - "{{BaseURL}}/vulnerable-endpoint"
    
    matchers:
      - type: word
        words:
          - "vulnerable pattern"
        part: body
```

### **Severity Levels**
1. **critical** - Immediate exploitation risk
2. **high** - Serious security issues
3. **medium** - Moderate vulnerabilities
4. **low** - Minor security concerns
5. **info** - Information disclosure

### **Common Tags**
- **cve** - CVE vulnerabilities
- **xss** - Cross-Site Scripting
- **sqli** - SQL Injection
- **rce** - Remote Code Execution
- **lfi** - Local File Inclusion
- **ssrf** - Server-Side Request Forgery
- **xxe** - XML External Entity
- **exposure** - Sensitive data exposure
- **config** - Misconfiguration
- **panel** - Admin panel detection

---

## 🔍 **5. JSON Output Format**

### **Output Structure**
```json
{
  "template-id": "cve-2021-12345",
  "info": {
    "name": "Example CVE Vulnerability",
    "author": "researcher",
    "severity": "critical",
    "tags": ["cve", "rce"]
  },
  "type": "http",
  "host": "https://example.com",
  "matched-at": "https://example.com/vulnerable",
  "extracted-results": ["data1", "data2"],
  "curl-command": "curl -X GET https://example.com/vulnerable",
  "matcher-name": "vulnerability-found",
  "timestamp": "2026-01-03T19:00:00Z"
}
```

### **Parsing Strategy**
- Each line is a separate JSON object (JSONL format)
- Parse line-by-line for real-time processing
- Group by severity for reporting
- Extract template-id, severity, matched-at

---

## 🏗️ **6. Docker Integration Architecture**

```
User Request
    ↓
Celery Task (run_nuclei_scan)
    ↓
NucleiExecutor.execute()
    ↓
Phase 1: Validate Target (10%)
    ├─ Target URL validation
    └─ Template/tag validation
    ↓
Phase 2: Build Command (20%)
    ├─ Target specification
    ├─ Template selection (-t, -tags, -severity)
    ├─ Output format (-json -o)
    └─ Performance options (-c, -rate-limit)
    ↓
Phase 3: Update Templates (30%)
    └─ Ensure latest templates (-update-templates)
    ↓
Phase 4: Execute Scan (70%)
    └─ Docker container with Nuclei
    ↓
Phase 5: Parse Results (90%)
    ├─ Parse JSON output
    ├─ Group by severity
    └─ Extract vulnerabilities
    ↓
Phase 6: Complete (100%)
    └─ Return structured results
```

---

## 🔒 **7. Security Considerations**

### **Blocked Operations**
- ❌ **localhost/127.0.0.1** as target
- ❌ **Internal IPs** (10.0.0.0/8, 192.168.0.0/16, 172.16.0.0/12)
- ❌ **Aggressive scanning** without rate limiting

### **Resource Limits**
- **Memory:** 512MB
- **CPU:** 1.0 core
- **Timeout:** 300 seconds (5 minutes)
- **Network:** `isolated_pentest`
- **Rate Limit:** 50 requests/second (max)

### **Container Security**
- **Read-only filesystem:** Yes
- **User:** `nobody` (non-root)
- **Capabilities:** Dropped ALL
- **Security options:** `no-new-privileges`

---

## 📈 **8. Performance Metrics**

### **Typical Scan Times**
- **Single URL, All Templates:** 30-120 seconds
- **Single URL, CVE Only:** 10-30 seconds
- **Single URL, Critical Severity:** 5-15 seconds
- **100 URLs, Selected Templates:** 2-10 minutes

### **Optimization Tips**
- Use `-severity critical,high` for fast scans
- Use `-tags cve` for CVE-focused scanning
- Use `-c 50` for faster concurrent requests
- Use `-rate-limit 50` to prevent rate limiting
- Use `-timeout 5` for quick timeouts

---

## 🎯 **9. Template Categories**

### **Vulnerability Detection**
- **CVE Templates** (1000+): Known vulnerabilities
- **Exposed Panels**: Admin/login pages
- **Misconfigurations**: Security misconfigs
- **Default Credentials**: Default passwords
- **Sensitive Data**: Data exposure

### **Technology Detection**
- **CMS Detection**: WordPress, Drupal, Joomla
- **Framework Detection**: Laravel, Django, Express
- **Server Detection**: Apache, Nginx, IIS
- **Service Detection**: APIs, databases

### **Security Headers**
- **Missing Headers**: CSP, HSTS, X-Frame
- **Header Misconfig**: Weak policies
- **Cookie Security**: Secure, HttpOnly flags

---

## 🛠️ **10. Implementation Checklist**

### **Phase 7.5 Requirements**
- [x] Research Nuclei features
- [x] Research Docker integration
- [x] Research template system
- [x] Research JSON output
- [x] Research command-line arguments
- [x] Research performance optimization
- [ ] Implement NucleiExecutor class
- [ ] Implement command builder
- [ ] Implement JSON parser
- [ ] Implement security controls
- [ ] Write 20+ test cases
- [ ] Create documentation
- [ ] Integration with Celery tasks

---

## 📚 **11. Key Findings**

### **Strengths**
✅ 5000+ community templates  
✅ Fast template-based scanning  
✅ Zero false positives  
✅ JSON output for easy parsing  
✅ Multi-protocol support  
✅ Docker support for isolation  
✅ Monthly template updates  

### **Challenges**
⚠️ Template updates required before scan  
⚠️ Large template database (~500MB)  
⚠️ JSON Lines format (not standard JSON)  
⚠️ Rate limiting needed for large scans  
⚠️ No built-in WAF bypass (unlike SQLMap)  

### **Best Practices**
1. Always update templates before scanning
2. Use `-severity critical,high` for important scans
3. Use `-tags cve` for CVE-focused scanning
4. Set `-rate-limit 50` to prevent blocking
5. Use `-c 25` for balanced performance
6. Parse JSON output line-by-line (JSONL)
7. Implement timeout enforcement (300s max)
8. Block internal/localhost targets

---

## 🚀 **12. Next Steps**

1. **Implement NucleiExecutor** (~3 hours)
   - Docker container management
   - Template update mechanism
   - Command builder
   - JSON parser (JSONL format)
   - Security controls

2. **Testing** (~0.5 hour)
   - 20+ test cases
   - Command building tests
   - JSON parsing tests
   - Security validation tests

3. **Documentation** (~0.5 hour)
   - PHASE_7.5_COMPLETE.md
   - Usage examples
   - Architecture diagrams

**Total Estimated Time:** ~4 hours

---

**Research Complete!** ✅  
**Ready for Implementation** 🚀

---

**Author:** SecureRedLab Team  
**Date:** 2026-01-03  
**Phase:** 7.5 Research  
**Status:** ✅ COMPLETE
