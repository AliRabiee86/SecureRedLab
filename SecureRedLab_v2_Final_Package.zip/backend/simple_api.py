"""
SecureRedLab - Simple Backend API for Development
این فایل یک API ساده برای توسعه Frontend است.
برای production از backend/main.py استفاده کنید.
"""

from fastapi import FastAPI, HTTPException, Depends, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import uvicorn
import asyncio
import json

# ==============================================================================
# Configuration
# ==============================================================================

app = FastAPI(
    title="SecureRedLab API",
    description="AI-Powered Penetration Testing Platform",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "https://*.sandbox.novita.ai"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==============================================================================
# Models
# ==============================================================================

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class LoginResponse(BaseModel):
    token: str
    user: Dict[str, Any]

class User(BaseModel):
    id: str
    email: str
    username: str
    full_name: str
    role: str

class Scan(BaseModel):
    id: str
    name: str
    target: str
    type: str
    tool: str
    status: str
    progress: int
    created_at: str
    updated_at: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None

class Attack(BaseModel):
    id: str
    name: str
    target: str
    type: str
    tool: str
    status: str
    severity: str
    progress: int
    created_at: str
    updated_at: str

class Vulnerability(BaseModel):
    id: str
    scan_id: str
    name: str
    severity: str
    cvss_score: Optional[float] = None
    cve_id: Optional[str] = None
    description: str
    status: str
    discovered_at: str
    created_at: str
    updated_at: str

# ==============================================================================
# Mock Data
# ==============================================================================

MOCK_USER = {
    "id": "user-001",
    "email": "admin@secureredlab.local",
    "username": "admin",
    "full_name": "Security Admin",
    "role": "admin"
}

MOCK_SCANS: List[Dict] = [
    {
        "id": "scan-001",
        "name": "Production Network Scan",
        "target": "192.168.1.0/24",
        "type": "network",
        "tool": "nmap",
        "status": "completed",
        "progress": 100,
        "started_at": "2024-01-20T10:00:00Z",
        "completed_at": "2024-01-20T10:15:00Z",
        "created_at": "2024-01-20T09:55:00Z",
        "updated_at": "2024-01-20T10:15:00Z"
    },
    {
        "id": "scan-002",
        "name": "Web Application Scan",
        "target": "https://example.com",
        "type": "web",
        "tool": "nuclei",
        "status": "running",
        "progress": 65,
        "started_at": "2024-01-20T11:00:00Z",
        "created_at": "2024-01-20T10:55:00Z",
        "updated_at": "2024-01-20T11:30:00Z"
    }
]

MOCK_ATTACKS: List[Dict] = [
    {
        "id": "attack-001",
        "name": "SQL Injection Test",
        "target": "https://example.com/login",
        "type": "sqli",
        "tool": "sqlmap",
        "status": "completed",
        "severity": "critical",
        "progress": 100,
        "started_at": "2024-01-20T09:00:00Z",
        "completed_at": "2024-01-20T09:45:00Z",
        "created_at": "2024-01-20T08:55:00Z",
        "updated_at": "2024-01-20T09:45:00Z"
    }
]

MOCK_VULNERABILITIES: List[Dict] = [
    {
        "id": "vuln-001",
        "scan_id": "scan-001",
        "name": "SQL Injection in Login Form",
        "description": "The login form is vulnerable to SQL injection attacks.",
        "severity": "critical",
        "cvss_score": 9.8,
        "cve_id": "CVE-2024-0001",
        "status": "open",
        "discovered_at": "2024-01-20T10:15:00Z",
        "created_at": "2024-01-20T10:15:00Z",
        "updated_at": "2024-01-20T10:15:00Z"
    }
]

# ==============================================================================
# WebSocket Connection Manager
# ==============================================================================

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

# ==============================================================================
# Health Check
# ==============================================================================

@app.get("/")
async def root():
    return {
        "message": "SecureRedLab API - Development Mode",
        "version": "1.0.0",
        "status": "running",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    }

# ==============================================================================
# Authentication Endpoints
# ==============================================================================

@app.post("/auth/login", response_model=LoginResponse)
async def login(credentials: LoginRequest):
    # Simple mock authentication
    if credentials.email == "admin@secureredlab.local" and credentials.password == "admin":
        return {
            "token": "mock_jwt_token_12345",
            "user": MOCK_USER
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.post("/auth/logout")
async def logout():
    return {"message": "Logged out successfully"}

@app.get("/auth/me")
async def get_current_user():
    return MOCK_USER

# ==============================================================================
# Scans Endpoints
# ==============================================================================

@app.get("/scans")
async def get_scans() -> List[Dict]:
    return MOCK_SCANS

@app.get("/scans/{scan_id}")
async def get_scan(scan_id: str):
    scan = next((s for s in MOCK_SCANS if s["id"] == scan_id), None)
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return scan

@app.post("/scans")
async def create_scan(scan_data: Dict[str, Any]):
    new_scan = {
        "id": f"scan-{len(MOCK_SCANS) + 1:03d}",
        "name": scan_data.get("name", "New Scan"),
        "target": scan_data.get("target"),
        "type": scan_data.get("type", "network"),
        "tool": scan_data.get("tool", "nmap"),
        "status": "pending",
        "progress": 0,
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat()
    }
    MOCK_SCANS.append(new_scan)
    return new_scan

# ==============================================================================
# Attacks Endpoints
# ==============================================================================

@app.get("/attacks")
async def get_attacks() -> List[Dict]:
    return MOCK_ATTACKS

@app.get("/attacks/{attack_id}")
async def get_attack(attack_id: str):
    attack = next((a for a in MOCK_ATTACKS if a["id"] == attack_id), None)
    if not attack:
        raise HTTPException(status_code=404, detail="Attack not found")
    return attack

# ==============================================================================
# Vulnerabilities Endpoints
# ==============================================================================

@app.get("/vulnerabilities")
async def get_vulnerabilities() -> List[Dict]:
    return MOCK_VULNERABILITIES

@app.get("/scans/{scan_id}/vulnerabilities")
async def get_scan_vulnerabilities(scan_id: str):
    vulns = [v for v in MOCK_VULNERABILITIES if v["scan_id"] == scan_id]
    return vulns

# ==============================================================================
# Dashboard Endpoints
# ==============================================================================

@app.get("/dashboard/stats")
async def get_dashboard_stats():
    return {
        "total_scans": len(MOCK_SCANS),
        "active_scans": sum(1 for s in MOCK_SCANS if s["status"] == "running"),
        "total_attacks": len(MOCK_ATTACKS),
        "active_attacks": sum(1 for a in MOCK_ATTACKS if a["status"] == "running"),
        "total_vulnerabilities": len(MOCK_VULNERABILITIES),
        "critical_vulnerabilities": sum(1 for v in MOCK_VULNERABILITIES if v["severity"] == "critical"),
        "recent_scans": MOCK_SCANS[:5],
        "recent_attacks": MOCK_ATTACKS[:5],
        "severity_distribution": {
            "critical": sum(1 for v in MOCK_VULNERABILITIES if v["severity"] == "critical"),
            "high": sum(1 for v in MOCK_VULNERABILITIES if v["severity"] == "high"),
            "medium": sum(1 for v in MOCK_VULNERABILITIES if v["severity"] == "medium"),
            "low": sum(1 for v in MOCK_VULNERABILITIES if v["severity"] == "low"),
            "info": sum(1 for v in MOCK_VULNERABILITIES if v["severity"] == "info")
        },
        "scan_history": []
    }

# ==============================================================================
# WebSocket Endpoint
# ==============================================================================

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send initial connection message
        await websocket.send_json({
            "type": "connection.established",
            "data": {"message": "Connected to SecureRedLab"},
            "timestamp": datetime.utcnow().isoformat()
        })
        
        # Keep connection alive and listen for messages
        while True:
            data = await websocket.receive_text()
            # Echo back for now
            await websocket.send_json({
                "type": "message.received",
                "data": {"echo": data},
                "timestamp": datetime.utcnow().isoformat()
            })
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# ==============================================================================
# Background Tasks (Simulated Real-time Updates)
# ==============================================================================

async def send_periodic_updates():
    """Send periodic updates to connected clients"""
    while True:
        await asyncio.sleep(10)  # Every 10 seconds
        message = {
            "type": "scan.progress",
            "data": {
                "scan_id": "scan-002",
                "progress": 70,
                "status": "running"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        await manager.broadcast(message)

@app.on_event("startup")
async def startup_event():
    # Start background tasks
    asyncio.create_task(send_periodic_updates())
    print("✓ SecureRedLab API Started")
    print("✓ Docs: http://localhost:8000/docs")
    print("✓ WebSocket: ws://localhost:8000/ws")

# ==============================================================================
# Main
# ==============================================================================

if __name__ == "__main__":
    uvicorn.run(
        "simple_api:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
