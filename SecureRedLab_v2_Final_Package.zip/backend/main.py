"""
SecureRedLab - FastAPI Backend Main Entry Point
پلتفرم شبیه‌سازی تیم قرمز مبتنی بر هوش مصنوعی

Plan C: Hybrid Architecture
- Frontend: Cloudflare Pages
- Backend: VPS (FastAPI + AI + Execution)

Author: SecureRedLab Team
License: Academic Research Only
"""

import sys
import os
from pathlib import Path

# اضافه کردن مسیر backend به PYTHONPATH
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from contextlib import asynccontextmanager
import time
from typing import Dict, Any
import asyncio

# Core imports
from core.logging_system import LoggingSystem, LogCategory
from core.exception_handler import (
    SecureRedLabException,
    ErrorCategory,
    ErrorSeverity,
    handle_exception
)
from core.config_manager import ConfigManager
from core.database_manager import get_database_manager
from core.auth_system import AuthSystem

# ==============================================================================
# Configuration - پیکربندی
# ==============================================================================

# Load configuration
config_manager = ConfigManager()
config = config_manager.get_config()

# Initialize logging system
logging_system = LoggingSystem()
logger = logging_system.get_logger(LogCategory.SYSTEM)

# Initialize database manager
db_manager = get_database_manager()

# Initialize auth system
auth_system = AuthSystem()

# ==============================================================================
# Lifespan Events - رویدادهای چرخه حیات
# ==============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for startup and shutdown events
    
    مدیریت رویدادهای Startup و Shutdown
    """
    # Startup
    logger.info("🚀 Starting SecureRedLab Backend...")
    
    try:
        # Test database connection
        logger.info("📊 Testing database connection...")
        # db_manager.test_connection()  # Uncomment در production
        logger.info("✅ Database connection successful")
        
        # Load AI models configuration
        logger.info("🤖 Loading AI models configuration...")
        ai_models = config.get('ai_models', {})
        enabled_models = [name for name, conf in ai_models.items() if conf.get('enabled')]
        logger.info(f"✅ AI Models loaded: {', '.join(enabled_models)}")
        
        # Initialize execution containers (Docker)
        logger.info("🐳 Checking Docker containers...")
        # TODO: Add Docker health check
        logger.info("✅ Docker containers ready")
        
        logger.info("✅ SecureRedLab Backend started successfully!")
        logger.info("=" * 80)
        
    except Exception as e:
        logger.error(f"❌ Startup failed: {str(e)}", exc_info=True)
        raise
    
    yield
    
    # Shutdown
    logger.info("=" * 80)
    logger.info("🛑 Shutting down SecureRedLab Backend...")
    
    try:
        # Close database connections
        logger.info("📊 Closing database connections...")
        # db_manager.close_all_connections()  # Uncomment در production
        
        # Stop background tasks
        logger.info("⏸️  Stopping background tasks...")
        
        logger.info("✅ SecureRedLab Backend stopped successfully!")
        
    except Exception as e:
        logger.error(f"❌ Shutdown error: {str(e)}", exc_info=True)

# ==============================================================================
# FastAPI App Initialization - راه‌اندازی برنامه
# ==============================================================================

app = FastAPI(
    title="SecureRedLab API",
    description="AI-Driven Red Team Simulation Platform - پلتفرم شبیه‌سازی تیم قرمز مبتنی بر هوش مصنوعی",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan
)

# ==============================================================================
# Middleware Configuration - پیکربندی Middleware
# ==============================================================================

# CORS Middleware
cors_origins = config.get('cors', {}).get('allow_origins', ['*'])
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (امنیت)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]  # TODO: محدود کنید در production
)

# Request Logging Middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """
    Log all incoming requests
    
    لاگ تمام درخواست‌های ورودی
    """
    start_time = time.time()
    
    # Log request
    logger.info(
        f"📥 {request.method} {request.url.path}",
        extra={
            "method": request.method,
            "path": request.url.path,
            "client_ip": request.client.host,
            "user_agent": request.headers.get("user-agent")
        }
    )
    
    try:
        response = await call_next(request)
        
        # Calculate request duration
        duration = time.time() - start_time
        
        # Log response
        logger.info(
            f"📤 {request.method} {request.url.path} - {response.status_code} ({duration:.3f}s)",
            extra={
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration": duration
            }
        )
        
        # Add custom headers
        response.headers["X-Process-Time"] = str(duration)
        response.headers["X-API-Version"] = "2.0.0"
        
        return response
        
    except Exception as e:
        duration = time.time() - start_time
        logger.error(
            f"❌ {request.method} {request.url.path} - Error: {str(e)} ({duration:.3f}s)",
            exc_info=True
        )
        raise

# ==============================================================================
# Exception Handlers - مدیریت خطاها
# ==============================================================================

@app.exception_handler(SecureRedLabException)
async def secureredlab_exception_handler(request: Request, exc: SecureRedLabException):
    """
    Handle custom SecureRedLab exceptions
    
    مدیریت خطاهای سفارشی SecureRedLab
    """
    logger.error(
        f"SecureRedLab Exception: {exc.message}",
        extra={
            "category": exc.category.value,
            "severity": exc.severity.value,
            "context": exc.context,
            "path": request.url.path
        }
    )
    
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "success": False,
            "error": {
                "type": exc.__class__.__name__,
                "category": exc.category.value,
                "severity": exc.severity.value,
                "message": exc.message,
                "message_fa": exc.persian_message or exc.message,
                "timestamp": time.time()
            }
        }
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """
    Handle request validation errors
    
    مدیریت خطاهای اعتبارسنجی
    """
    logger.warning(
        f"Validation Error: {str(exc)}",
        extra={
            "path": request.url.path,
            "errors": exc.errors()
        }
    )
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "error": {
                "type": "ValidationError",
                "message": "Invalid request data",
                "message_fa": "داده‌های درخواست نامعتبر است",
                "details": exc.errors(),
                "timestamp": time.time()
            }
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    Handle all other exceptions
    
    مدیریت سایر خطاها
    """
    logger.error(
        f"Unhandled Exception: {str(exc)}",
        exc_info=True,
        extra={"path": request.url.path}
    )
    
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "success": False,
            "error": {
                "type": "InternalServerError",
                "message": "An unexpected error occurred",
                "message_fa": "یک خطای غیرمنتظره رخ داده است",
                "timestamp": time.time()
            }
        }
    )

# ==============================================================================
# Health Check Endpoints - نقاط پایانی بررسی سلامت
# ==============================================================================

@app.get("/")
async def root():
    """
    Root endpoint
    
    نقطه پایانی ریشه
    """
    return {
        "success": True,
        "message": "SecureRedLab API is running",
        "message_fa": "API SecureRedLab در حال اجرا است",
        "version": "2.0.0",
        "architecture": "Plan C - Hybrid (Cloudflare Pages + VPS)",
        "timestamp": time.time()
    }

@app.get("/health")
async def health_check():
    """
    Health check endpoint
    
    بررسی سلامت سیستم
    """
    health_status = {
        "success": True,
        "status": "healthy",
        "timestamp": time.time(),
        "checks": {
            "database": "unknown",
            "redis": "unknown",
            "docker": "unknown",
            "ai_models": "unknown"
        }
    }
    
    try:
        # Check database
        # db_manager.test_connection()  # Uncomment در production
        health_status["checks"]["database"] = "healthy"
    except Exception as e:
        health_status["checks"]["database"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
    
    try:
        # Check Redis
        # TODO: Add Redis health check
        health_status["checks"]["redis"] = "healthy"
    except Exception as e:
        health_status["checks"]["redis"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
    
    try:
        # Check Docker
        # TODO: Add Docker health check
        health_status["checks"]["docker"] = "healthy"
    except Exception as e:
        health_status["checks"]["docker"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
    
    # Check AI models
    ai_models = config.get('ai_models', {})
    enabled_count = sum(1 for conf in ai_models.values() if conf.get('enabled'))
    health_status["checks"]["ai_models"] = f"{enabled_count}/5 enabled"
    
    return health_status

@app.get("/api/info")
async def api_info():
    """
    API information endpoint
    
    اطلاعات API
    """
    return {
        "success": True,
        "api": {
            "name": "SecureRedLab API",
            "version": "2.0.0",
            "architecture": "Plan C - Hybrid",
            "description": "AI-Driven Red Team Simulation Platform",
            "description_fa": "پلتفرم شبیه‌سازی تیم قرمز مبتنی بر هوش مصنوعی"
        },
        "features": {
            "ai_models": ["DeepSeek-Coder-33B", "GLM-4-6B", "LLaMA-3.1-70B", "Mixtral-8x22B", "Qwen-14B"],
            "execution_engines": ["Metasploit", "SQLMap", "Nmap"],
            "rl_agents": ["DDoS", "Shell Upload", "Data Extraction", "Deface", "Behavior Simulation"],
            "vulnerability_types": 15,
            "waf_bypass": True,
            "real_time_monitoring": True,
            "tamper_proof_logging": True
        },
        "endpoints": {
            "health": "/health",
            "docs": "/api/docs",
            "authentication": "/api/auth/*",
            "scanning": "/api/scan/*",
            "execution": "/api/execute/*",
            "monitoring": "/api/monitor/*",
            "admin": "/api/admin/*"
        },
        "timestamp": time.time()
    }

# ==============================================================================
# API Routes Registration - ثبت مسیرهای API
# ==============================================================================

# TODO: Import و register کردن routers
# from api.routes import auth_router, scan_router, execute_router, monitor_router, admin_router
# 
# app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
# app.include_router(scan_router, prefix="/api/scan", tags=["Scanning"])
# app.include_router(execute_router, prefix="/api/execute", tags=["Execution"])
# app.include_router(monitor_router, prefix="/api/monitor", tags=["Monitoring"])
# app.include_router(admin_router, prefix="/api/admin", tags=["Admin"])

# ==============================================================================
# Main Entry Point - نقطه ورود اصلی
# ==============================================================================

if __name__ == "__main__":
    import uvicorn
    
    # Development mode
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,  # Auto-reload در development
        log_level="info",
        access_log=True
    )
