"""
SecureRedLab Execution Layer
لایه اجرای ابزارهای تست نفوذ

این پکیج شامل wrapperهای Metasploit, SQLMap, Nmap و سایر ابزارها می‌باشد.
"""

__version__ = "2.0.0"
__all__ = []
