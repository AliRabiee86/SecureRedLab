#!/bin/bash
# SecureRedLab Backend - Start Script for Development

# Set colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}SecureRedLab Backend - Development Mode${NC}"
echo -e "${BLUE}========================================${NC}"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Set PYTHONPATH to include project root
export PYTHONPATH="${PROJECT_ROOT}:${PROJECT_ROOT}/backend:${PYTHONPATH}"

echo -e "${BLUE}Project Root:${NC} $PROJECT_ROOT"
echo -e "${BLUE}PYTHONPATH:${NC} $PYTHONPATH"
echo ""

# Activate virtual environment
if [ -f "$SCRIPT_DIR/venv/bin/activate" ]; then
    echo -e "${GREEN}✓${NC} Activating virtual environment..."
    source "$SCRIPT_DIR/venv/bin/activate"
else
    echo -e "${RED}✗${NC} Virtual environment not found!"
    echo "Please run: python3 -m venv venv"
    exit 1
fi

# Check if .env exists
if [ ! -f "$SCRIPT_DIR/.env" ]; then
    echo -e "${RED}✗${NC} .env file not found!"
    echo "Copying .env.example to .env..."
    cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"
    echo -e "${GREEN}✓${NC} .env file created. Please configure it."
fi

# Create logs directory
mkdir -p "$SCRIPT_DIR/logs"

echo -e "${GREEN}✓${NC} Starting FastAPI backend..."
echo ""

# Start uvicorn
cd "$SCRIPT_DIR"
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
