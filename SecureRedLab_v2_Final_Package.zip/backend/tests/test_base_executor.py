"""
Tests for Enhanced BaseExecutor
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from app.execution.base_executor import (
    BaseExecutor,
    ContainerTimeoutError,
    ContainerExecutionError
)


class MockExecutor(BaseExecutor):
    """Mock executor for testing"""
    
    async def execute(self, **kwargs):
        """Mock execute implementation"""
        return await self._run_container(
            image="alpine:latest",
            command="echo 'test'",
            timeout=10
        )
    
    def parse_output(self, raw_output: str):
        """Mock parse implementation"""
        return {"output": raw_output}


@pytest.fixture
def mock_docker_client():
    """Mock Docker client"""
    with patch('docker.from_env') as mock:
        client = MagicMock()
        mock.return_value = client
        yield client


@pytest.fixture
def progress_callback():
    """Mock progress callback"""
    return Mock()


@pytest.mark.asyncio
async def test_executor_initialization(mock_docker_client):
    """Test executor initialization"""
    executor = MockExecutor()
    assert executor.docker_client is not None
    assert executor.progress_callback is None
    assert len(executor._running_containers) == 0


@pytest.mark.asyncio
async def test_executor_with_progress_callback(mock_docker_client, progress_callback):
    """Test executor with progress callback"""
    executor = MockExecutor(progress_callback=progress_callback)
    assert executor.progress_callback == progress_callback


@pytest.mark.asyncio
async def test_update_progress(mock_docker_client):
    """Test progress update"""
    callback = Mock()
    executor = MockExecutor(progress_callback=callback)
    
    await executor._update_progress(50, "Test message")
    callback.assert_called_once_with(50, "Test message")


@pytest.mark.asyncio
async def test_update_progress_async_callback(mock_docker_client):
    """Test async progress callback"""
    callback = AsyncMock()
    executor = MockExecutor(progress_callback=callback)
    
    await executor._update_progress(75, "Async test")
    callback.assert_called_once_with(75, "Async test")


@pytest.mark.asyncio
async def test_run_container_basic(mock_docker_client):
    """Test basic container execution"""
    # Mock container
    mock_container = MagicMock()
    mock_container.id = "test123"
    mock_container.wait.return_value = {"StatusCode": 0}
    mock_container.logs.return_value = b"test output"
    mock_container.attach.return_value = [(b"test output", None)]
    
    # Mock image
    mock_docker_client.images.get.return_value = MagicMock()
    mock_docker_client.containers.create.return_value = mock_container
    
    executor = MockExecutor()
    
    result = await executor._run_container(
        image="alpine:latest",
        command="echo test",
        timeout=10,
        stream_logs=False
    )
    
    assert result["exit_code"] == 0
    assert "stdout" in result
    assert "duration" in result


@pytest.mark.asyncio
async def test_run_container_timeout(mock_docker_client):
    """Test container timeout"""
    # Mock container that never finishes
    mock_container = MagicMock()
    mock_container.id = "timeout123"
    mock_container.wait = Mock(side_effect=asyncio.TimeoutError())
    
    mock_docker_client.images.get.return_value = MagicMock()
    mock_docker_client.containers.create.return_value = mock_container
    
    executor = MockExecutor()
    
    with pytest.raises(ContainerTimeoutError):
        await executor._run_container(
            image="alpine:latest",
            command="sleep 999",
            timeout=1,
            stream_logs=False
        )


@pytest.mark.asyncio
async def test_run_container_resource_limits(mock_docker_client):
    """Test container resource limits"""
    mock_container = MagicMock()
    mock_container.id = "resource123"
    mock_container.wait.return_value = {"StatusCode": 0}
    mock_container.logs.return_value = b"output"
    
    mock_docker_client.images.get.return_value = MagicMock()
    mock_docker_client.containers.create.return_value = mock_container
    
    executor = MockExecutor()
    
    await executor._run_container(
        image="alpine:latest",
        command="echo test",
        mem_limit="256m",
        cpu_quota=50000,  # 0.5 CPU
        timeout=10,
        stream_logs=False
    )
    
    # Verify resource limits were passed
    create_call = mock_docker_client.containers.create.call_args
    assert create_call.kwargs["mem_limit"] == "256m"
    assert create_call.kwargs["cpu_quota"] == 50000


@pytest.mark.asyncio
async def test_run_container_security_options(mock_docker_client):
    """Test container security options"""
    mock_container = MagicMock()
    mock_container.id = "secure123"
    mock_container.wait.return_value = {"StatusCode": 0}
    mock_container.logs.return_value = b"output"
    
    mock_docker_client.images.get.return_value = MagicMock()
    mock_docker_client.containers.create.return_value = mock_container
    
    executor = MockExecutor()
    
    await executor._run_container(
        image="alpine:latest",
        command="echo test",
        read_only=True,
        user="nobody",
        timeout=10,
        stream_logs=False
    )
    
    # Verify security options
    create_call = mock_docker_client.containers.create.call_args
    assert create_call.kwargs["read_only"] == True
    assert create_call.kwargs["user"] == "nobody"
    assert create_call.kwargs["cap_drop"] == ["ALL"]
    assert "no-new-privileges" in create_call.kwargs["security_opt"]


@pytest.mark.asyncio
async def test_kill_container_async(mock_docker_client):
    """Test async container kill"""
    mock_container = MagicMock()
    mock_docker_client.containers.get.return_value = mock_container
    
    executor = MockExecutor()
    
    await executor._kill_container_async("test123")
    
    mock_container.stop.assert_called_once()


@pytest.mark.asyncio
async def test_kill_container_force(mock_docker_client):
    """Test force kill when stop fails"""
    mock_container = MagicMock()
    mock_container.stop.side_effect = Exception("Stop failed")
    mock_docker_client.containers.get.return_value = mock_container
    
    executor = MockExecutor()
    
    await executor._kill_container_async("test123")
    
    mock_container.kill.assert_called_once()


@pytest.mark.asyncio
async def test_emergency_stop(mock_docker_client):
    """Test emergency stop all containers"""
    # Create executor with running containers
    executor = MockExecutor()
    executor._running_containers = {"container1", "container2", "container3"}
    
    mock_container = MagicMock()
    mock_docker_client.containers.get.return_value = mock_container
    
    await executor.emergency_stop()
    
    # Verify all containers stopped
    assert len(executor._running_containers) == 0
    assert mock_docker_client.containers.get.call_count == 3


@pytest.mark.asyncio
async def test_cleanup_container(mock_docker_client):
    """Test container cleanup"""
    mock_container = MagicMock()
    mock_docker_client.containers.get.return_value = mock_container
    
    executor = MockExecutor()
    
    await executor._cleanup_container("cleanup123")
    
    mock_container.remove.assert_called_once_with(force=True)


@pytest.mark.asyncio
async def test_progress_callback_error_handling(mock_docker_client):
    """Test progress callback error doesn't crash execution"""
    # Callback that raises error
    callback = Mock(side_effect=Exception("Callback error"))
    executor = MockExecutor(progress_callback=callback)
    
    # Should not raise
    await executor._update_progress(50, "Test")
    
    callback.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
