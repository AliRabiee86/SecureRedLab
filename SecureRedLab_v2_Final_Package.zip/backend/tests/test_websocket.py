"""
WebSocket Test Client
Simple Python script to test WebSocket functionality
"""

import asyncio
import websockets
import json
from datetime import datetime


async def test_scan_websocket(scan_id: str = "test-scan-123"):
    """
    Test WebSocket connection for scan updates
    
    Usage:
        python test_websocket.py
    """
    uri = f"ws://localhost:8000/ws/scans/{scan_id}"
    
    print(f"Connecting to {uri}...")
    
    try:
        async with websockets.connect(uri) as websocket:
            print("✅ Connected successfully!")
            
            # Receive messages
            while True:
                try:
                    message = await websocket.recv()
                    data = json.loads(message)
                    
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    msg_type = data.get("type", "unknown")
                    
                    print(f"\n[{timestamp}] Received: {msg_type}")
                    print(json.dumps(data, indent=2))
                    
                    # Check for completion
                    if data.get("type") == "status_update" and data.get("status") == "completed":
                        print("\n✅ Scan completed! Closing connection...")
                        break
                    
                except websockets.exceptions.ConnectionClosed:
                    print("\n❌ Connection closed by server")
                    break
                except json.JSONDecodeError as e:
                    print(f"\n❌ Invalid JSON: {e}")
                except Exception as e:
                    print(f"\n❌ Error: {e}")
                    break
    
    except Exception as e:
        print(f"\n❌ Failed to connect: {e}")


async def test_multiple_connections():
    """Test multiple concurrent WebSocket connections"""
    scan_ids = ["scan-1", "scan-2", "scan-3"]
    
    tasks = [test_scan_websocket(scan_id) for scan_id in scan_ids]
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    print("=" * 60)
    print("SecureRedLab - WebSocket Test Client")
    print("=" * 60)
    
    # Test single connection
    asyncio.run(test_scan_websocket())
    
    # Uncomment to test multiple connections:
    # asyncio.run(test_multiple_connections())
