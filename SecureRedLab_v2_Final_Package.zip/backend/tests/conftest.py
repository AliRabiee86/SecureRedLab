"""
SecureRedLab Backend - Pytest Configuration
Fixtures and configuration for testing
"""

import pytest
from fastapi.testclient import TestClient
import os
import sys

# Add backend to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.main import app
from app.config import settings


@pytest.fixture
def client():
    """FastAPI test client"""
    return TestClient(app)


@pytest.fixture
def auth_headers(client):
    """Get authentication headers"""
    # Create test user and login
    response = client.post(
        "/api/v1/auth/register",
        json={
            "username": "testuser",
            "email": "test@example.com",
            "password": "TestPassword123!"
        }
    )
    
    # Login
    response = client.post(
        "/api/v1/auth/login",
        json={
            "username": "testuser",
            "password": "TestPassword123!"
        }
    )
    
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def test_user():
    """Test user data"""
    return {
        "username": "testuser",
        "email": "test@example.com",
        "password": "TestPassword123!"
    }


@pytest.fixture
def test_scan_data():
    """Test scan data"""
    return {
        "target": "192.168.1.1",
        "scan_type": "port_scan",
        "ports": "1-1000"
    }


@pytest.fixture
def test_attack_data():
    """Test attack data"""
    return {
        "target": "http://testphp.vulnweb.com",
        "attack_type": "sql_injection",
        "use_rl": True
    }


@pytest.fixture(scope="session")
def database():
    """Test database fixture"""
    # TODO: Setup test database
    # TODO: Run migrations
    yield
    # TODO: Cleanup database


# Configure pytest
def pytest_configure(config):
    """Pytest configuration"""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests"
    )
    config.addinivalue_line(
        "markers", "unit: marks tests as unit tests"
    )
