"""
SecureRedLab Backend - SQLMap Executor Tests
Phase 7.4: Comprehensive test suite for SQLMapExecutor

Test Coverage:
- Input validation (target, level, risk)
- Command building
- Output parsing
- SQL injection detection
- Database enumeration
- Security controls
- Error handling
- Timeout behavior

Author: SecureRedLab Team
Date: 2026-01-02
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from typing import Dict, Any

from app.execution.sqlmap_executor import (
    SQLMapExecutor,
    InjectionTechnique,
    DatabaseType,
    TamperScript
)
from app.execution.base_executor import ContainerExecutionError, ContainerTimeoutError


# Test Fixtures
@pytest.fixture
def sqlmap_executor():
    """Create SQLMapExecutor instance for testing."""
    return SQLMapExecutor()


# ==================== Input Validation Tests ====================

class TestInputValidation:
    """Test input validation for SQLMapExecutor."""
    
    def test_validate_target_valid_http(self, sqlmap_executor):
        """Test valid HTTP target validation."""
        sqlmap_executor._validate_target("http://example.com/page?id=1")  # Should not raise
    
    def test_validate_target_valid_https(self, sqlmap_executor):
        """Test valid HTTPS target validation."""
        sqlmap_executor._validate_target("https://example.com/page?id=1")  # Should not raise
    
    def test_validate_target_blocked_localhost(self, sqlmap_executor):
        """Test that localhost is blocked."""
        with pytest.raises(ValueError, match="blocked for security reasons"):
            sqlmap_executor._validate_target("http://localhost/page?id=1")
    
    def test_validate_target_blocked_127(self, sqlmap_executor):
        """Test that 127.0.0.1 is blocked."""
        with pytest.raises(ValueError, match="blocked for security reasons"):
            sqlmap_executor._validate_target("http://127.0.0.1/page?id=1")
    
    def test_validate_target_no_protocol(self, sqlmap_executor):
        """Test target without http:// or https://."""
        with pytest.raises(ValueError, match="must start with http"):
            sqlmap_executor._validate_target("example.com/page?id=1")
    
    def test_validate_target_dangerous_option(self, sqlmap_executor):
        """Test that dangerous options are blocked."""
        with pytest.raises(ValueError, match="Dangerous option"):
            sqlmap_executor._validate_target("http://example.com?id=1 --os-shell")
    
    def test_validate_level_risk_valid(self, sqlmap_executor):
        """Test valid level and risk."""
        sqlmap_executor._validate_level_risk(1, 1)  # Should not raise
        sqlmap_executor._validate_level_risk(5, 3)  # Should not raise
    
    def test_validate_level_invalid(self, sqlmap_executor):
        """Test invalid level."""
        with pytest.raises(ValueError, match="Level must be between 1 and 5"):
            sqlmap_executor._validate_level_risk(6, 1)
    
    def test_validate_risk_invalid(self, sqlmap_executor):
        """Test invalid risk."""
        with pytest.raises(ValueError, match="Risk must be between 1 and 3"):
            sqlmap_executor._validate_level_risk(1, 4)


# ==================== Command Building Tests ====================

class TestCommandBuilding:
    """Test SQLMap command building."""
    
    def test_build_basic_command(self, sqlmap_executor):
        """Test basic command building."""
        command = sqlmap_executor._build_sqlmap_command(
            target="http://example.com/page?id=1",
            parameters=None,
            technique=InjectionTechnique.ALL,
            level=1,
            risk=1,
            tamper=None,
            threads=3
        )
        
        assert "sqlmap" in command
        assert "-u" in command
        assert "http://example.com/page?id=1" in command
        assert "--batch" in command
        assert "--technique=BEUSTQ" in command
        assert "--level=1" in command
        assert "--risk=1" in command
        assert "--threads=3" in command
    
    def test_build_command_with_parameters(self, sqlmap_executor):
        """Test command with specific parameters."""
        command = sqlmap_executor._build_sqlmap_command(
            target="http://example.com/page?id=1&name=test",
            parameters=["id", "name"],
            technique=InjectionTechnique.UNION_QUERY,
            level=2,
            risk=2,
            tamper=None,
            threads=5
        )
        
        assert "-p" in command
        assert "id,name" in command
    
    def test_build_command_with_tamper(self, sqlmap_executor):
        """Test command with tamper scripts."""
        command = sqlmap_executor._build_sqlmap_command(
            target="http://example.com/page?id=1",
            parameters=None,
            technique=InjectionTechnique.ALL,
            level=1,
            risk=1,
            tamper=[TamperScript.SPACE2COMMENT, TamperScript.RANDOMCASE],
            threads=3
        )
        
        assert "--tamper" in command
        assert "space2comment,randomcase" in command


# ==================== Output Parsing Tests ====================

class TestOutputParsing:
    """Test SQLMap output parsing."""
    
    def test_parse_injectable_output(self, sqlmap_executor):
        """Test parsing output with SQL injection found."""
        output = """
        [INFO] testing if GET parameter 'id' is vulnerable
        [INFO] GET parameter 'id' is vulnerable. Do you want to keep testing the others?
        [INFO] the back-end DBMS is MySQL
        web application technology: PHP 7.4.3
        back-end DBMS: MySQL 5.7.30
        available databases [3]:
        [*] information_schema
        [*] mysql
        [*] test_db
        """
        
        result = sqlmap_executor._parse_sqlmap_output(output)
        
        assert result['injectable'] is True
        assert result['dbms'] == DatabaseType.MYSQL.value
        assert result['version'] == '5.7.30'
        assert 'information_schema' in result['databases']
        assert len(result['vulnerabilities']) > 0
    
    def test_parse_not_injectable_output(self, sqlmap_executor):
        """Test parsing output with no SQL injection."""
        output = """
        [INFO] testing if GET parameter 'id' is vulnerable
        [WARNING] GET parameter 'id' does not seem to be injectable
        [CRITICAL] all tested parameters do not appear to be injectable
        """
        
        result = sqlmap_executor._parse_sqlmap_output(output)
        
        assert result['injectable'] is False
        assert len(result['vulnerabilities']) == 0
    
    def test_parse_technique_detection(self, sqlmap_executor):
        """Test technique detection in output."""
        output = """
        [INFO] GET parameter 'id' is 'Boolean-based blind' injectable
        """
        
        result = sqlmap_executor._parse_sqlmap_output(output)
        
        assert result['technique'] == 'Boolean-based blind'
    
    def test_parse_union_technique(self, sqlmap_executor):
        """Test Union query technique detection."""
        output = """
        [INFO] GET parameter 'id' is 'Union query' injectable
        """
        
        result = sqlmap_executor._parse_sqlmap_output(output)
        
        assert result['technique'] == 'Union query'


# ==================== SQL Injection Detection Tests ====================

class TestSQLInjectionDetection:
    """Test SQL injection detection functionality."""
    
    @pytest.mark.asyncio
    async def test_execute_success(self, sqlmap_executor):
        """Test successful SQL injection detection."""
        with patch.object(sqlmap_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'sqlmap-123',
                'stdout': """
                [INFO] GET parameter 'id' is vulnerable
                [INFO] the back-end DBMS is MySQL
                back-end DBMS: MySQL 5.7.30
                available databases [2]:
                [*] test_db
                [*] app_db
                """,
                'stderr': '',
                'exit_code': 0
            }
            
            result = await sqlmap_executor.execute(
                target="http://example.com/page?id=1",
                level=1,
                risk=1
            )
            
            assert result['injectable'] is True
            assert result['dbms'] == DatabaseType.MYSQL.value
            assert result['status'] == "completed"
            assert 'test_db' in result['databases']
    
    @pytest.mark.asyncio
    async def test_execute_not_vulnerable(self, sqlmap_executor):
        """Test when target is not vulnerable."""
        with patch.object(sqlmap_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'sqlmap-123',
                'stdout': """
                [WARNING] GET parameter 'id' does not seem to be injectable
                [CRITICAL] all tested parameters do not appear to be injectable
                """,
                'stderr': '',
                'exit_code': 0
            }
            
            result = await sqlmap_executor.execute(
                target="http://example.com/page?id=1"
            )
            
            assert result['injectable'] is False
            assert result['status'] == "completed"


# ==================== Security Tests ====================

class TestSecurity:
    """Test security controls and validation."""
    
    @pytest.mark.asyncio
    async def test_blocked_target_localhost(self, sqlmap_executor):
        """Test that localhost is blocked as target."""
        result = await sqlmap_executor.execute(
            target="http://localhost/page?id=1"
        )
        
        assert result['injectable'] is False
        assert result['status'] == "failed"
        assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_blocked_target_127(self, sqlmap_executor):
        """Test that 127.0.0.1 is blocked."""
        result = await sqlmap_executor.execute(
            target="http://127.0.0.1/page?id=1"
        )
        
        assert result['injectable'] is False
        assert result['status'] == "failed"


# ==================== Integration Tests ====================

class TestIntegration:
    """Integration tests for full workflow."""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self, sqlmap_executor):
        """Test complete SQL injection workflow."""
        progress_updates = []
        
        def progress_callback(progress: int, message: str):
            progress_updates.append((progress, message))
        
        sqlmap_executor.progress_callback = progress_callback
        
        with patch.object(sqlmap_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'sqlmap-123',
                'stdout': """
                [INFO] testing if GET parameter 'id' is vulnerable
                [INFO] GET parameter 'id' is 'Union query' injectable
                [INFO] the back-end DBMS is PostgreSQL
                back-end DBMS: PostgreSQL 12.5
                available databases [3]:
                [*] public
                [*] postgres
                [*] app_db
                """,
                'stderr': '',
                'exit_code': 0
            }
            
            result = await sqlmap_executor.execute(
                target="http://example.com/page?id=1",
                technique=InjectionTechnique.UNION_QUERY,
                level=2,
                risk=1,
                attack_id="test_attack_001"
            )
            
            # Verify result
            assert result['injectable'] is True
            assert result['attack_id'] == "test_attack_001"
            assert result['dbms'] == DatabaseType.POSTGRESQL.value
            assert result['status'] == "completed"
            
            # Verify progress updates
            assert len(progress_updates) > 0
            assert progress_updates[0][0] == 10  # First progress
            assert progress_updates[-1][0] == 100  # Last progress


# ==================== Error Handling Tests ====================

class TestErrorHandling:
    """Test error handling and recovery."""
    
    @pytest.mark.asyncio
    async def test_container_failure(self, sqlmap_executor):
        """Test handling of container execution failure."""
        with patch.object(sqlmap_executor, '_run_container', side_effect=Exception("Container failed")):
            result = await sqlmap_executor.execute(
                target="http://example.com/page?id=1"
            )
            
            assert result['injectable'] is False
            assert result['status'] == "failed"
            assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_timeout_handling(self, sqlmap_executor):
        """Test handling of execution timeout."""
        with patch.object(sqlmap_executor, '_run_container', side_effect=asyncio.TimeoutError("Timeout")):
            result = await sqlmap_executor.execute(
                target="http://example.com/page?id=1",
                timeout=10
            )
            
            assert result['injectable'] is False
            assert 'error' in result


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
