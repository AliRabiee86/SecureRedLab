#!/usr/bin/env python3
"""
SecureRedLab - Backend API Integration Test
Phase 9.1 - Frontend-Backend Integration Testing

Tests all API endpoints to ensure proper connectivity
"""

import requests
import json
import sys
from typing import Dict, Any
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:8000"
TIMEOUT = 5

# Test results
test_results = {
    "passed": 0,
    "failed": 0,
    "errors": []
}


def log_test(endpoint: str, method: str, status: str, message: str = ""):
    """Log test result"""
    symbol = "✅" if status == "PASS" else "❌"
    print(f"{symbol} {method:6} {endpoint:40} - {status}")
    if message:
        print(f"   └─ {message}")


def test_endpoint(method: str, endpoint: str, expected_status: int = 200, 
                 data: Dict[str, Any] = None) -> bool:
    """Test a single endpoint"""
    try:
        url = f"{BASE_URL}{endpoint}"
        
        if method == "GET":
            response = requests.get(url, timeout=TIMEOUT)
        elif method == "POST":
            response = requests.post(url, json=data, timeout=TIMEOUT)
        elif method == "DELETE":
            response = requests.delete(url, timeout=TIMEOUT)
        else:
            raise ValueError(f"Unsupported method: {method}")
        
        if response.status_code == expected_status:
            test_results["passed"] += 1
            log_test(endpoint, method, "PASS", f"Status: {response.status_code}")
            return True
        else:
            test_results["failed"] += 1
            log_test(endpoint, method, "FAIL", 
                    f"Expected {expected_status}, got {response.status_code}")
            test_results["errors"].append({
                "endpoint": endpoint,
                "method": method,
                "expected": expected_status,
                "actual": response.status_code
            })
            return False
            
    except requests.exceptions.Timeout:
        test_results["failed"] += 1
        log_test(endpoint, method, "FAIL", "Timeout")
        test_results["errors"].append({
            "endpoint": endpoint,
            "method": method,
            "error": "Timeout"
        })
        return False
        
    except Exception as e:
        test_results["failed"] += 1
        log_test(endpoint, method, "FAIL", str(e))
        test_results["errors"].append({
            "endpoint": endpoint,
            "method": method,
            "error": str(e)
        })
        return False


def main():
    """Run all API integration tests"""
    print("\n" + "="*60)
    print("🧪 SecureRedLab Backend API Integration Tests")
    print("="*60)
    print(f"Base URL: {BASE_URL}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    
    # Health Check
    print("📋 Health Check")
    print("-" * 60)
    test_endpoint("GET", "/")
    test_endpoint("GET", "/health")
    print()
    
    # Authentication Endpoints
    print("🔐 Authentication Endpoints")
    print("-" * 60)
    test_endpoint("POST", "/auth/login", 200, {
        "email": "test@example.com",
        "password": "testpass123"
    })
    test_endpoint("POST", "/auth/logout")
    test_endpoint("GET", "/auth/me", 401)  # Should fail without auth
    print()
    
    # Scans Endpoints
    print("🔍 Scans Endpoints")
    print("-" * 60)
    test_endpoint("GET", "/scans")
    test_endpoint("GET", "/scans/scan-001")
    test_endpoint("POST", "/scans", 200, {
        "target": "192.168.1.0/24",
        "scan_type": "NMAP"
    })
    print()
    
    # Attacks Endpoints
    print("⚔️  Attacks Endpoints")
    print("-" * 60)
    test_endpoint("GET", "/attacks")
    test_endpoint("GET", "/attacks/attack-001")
    print()
    
    # Vulnerabilities Endpoints
    print("🐛 Vulnerabilities Endpoints")
    print("-" * 60)
    test_endpoint("GET", "/vulnerabilities")
    test_endpoint("GET", "/scans/scan-001/vulnerabilities")
    print()
    
    # Dashboard Endpoints
    print("📊 Dashboard Endpoints")
    print("-" * 60)
    test_endpoint("GET", "/dashboard/stats")
    print()
    
    # WebSocket (just check docs)
    print("🔌 WebSocket Endpoint")
    print("-" * 60)
    print("ℹ️  WebSocket endpoint: ws://localhost:8000/ws")
    print("   (WebSocket requires separate connection test)")
    print()
    
    # Summary
    print("="*60)
    print("📈 Test Summary")
    print("="*60)
    total = test_results["passed"] + test_results["failed"]
    pass_rate = (test_results["passed"] / total * 100) if total > 0 else 0
    
    print(f"Total Tests:  {total}")
    print(f"✅ Passed:    {test_results['passed']}")
    print(f"❌ Failed:    {test_results['failed']}")
    print(f"📊 Pass Rate: {pass_rate:.1f}%")
    
    if test_results["errors"]:
        print("\n⚠️  Failed Tests Details:")
        for error in test_results["errors"]:
            print(f"   - {error['method']} {error['endpoint']}")
            if 'error' in error:
                print(f"     Error: {error['error']}")
            else:
                print(f"     Expected: {error['expected']}, Got: {error['actual']}")
    
    print("="*60 + "\n")
    
    # Exit code
    return 0 if test_results["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
