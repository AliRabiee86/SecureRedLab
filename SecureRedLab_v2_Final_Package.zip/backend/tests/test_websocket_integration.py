#!/usr/bin/env python3
"""
SecureRedLab - WebSocket Integration Test
Phase 9.1 - Frontend-Backend Integration Testing

Tests WebSocket connection and real-time updates
"""

import asyncio
import websockets
import json
from datetime import datetime


async def test_websocket():
    """Test WebSocket connection"""
    uri = "ws://localhost:8000/ws"
    
    print("\n" + "="*60)
    print("🔌 SecureRedLab WebSocket Integration Test")
    print("="*60)
    print(f"URI: {uri}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    
    try:
        print("🔄 Connecting to WebSocket...")
        async with websockets.connect(uri) as websocket:
            print("✅ Connected successfully!")
            print("\n📨 Waiting for messages (5 seconds)...\n")
            
            try:
                # Wait for messages for 5 seconds
                message = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                data = json.loads(message)
                print(f"📬 Received message:")
                print(json.dumps(data, indent=2))
                print()
                
                # Try to receive more messages
                while True:
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=2.0)
                        data = json.loads(message)
                        print(f"📬 Received message:")
                        print(json.dumps(data, indent=2))
                        print()
                    except asyncio.TimeoutError:
                        print("⏰ No more messages in 2 seconds")
                        break
                        
            except asyncio.TimeoutError:
                print("⏰ No messages received in 5 seconds")
                print("ℹ️  This is normal for mock WebSocket server")
            
            print("\n✅ WebSocket test completed successfully!")
            print("="*60 + "\n")
            return True
            
    except websockets.exceptions.WebSocketException as e:
        print(f"❌ WebSocket error: {e}")
        print("="*60 + "\n")
        return False
        
    except Exception as e:
        print(f"❌ Connection error: {e}")
        print("="*60 + "\n")
        return False


if __name__ == "__main__":
    result = asyncio.run(test_websocket())
    exit(0 if result else 1)
