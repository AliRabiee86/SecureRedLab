"""
Tests for NmapExecutor
Phase 7.2: Real Nmap implementation tests
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from app.execution.nmap_executor import NmapExecutor


# Sample Nmap XML output
SAMPLE_NMAP_XML = """<?xml version="1.0"?>
<nmaprun scanner="nmap" args="nmap -sS -p 1-1000 192.168.1.1" start="1640000000">
  <host>
    <status state="up"/>
    <address addr="192.168.1.1" addrtype="ipv4"/>
    <hostnames>
      <hostname name="target.local" type="PTR"/>
    </hostnames>
    <ports>
      <port protocol="tcp" portid="22">
        <state state="open" reason="syn-ack"/>
        <service name="ssh" product="OpenSSH" version="8.2p1" extrainfo="Ubuntu Linux" method="probed"/>
      </port>
      <port protocol="tcp" portid="80">
        <state state="open" reason="syn-ack"/>
        <service name="http" product="nginx" version="1.18.0" method="probed"/>
      </port>
      <port protocol="tcp" portid="443">
        <state state="open" reason="syn-ack"/>
        <service name="https" product="nginx" version="1.18.0" method="probed"/>
      </port>
    </ports>
    <os>
      <osmatch name="Linux 5.4" accuracy="95" line="71234">
        <osclass type="general purpose" vendor="Linux" osfamily="Linux" osgen="5.X" accuracy="95"/>
      </osmatch>
    </os>
  </host>
  <runstats>
    <finished time="1640000100" timestr="Mon Dec 20 10:01:40 2021" elapsed="100.23" summary="Nmap done at Mon Dec 20 10:01:40 2021; 1 IP address (1 host up) scanned in 100.23 seconds" exit="success"/>
  </runstats>
</nmaprun>
"""


@pytest.fixture
def mock_docker_client():
    """Mock Docker client"""
    with patch('docker.from_env') as mock:
        client = MagicMock()
        mock.return_value = client
        yield client


@pytest.fixture
def progress_callback():
    """Mock progress callback"""
    return AsyncMock()


@pytest.mark.asyncio
async def test_nmap_executor_initialization(mock_docker_client):
    """Test NmapExecutor initialization"""
    executor = NmapExecutor()
    assert executor.tool_name == "Nmap"
    assert executor.DOCKER_IMAGE == "instrumentisto/nmap:latest"
    assert executor.nm is not None


@pytest.mark.asyncio
async def test_build_nmap_command_basic(mock_docker_client):
    """Test basic Nmap command building"""
    executor = NmapExecutor()
    
    command = executor._build_nmap_command(
        target="192.168.1.1",
        ports="1-1000",
        scan_type="syn",
        service_detection=False,
        os_detection=False,
        nse_scripts=None,
        timing=4
    )
    
    assert "nmap" in command
    assert "-sS" in command  # SYN scan
    assert "-p 1-1000" in command
    assert "-T4" in command
    assert "-oX -" in command  # XML output
    assert "192.168.1.1" in command


@pytest.mark.asyncio
async def test_build_nmap_command_with_version_detection(mock_docker_client):
    """Test Nmap command with service version detection"""
    executor = NmapExecutor()
    
    command = executor._build_nmap_command(
        target="192.168.1.1",
        ports="22,80,443",
        scan_type="tcp",
        service_detection=True,
        os_detection=False,
        nse_scripts=None,
        timing=4
    )
    
    assert "-sT" in command  # TCP Connect scan
    assert "-sV" in command  # Service version
    assert "-p 22,80,443" in command


@pytest.mark.asyncio
async def test_build_nmap_command_with_os_detection(mock_docker_client):
    """Test Nmap command with OS detection"""
    executor = NmapExecutor()
    
    command = executor._build_nmap_command(
        target="192.168.1.1",
        ports="1-1000",
        scan_type="syn",
        service_detection=False,
        os_detection=True,
        nse_scripts=None,
        timing=4
    )
    
    assert "-O" in command  # OS detection


@pytest.mark.asyncio
async def test_build_nmap_command_with_nse_scripts(mock_docker_client):
    """Test Nmap command with NSE scripts"""
    executor = NmapExecutor()
    
    command = executor._build_nmap_command(
        target="192.168.1.1",
        ports="80,443",
        scan_type="tcp",
        service_detection=False,
        os_detection=False,
        nse_scripts=["vuln", "default"],
        timing=3
    )
    
    assert "--script vuln,default" in command
    assert "-T3" in command


@pytest.mark.asyncio
async def test_parse_output_xml(mock_docker_client):
    """Test XML output parsing"""
    executor = NmapExecutor()
    
    results = executor.parse_output(SAMPLE_NMAP_XML)
    
    assert results["hosts_up"] == 1
    assert results["total_hosts"] == 1
    assert len(results["hosts"]) == 1
    
    host = results["hosts"][0]
    assert host["ip"] == "192.168.1.1"
    assert host["hostname"] == "target.local"
    assert host["state"] == "up"
    assert len(host["open_ports"]) == 3
    
    # Check ports
    ports = {p["port"]: p for p in host["open_ports"]}
    assert 22 in ports
    assert ports[22]["service"]["name"] == "ssh"
    assert ports[22]["service"]["product"] == "OpenSSH"
    assert ports[22]["service"]["version"] == "8.2p1"
    
    assert 80 in ports
    assert ports[80]["service"]["name"] == "http"
    assert ports[80]["service"]["product"] == "nginx"
    
    # Check OS detection
    assert host["os_detection"] is not None
    assert "Linux" in host["os_detection"]["name"]
    assert host["os_detection"]["accuracy"] == 95


@pytest.mark.asyncio
async def test_parse_output_no_xml(mock_docker_client):
    """Test parsing when no XML in output"""
    executor = NmapExecutor()
    
    results = executor.parse_output("No XML here, just plain text")
    
    assert "error" in results
    assert results["hosts_up"] == 0
    assert len(results["hosts"]) == 0


@pytest.mark.asyncio
async def test_validate_target_valid_ipv4(mock_docker_client):
    """Test valid IPv4 target"""
    executor = NmapExecutor()
    
    # Should not raise
    executor._validate_target("192.168.1.1")
    executor._validate_target("10.0.0.1")
    executor._validate_target("8.8.8.8")


@pytest.mark.asyncio
async def test_validate_target_valid_domain(mock_docker_client):
    """Test valid domain target"""
    executor = NmapExecutor()
    
    # Should not raise
    executor._validate_target("example.com")
    executor._validate_target("subdomain.example.com")


@pytest.mark.asyncio
async def test_validate_target_valid_cidr(mock_docker_client):
    """Test valid CIDR target"""
    executor = NmapExecutor()
    
    # Should not raise
    executor._validate_target("192.168.1.0/24")
    executor._validate_target("10.0.0.0/8")


@pytest.mark.asyncio
async def test_validate_target_invalid_localhost(mock_docker_client):
    """Test blocked localhost target"""
    executor = NmapExecutor()
    
    with pytest.raises(ValueError, match="not allowed"):
        executor._validate_target("localhost")
    
    with pytest.raises(ValueError, match="not allowed"):
        executor._validate_target("127.0.0.1")


@pytest.mark.asyncio
async def test_validate_target_invalid_format(mock_docker_client):
    """Test invalid target format"""
    executor = NmapExecutor()
    
    with pytest.raises(ValueError, match="Invalid target format"):
        executor._validate_target("not-a-valid-target!!!")


@pytest.mark.asyncio
async def test_validate_ports_valid(mock_docker_client):
    """Test valid port specifications"""
    executor = NmapExecutor()
    
    # Should not raise
    executor._validate_ports("80")
    executor._validate_ports("80,443")
    executor._validate_ports("1-1000")
    executor._validate_ports("20-25,80,443,8000-9000")
    executor._validate_ports("-")  # All ports


@pytest.mark.asyncio
async def test_validate_ports_invalid(mock_docker_client):
    """Test invalid port specifications"""
    executor = NmapExecutor()
    
    with pytest.raises(ValueError, match="Invalid port specification"):
        executor._validate_ports("80-")
    
    with pytest.raises(ValueError, match="Invalid port specification"):
        executor._validate_ports("-80")
    
    with pytest.raises(ValueError, match="Invalid port specification"):
        executor._validate_ports("80,443,")


@pytest.mark.asyncio
async def test_validate_ports_out_of_range(mock_docker_client):
    """Test port numbers out of range"""
    executor = NmapExecutor()
    
    with pytest.raises(ValueError, match="between 1 and 65535"):
        executor._validate_ports("0")
    
    with pytest.raises(ValueError, match="between 1 and 65535"):
        executor._validate_ports("65536")
    
    with pytest.raises(ValueError, match="between 1 and 65535"):
        executor._validate_ports("1-70000")


@pytest.mark.asyncio
async def test_validate_scan_type_valid(mock_docker_client):
    """Test valid scan types"""
    executor = NmapExecutor()
    
    # Should not raise
    executor._validate_scan_type("syn")
    executor._validate_scan_type("tcp")
    executor._validate_scan_type("udp")
    executor._validate_scan_type("version")


@pytest.mark.asyncio
async def test_validate_scan_type_invalid(mock_docker_client):
    """Test invalid scan type"""
    executor = NmapExecutor()
    
    with pytest.raises(ValueError, match="Invalid scan type"):
        executor._validate_scan_type("invalid_scan")


@pytest.mark.asyncio
async def test_privileged_scans_detection(mock_docker_client):
    """Test detection of scans that need privileged mode"""
    executor = NmapExecutor()
    
    assert "syn" in executor.PRIVILEGED_SCANS
    assert "udp" in executor.PRIVILEGED_SCANS
    assert "tcp" not in executor.PRIVILEGED_SCANS
    assert "version" not in executor.PRIVILEGED_SCANS


@pytest.mark.asyncio
async def test_scan_types_mapping(mock_docker_client):
    """Test scan type to Nmap flag mapping"""
    executor = NmapExecutor()
    
    assert executor.SCAN_TYPES["syn"] == "-sS"
    assert executor.SCAN_TYPES["tcp"] == "-sT"
    assert executor.SCAN_TYPES["udp"] == "-sU"
    assert executor.SCAN_TYPES["version"] == "-sV"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
