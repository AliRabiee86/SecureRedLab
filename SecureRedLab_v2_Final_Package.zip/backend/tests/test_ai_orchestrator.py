"""
Tests for AI Orchestrator
Phase 7.x: AI-controlled tools integration tests
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from app.execution.ai_orchestrator import (
    AIOrchestrator,
    get_ai_orchestrator,
    ToolType
)


@pytest.fixture
def mock_docker_client():
    """Mock Docker client"""
    with patch('docker.from_env') as mock:
        client = MagicMock()
        mock.return_value = client
        yield client


@pytest.fixture
def orchestrator(mock_docker_client):
    """Create orchestrator instance"""
    return AIOrchestrator()


def test_orchestrator_initialization(orchestrator):
    """Test orchestrator initialization"""
    assert orchestrator is not None
    assert len(orchestrator.executors) == 4
    assert ToolType.NMAP in orchestrator.executors
    assert ToolType.METASPLOIT in orchestrator.executors
    assert ToolType.SQLMAP in orchestrator.executors
    assert ToolType.NUCLEI in orchestrator.executors


def test_singleton_pattern(mock_docker_client):
    """Test singleton pattern"""
    orch1 = get_ai_orchestrator()
    orch2 = get_ai_orchestrator()
    assert orch1 is orch2


def test_detect_target_type_ip(orchestrator):
    """Test IP target detection"""
    assert orchestrator._detect_target_type("192.168.1.1") == "ip"
    assert orchestrator._detect_target_type("10.0.0.1") == "ip"


def test_detect_target_type_domain(orchestrator):
    """Test domain target detection"""
    assert orchestrator._detect_target_type("example.com") == "domain"
    assert orchestrator._detect_target_type("subdomain.example.com") == "domain"


def test_detect_target_type_url(orchestrator):
    """Test URL target detection"""
    assert orchestrator._detect_target_type("http://example.com") == "url"
    assert orchestrator._detect_target_type("https://example.com/path") == "url"


@pytest.mark.asyncio
async def test_analyze_target_ip(orchestrator):
    """Test target analysis for IP"""
    analysis = await orchestrator.analyze_target("192.168.1.1")
    
    assert analysis["target"] == "192.168.1.1"
    assert analysis["target_type"] == "ip"
    assert "nmap" in analysis["recommended_tools"]
    assert len(analysis["execution_plan"]) > 0


@pytest.mark.asyncio
async def test_analyze_target_url(orchestrator):
    """Test target analysis for URL"""
    analysis = await orchestrator.analyze_target("https://example.com")
    
    assert analysis["target"] == "https://example.com"
    assert analysis["target_type"] == "url"
    assert "nuclei" in analysis["recommended_tools"]


def test_execution_history(orchestrator):
    """Test execution history"""
    assert len(orchestrator.get_execution_history()) == 0
    
    # Add mock entry
    orchestrator.execution_history.append({"test": "data"})
    assert len(orchestrator.get_execution_history()) == 1
    
    # Clear history
    orchestrator.clear_history()
    assert len(orchestrator.get_execution_history()) == 0


@pytest.mark.asyncio
async def test_interpret_nmap_results_empty(orchestrator):
    """Test Nmap results interpretation with empty data"""
    results = {"hosts": []}
    interpretation = await orchestrator._interpret_nmap_results(results)
    
    assert "summary" in interpretation
    assert "open_services" in interpretation
    assert "security_concerns" in interpretation


@pytest.mark.asyncio
async def test_interpret_nmap_results_with_data(orchestrator):
    """Test Nmap results interpretation with data"""
    results = {
        "hosts": [{
            "ip": "192.168.1.1",
            "open_ports": [
                {
                    "port": 22,
                    "service": {"name": "ssh", "version": "8.2"}
                },
                {
                    "port": 80,
                    "service": {"name": "http", "version": ""}
                }
            ]
        }]
    }
    
    interpretation = await orchestrator._interpret_nmap_results(results)
    
    assert "2 open ports" in interpretation["summary"]
    assert len(interpretation["open_services"]) == 2
    assert "SSH exposed" in interpretation["security_concerns"]
    assert any("web vulnerability" in rec.lower() for rec in interpretation["recommendations"])


@pytest.mark.asyncio
async def test_determine_next_steps_web_service(orchestrator):
    """Test next step determination for web services"""
    scan_results = {}
    interpretation = {
        "recommendations": ["Run web vulnerability scan"]
    }
    
    next_steps = await orchestrator._determine_next_steps(scan_results, interpretation)
    
    assert len(next_steps) > 0
    assert next_steps[0]["tool"] == "nuclei"
    assert "web services detected" in next_steps[0]["reason"].lower()


@pytest.mark.asyncio
async def test_select_nuclei_templates_default(orchestrator):
    """Test Nuclei template selection"""
    templates = await orchestrator._select_nuclei_templates("https://example.com", None)
    
    assert "default" in templates


@pytest.mark.asyncio
async def test_interpret_vulnerabilities_empty(orchestrator):
    """Test vulnerability interpretation with empty data"""
    scan_results = {"vulnerabilities": []}
    interpretation = await orchestrator._interpret_vulnerabilities(scan_results)
    
    assert interpretation["critical_count"] == 0
    assert interpretation["high_count"] == 0
    assert len(interpretation["exploitable"]) == 0


@pytest.mark.asyncio
async def test_interpret_vulnerabilities_with_data(orchestrator):
    """Test vulnerability interpretation with data"""
    scan_results = {
        "vulnerabilities": [
            {"severity": "critical", "name": "CVE-2021-1234"},
            {"severity": "high", "name": "CVE-2021-5678"},
            {"severity": "medium", "name": "CVE-2021-9012"}
        ]
    }
    
    interpretation = await orchestrator._interpret_vulnerabilities(scan_results)
    
    assert interpretation["critical_count"] == 1
    assert interpretation["high_count"] == 1
    assert len(interpretation["exploitable"]) == 1  # Only critical


@pytest.mark.asyncio
async def test_select_exploit_safe_mode(orchestrator):
    """Test exploit selection (safe mode)"""
    vulnerability_data = {"cve": "CVE-2021-1234"}
    
    exploit_plan = await orchestrator._select_exploit(vulnerability_data)
    
    assert exploit_plan["safe"] == True
    assert exploit_plan["module"] is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
