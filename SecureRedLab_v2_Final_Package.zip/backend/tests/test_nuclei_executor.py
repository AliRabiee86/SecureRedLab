"""
SecureRedLab Backend - Nuclei Executor Tests
Phase 7.5: Comprehensive test suite for NucleiExecutor

Test Coverage:
- Input validation (target, severity, tags)
- Command building
- JSON Lines output parsing
- Vulnerability detection
- Severity filtering
- Security controls
- Error handling
- Timeout behavior

Author: SecureRedLab Team
Date: 2026-01-03
"""

import pytest
import asyncio
import json
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from typing import Dict, Any

from app.execution.nuclei_executor import (
    NucleiExecutor,
    SeverityLevel,
    TemplateTag
)
from app.execution.base_executor import ContainerExecutionError, ContainerTimeoutError


# Test Fixtures
@pytest.fixture
def nuclei_executor():
    """Create NucleiExecutor instance for testing."""
    return NucleiExecutor()


# ==================== Input Validation Tests ====================

class TestInputValidation:
    """Test input validation for NucleiExecutor."""
    
    def test_validate_target_valid_http(self, nuclei_executor):
        """Test valid HTTP target validation."""
        nuclei_executor._validate_target("http://example.com")  # Should not raise
    
    def test_validate_target_valid_https(self, nuclei_executor):
        """Test valid HTTPS target validation."""
        nuclei_executor._validate_target("https://example.com")  # Should not raise
    
    def test_validate_target_blocked_localhost(self, nuclei_executor):
        """Test that localhost is blocked."""
        with pytest.raises(ValueError, match="blocked for security reasons"):
            nuclei_executor._validate_target("http://localhost")
    
    def test_validate_target_blocked_127(self, nuclei_executor):
        """Test that 127.0.0.1 is blocked."""
        with pytest.raises(ValueError, match="blocked for security reasons"):
            nuclei_executor._validate_target("http://127.0.0.1")
    
    def test_validate_target_blocked_internal_10(self, nuclei_executor):
        """Test that 10.x.x.x is blocked."""
        with pytest.raises(ValueError, match="Internal IP"):
            nuclei_executor._validate_target("http://10.0.0.1")
    
    def test_validate_target_blocked_internal_192(self, nuclei_executor):
        """Test that 192.168.x.x is blocked."""
        with pytest.raises(ValueError, match="Internal IP"):
            nuclei_executor._validate_target("http://192.168.1.1")
    
    def test_validate_target_no_protocol(self, nuclei_executor):
        """Test target without http:// or https://."""
        with pytest.raises(ValueError, match="must start with http"):
            nuclei_executor._validate_target("example.com")


# ==================== Command Building Tests ====================

class TestCommandBuilding:
    """Test Nuclei command building."""
    
    def test_build_basic_command(self, nuclei_executor):
        """Test basic command building."""
        command = nuclei_executor._build_nuclei_command(
            target="https://example.com",
            templates=None,
            tags=None,
            severity=None,
            concurrency=25,
            rate_limit=50
        )
        
        assert "nuclei" in command
        assert "-u" in command
        assert "https://example.com" in command
        assert "-json" in command
        assert "-silent" in command
        assert "-c" in command
        assert "25" in command
    
    def test_build_command_with_tags(self, nuclei_executor):
        """Test command with specific tags."""
        command = nuclei_executor._build_nuclei_command(
            target="https://example.com",
            templates=None,
            tags=[TemplateTag.CVE, TemplateTag.XSS],
            severity=None,
            concurrency=25,
            rate_limit=50
        )
        
        assert "-tags" in command
        assert "cve,xss" in command
    
    def test_build_command_with_severity(self, nuclei_executor):
        """Test command with severity filtering."""
        command = nuclei_executor._build_nuclei_command(
            target="https://example.com",
            templates=None,
            tags=None,
            severity=[SeverityLevel.CRITICAL, SeverityLevel.HIGH],
            concurrency=25,
            rate_limit=50
        )
        
        assert "-severity" in command
        assert "critical,high" in command
    
    def test_build_command_with_templates(self, nuclei_executor):
        """Test command with specific templates."""
        command = nuclei_executor._build_nuclei_command(
            target="https://example.com",
            templates=["cves/", "exposures/"],
            tags=None,
            severity=None,
            concurrency=25,
            rate_limit=50
        )
        
        assert "-t" in command
        assert "cves/" in command
        assert "exposures/" in command


# ==================== Output Parsing Tests ====================

class TestOutputParsing:
    """Test Nuclei JSON Lines output parsing."""
    
    def test_parse_vulnerability_output(self, nuclei_executor):
        """Test parsing output with vulnerabilities found."""
        output = """
{"template-id":"CVE-2021-12345","info":{"name":"Example CVE","severity":"critical","tags":["cve","rce"],"author":"researcher"},"type":"http","matched-at":"https://example.com/vuln","timestamp":"2026-01-03T19:00:00Z"}
{"template-id":"xss-reflected","info":{"name":"Reflected XSS","severity":"high","tags":["xss"],"author":"tester"},"type":"http","matched-at":"https://example.com/search","timestamp":"2026-01-03T19:00:01Z"}
        """
        
        result = nuclei_executor._parse_nuclei_output(output)
        
        assert len(result['vulnerabilities']) == 2
        assert result['templates_matched'] == 2
        assert result['severity_counts']['critical'] == 1
        assert result['severity_counts']['high'] == 1
        
        # Check first vulnerability
        vuln1 = result['vulnerabilities'][0]
        assert vuln1['template_id'] == 'CVE-2021-12345'
        assert vuln1['severity'] == 'critical'
        assert 'cve' in vuln1['tags']
    
    def test_parse_empty_output(self, nuclei_executor):
        """Test parsing empty output (no vulnerabilities)."""
        output = ""
        
        result = nuclei_executor._parse_nuclei_output(output)
        
        assert len(result['vulnerabilities']) == 0
        assert result['templates_matched'] == 0
        assert result['severity_counts']['critical'] == 0
    
    def test_parse_malformed_json(self, nuclei_executor):
        """Test handling of malformed JSON."""
        output = """
{"template-id":"valid","info":{"name":"Valid","severity":"high"}}
{invalid json line}
{"template-id":"valid2","info":{"name":"Valid 2","severity":"medium"}}
        """
        
        result = nuclei_executor._parse_nuclei_output(output)
        
        # Should skip malformed line and parse valid ones
        assert len(result['vulnerabilities']) == 2


# ==================== Vulnerability Detection Tests ====================

class TestVulnerabilityDetection:
    """Test vulnerability detection functionality."""
    
    @pytest.mark.asyncio
    async def test_execute_success(self, nuclei_executor):
        """Test successful vulnerability detection."""
        with patch.object(nuclei_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'nuclei-123',
                'stdout': '{"template-id":"CVE-2021-12345","info":{"name":"Test CVE","severity":"critical","tags":["cve"]},"matched-at":"https://example.com/vuln"}',
                'stderr': '',
                'exit_code': 0
            }
            
            result = await nuclei_executor.execute(
                target="https://example.com",
                severity=[SeverityLevel.CRITICAL]
            )
            
            assert result['status'] == "completed"
            assert result['templates_matched'] > 0
            assert len(result['vulnerabilities']) > 0
    
    @pytest.mark.asyncio
    async def test_execute_no_vulnerabilities(self, nuclei_executor):
        """Test when no vulnerabilities are found."""
        with patch.object(nuclei_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'nuclei-123',
                'stdout': '',
                'stderr': '',
                'exit_code': 0
            }
            
            result = await nuclei_executor.execute(
                target="https://example.com"
            )
            
            assert result['status'] == "completed"
            assert result['templates_matched'] == 0
            assert len(result['vulnerabilities']) == 0


# ==================== Security Tests ====================

class TestSecurity:
    """Test security controls and validation."""
    
    @pytest.mark.asyncio
    async def test_blocked_target_localhost(self, nuclei_executor):
        """Test that localhost is blocked as target."""
        result = await nuclei_executor.execute(
            target="http://localhost"
        )
        
        assert result['status'] == "failed"
        assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_blocked_target_127(self, nuclei_executor):
        """Test that 127.0.0.1 is blocked."""
        result = await nuclei_executor.execute(
            target="http://127.0.0.1"
        )
        
        assert result['status'] == "failed"
    
    @pytest.mark.asyncio
    async def test_blocked_target_internal_10(self, nuclei_executor):
        """Test that 10.x.x.x is blocked."""
        result = await nuclei_executor.execute(
            target="http://10.0.0.1"
        )
        
        assert result['status'] == "failed"
    
    @pytest.mark.asyncio
    async def test_blocked_target_internal_192(self, nuclei_executor):
        """Test that 192.168.x.x is blocked."""
        result = await nuclei_executor.execute(
            target="http://192.168.1.1"
        )
        
        assert result['status'] == "failed"


# ==================== Integration Tests ====================

class TestIntegration:
    """Integration tests for full workflow."""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self, nuclei_executor):
        """Test complete vulnerability scanning workflow."""
        progress_updates = []
        
        def progress_callback(progress: int, message: str):
            progress_updates.append((progress, message))
        
        nuclei_executor.progress_callback = progress_callback
        
        with patch.object(nuclei_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'nuclei-123',
                'stdout': '{"template-id":"CVE-2021-12345","info":{"name":"Test","severity":"high","tags":["cve"]},"matched-at":"https://example.com"}',
                'stderr': '',
                'exit_code': 0
            }
            
            result = await nuclei_executor.execute(
                target="https://example.com",
                tags=[TemplateTag.CVE],
                severity=[SeverityLevel.HIGH, SeverityLevel.CRITICAL],
                scan_id="test_scan_001"
            )
            
            # Verify result
            assert result['status'] == "completed"
            assert result['scan_id'] == "test_scan_001"
            assert len(result['vulnerabilities']) > 0
            
            # Verify progress updates
            assert len(progress_updates) > 0
            assert progress_updates[0][0] == 10  # First progress
            assert progress_updates[-1][0] == 100  # Last progress


# ==================== Error Handling Tests ====================

class TestErrorHandling:
    """Test error handling and recovery."""
    
    @pytest.mark.asyncio
    async def test_container_failure(self, nuclei_executor):
        """Test handling of container execution failure."""
        with patch.object(nuclei_executor, '_run_container', side_effect=Exception("Container failed")):
            result = await nuclei_executor.execute(
                target="https://example.com"
            )
            
            assert result['status'] == "failed"
            assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_timeout_handling(self, nuclei_executor):
        """Test handling of execution timeout."""
        with patch.object(nuclei_executor, '_run_container', side_effect=asyncio.TimeoutError("Timeout")):
            result = await nuclei_executor.execute(
                target="https://example.com",
                timeout=10
            )
            
            assert result['status'] == "failed"
            assert 'error' in result


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
