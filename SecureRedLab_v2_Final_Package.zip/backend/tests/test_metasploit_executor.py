"""
SecureRedLab Backend - Metasploit Executor Tests
Phase 7.3: Comprehensive test suite for MetasploitExecutor

Test Coverage:
- Input validation (target, module, payload, lhost)
- msfrpcd lifecycle management
- Exploit execution
- Session management
- Security controls
- Error handling
- Timeout behavior

Author: SecureRedLab Team
Date: 2026-01-01
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from typing import Dict, Any

from app.execution.metasploit_executor import (
    MetasploitExecutor,
    ExploitType,
    PayloadType
)
from app.execution.base_executor import ContainerExecutionError, ContainerTimeoutError


# Test Fixtures
@pytest.fixture
def metasploit_executor():
    """Create MetasploitExecutor instance for testing."""
    return MetasploitExecutor()


@pytest.fixture
def mock_msf_client():
    """Mock MsfRpcClient for testing."""
    client = MagicMock()
    client.sessions.list = {}
    client.modules.use = MagicMock()
    return client


# ==================== Input Validation Tests ====================

class TestInputValidation:
    """Test input validation for MetasploitExecutor."""
    
    def test_validate_target_valid_ip(self, metasploit_executor):
        """Test valid IP target validation."""
        metasploit_executor._validate_target("192.168.1.100")  # Should not raise
    
    def test_validate_target_valid_hostname(self, metasploit_executor):
        """Test valid hostname target validation."""
        metasploit_executor._validate_target("example.com")  # Should not raise
    
    def test_validate_target_blocked_localhost(self, metasploit_executor):
        """Test that localhost is blocked."""
        with pytest.raises(ValueError, match="blocked for security reasons"):
            metasploit_executor._validate_target("localhost")
    
    def test_validate_target_blocked_127(self, metasploit_executor):
        """Test that 127.0.0.1 is blocked."""
        with pytest.raises(ValueError, match="blocked for security reasons"):
            metasploit_executor._validate_target("127.0.0.1")
    
    def test_validate_target_empty(self, metasploit_executor):
        """Test empty target validation."""
        with pytest.raises(ValueError, match="Target is required"):
            metasploit_executor._validate_target("")
    
    def test_validate_module_valid(self, metasploit_executor):
        """Test valid module validation."""
        metasploit_executor._validate_module("exploit/windows/smb/ms17_010_eternalblue")
    
    def test_validate_module_invalid_format(self, metasploit_executor):
        """Test invalid module format."""
        with pytest.raises(ValueError, match="Invalid module format"):
            metasploit_executor._validate_module("invalid")
    
    def test_validate_module_invalid_category(self, metasploit_executor):
        """Test invalid module category."""
        with pytest.raises(ValueError, match="category .* not allowed"):
            metasploit_executor._validate_module("invalid_category/windows/test")
    
    def test_validate_payload_valid(self, metasploit_executor):
        """Test valid payload validation."""
        metasploit_executor._validate_payload("windows/x64/meterpreter/reverse_tcp")
    
    def test_validate_payload_invalid(self, metasploit_executor):
        """Test invalid payload format."""
        with pytest.raises(ValueError, match="Invalid payload format"):
            metasploit_executor._validate_payload("invalid_payload")
    
    def test_validate_lhost_blocked(self, metasploit_executor):
        """Test that localhost is blocked as LHOST."""
        with pytest.raises(ValueError, match="not allowed"):
            metasploit_executor._validate_lhost("127.0.0.1")


# ==================== msfrpcd Lifecycle Tests ====================

class TestMsfrpcdLifecycle:
    """Test msfrpcd daemon lifecycle management."""
    
    @pytest.mark.asyncio
    async def test_start_msfrpcd(self, metasploit_executor):
        """Test starting msfrpcd daemon."""
        with patch.object(metasploit_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            mock_run.return_value = {
                'container_id': 'msfrpcd-123',
                'stdout': 'msfrpcd started',
                'exit_code': 0
            }
            
            await metasploit_executor._start_msfrpcd()
            
            assert metasploit_executor.msfrpcd_running is True
            assert metasploit_executor.msfrpcd_container_id == 'msfrpcd-123'
            mock_run.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_start_msfrpcd_already_running(self, metasploit_executor):
        """Test starting msfrpcd when already running."""
        metasploit_executor.msfrpcd_running = True
        
        with patch.object(metasploit_executor, '_run_container', new_callable=AsyncMock) as mock_run:
            await metasploit_executor._start_msfrpcd()
            mock_run.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_cleanup_msfrpcd(self, metasploit_executor):
        """Test cleaning up msfrpcd resources."""
        metasploit_executor.msfrpcd_container_id = 'msfrpcd-123'
        metasploit_executor.msfrpcd_running = True
        
        with patch.object(metasploit_executor, '_kill_container_async', new_callable=AsyncMock):
            await metasploit_executor._cleanup_msfrpcd()
            
            assert metasploit_executor.msfrpcd_running is False
            assert metasploit_executor.msfrpcd_container_id is None


# ==================== Exploit Execution Tests ====================

class TestExploitExecution:
    """Test exploit execution functionality."""
    
    @pytest.mark.asyncio
    async def test_execute_success(self, metasploit_executor):
        """Test successful exploit execution."""
        with patch.object(metasploit_executor, '_start_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_connect_to_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_configure_exploit', new_callable=AsyncMock) as mock_config, \
             patch.object(metasploit_executor, '_execute_exploit', new_callable=AsyncMock) as mock_exec, \
             patch.object(metasploit_executor, '_cleanup_msfrpcd', new_callable=AsyncMock):
            
            mock_config.return_value = {
                'exploit': MagicMock(),
                'module': 'exploit/windows/smb/ms17_010_eternalblue',
                'target': '192.168.1.100',
                'payload': 'windows/x64/meterpreter/reverse_tcp'
            }
            
            mock_exec.return_value = {
                'success': True,
                'sessions': {'1': {'id': 1}},
                'output': 'Session 1 created'
            }
            
            result = await metasploit_executor.execute(
                target="192.168.1.100",
                module="exploit/windows/smb/ms17_010_eternalblue",
                payload="windows/x64/meterpreter/reverse_tcp",
                lhost="10.0.0.1",
                lport=4444
            )
            
            assert result['success'] is True
            assert result['target'] == "192.168.1.100"
            assert result['status'] == "completed"
            assert 'session_id' in result
    
    @pytest.mark.asyncio
    async def test_execute_failure(self, metasploit_executor):
        """Test failed exploit execution."""
        with patch.object(metasploit_executor, '_validate_target', side_effect=ValueError("Invalid target")):
            result = await metasploit_executor.execute(
                target="invalid",
                module="exploit/windows/smb/ms17_010_eternalblue"
            )
            
            assert result['success'] is False
            assert result['status'] == "failed"
            assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_execute_timeout(self, metasploit_executor):
        """Test exploit execution timeout."""
        with patch.object(metasploit_executor, '_start_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_connect_to_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_configure_exploit', side_effect=asyncio.TimeoutError("Timeout")), \
             patch.object(metasploit_executor, '_cleanup_msfrpcd', new_callable=AsyncMock):
            
            result = await metasploit_executor.execute(
                target="192.168.1.100",
                module="exploit/windows/smb/ms17_010_eternalblue",
                timeout=10
            )
            
            assert result['success'] is False
            assert 'error' in result


# ==================== Result Parsing Tests ====================

class TestResultParsing:
    """Test exploit result parsing."""
    
    def test_parse_exploit_result_success(self, metasploit_executor):
        """Test parsing successful exploit result."""
        result = {
            'success': True,
            'sessions': {'1': {'id': 1, 'type': 'meterpreter'}},
            'module': 'exploit/windows/smb/ms17_010_eternalblue',
            'output': 'Session 1 created'
        }
        
        parsed = metasploit_executor._parse_exploit_result(result)
        
        assert parsed['success'] is True
        assert parsed['session_id'] == '1'
        assert len(parsed['vulnerabilities']) > 0
        assert parsed['vulnerabilities'][0]['severity'] == 'CRITICAL'
    
    def test_parse_exploit_result_failure(self, metasploit_executor):
        """Test parsing failed exploit result."""
        result = {
            'success': False,
            'sessions': {},
            'output': 'Exploit failed',
            'error': 'Target not vulnerable'
        }
        
        parsed = metasploit_executor._parse_exploit_result(result)
        
        assert parsed['success'] is False
        assert parsed['session_id'] is None
        assert len(parsed['vulnerabilities']) == 0


# ==================== Security Tests ====================

class TestSecurity:
    """Test security controls and validation."""
    
    @pytest.mark.asyncio
    async def test_blocked_target_localhost(self, metasploit_executor):
        """Test that localhost is blocked as target."""
        result = await metasploit_executor.execute(
            target="localhost",
            module="exploit/windows/smb/ms17_010_eternalblue"
        )
        
        assert result['success'] is False
        assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_blocked_target_127(self, metasploit_executor):
        """Test that 127.0.0.1 is blocked."""
        result = await metasploit_executor.execute(
            target="127.0.0.1",
            module="exploit/windows/smb/ms17_010_eternalblue"
        )
        
        assert result['success'] is False
    
    def test_dangerous_module_warning(self, metasploit_executor, caplog):
        """Test that dangerous modules trigger warning."""
        metasploit_executor._validate_module("exploit/multi/handler")
        
        # Check that warning was logged
        assert any("dangerous module" in record.message.lower() for record in caplog.records)


# ==================== Integration Tests ====================

class TestIntegration:
    """Integration tests for full exploit workflow."""
    
    @pytest.mark.asyncio
    async def test_full_exploit_workflow(self, metasploit_executor):
        """Test complete exploit workflow from start to finish."""
        progress_updates = []
        
        def progress_callback(progress: int, message: str):
            progress_updates.append((progress, message))
        
        metasploit_executor.progress_callback = progress_callback
        
        with patch.object(metasploit_executor, '_start_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_connect_to_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_configure_exploit', new_callable=AsyncMock) as mock_config, \
             patch.object(metasploit_executor, '_execute_exploit', new_callable=AsyncMock) as mock_exec, \
             patch.object(metasploit_executor, '_cleanup_msfrpcd', new_callable=AsyncMock):
            
            mock_config.return_value = {
                'exploit': MagicMock(),
                'module': 'exploit/windows/smb/ms17_010_eternalblue',
                'target': '192.168.1.100',
                'payload': 'windows/x64/meterpreter/reverse_tcp'
            }
            
            mock_exec.return_value = {
                'success': True,
                'sessions': {'1': {'id': 1}},
                'output': 'Session created'
            }
            
            result = await metasploit_executor.execute(
                target="192.168.1.100",
                module="exploit/windows/smb/ms17_010_eternalblue",
                payload="windows/x64/meterpreter/reverse_tcp",
                lhost="10.0.0.1",
                attack_id="test_attack_001"
            )
            
            # Verify result
            assert result['success'] is True
            assert result['attack_id'] == "test_attack_001"
            assert result['status'] == "completed"
            
            # Verify progress updates
            assert len(progress_updates) > 0
            assert progress_updates[0][0] == 10  # First progress
            assert progress_updates[-1][0] == 100  # Last progress


# ==================== Error Handling Tests ====================

class TestErrorHandling:
    """Test error handling and recovery."""
    
    @pytest.mark.asyncio
    async def test_msfrpcd_startup_failure(self, metasploit_executor):
        """Test handling of msfrpcd startup failure."""
        with patch.object(metasploit_executor, '_run_container', side_effect=Exception("Container failed")):
            result = await metasploit_executor.execute(
                target="192.168.1.100",
                module="exploit/windows/smb/ms17_010_eternalblue"
            )
            
            assert result['success'] is False
            assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_connection_failure(self, metasploit_executor):
        """Test handling of msfrpcd connection failure."""
        with patch.object(metasploit_executor, '_start_msfrpcd', new_callable=AsyncMock), \
             patch.object(metasploit_executor, '_connect_to_msfrpcd', side_effect=Exception("Connection failed")), \
             patch.object(metasploit_executor, '_cleanup_msfrpcd', new_callable=AsyncMock):
            
            result = await metasploit_executor.execute(
                target="192.168.1.100",
                module="exploit/windows/smb/ms17_010_eternalblue"
            )
            
            assert result['success'] is False


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
