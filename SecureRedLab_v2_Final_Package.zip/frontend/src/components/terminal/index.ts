/**
 * SecureRedLab - Terminal Components Index
 * Phase 8.4 - Interactive Components
 */

export { default as Terminal } from './Terminal';
